export interface SideNavRouteInfo {
    id: number;
    path: string;
    name: string;
    active: boolean;
    submenu: SideNavRouteInfo[];
}
