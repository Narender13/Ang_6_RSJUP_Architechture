export interface EntityTypeHead {
    id: number;
    name: string;
    entityEnum: number;
    entityType: string;
} 
