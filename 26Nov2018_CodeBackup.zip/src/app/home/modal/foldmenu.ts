export interface FoldMenu {
    id: number;
    item: string;
}
