import { Component, OnInit } from '@angular/core';
import { SearchService } from '../finance/search/service/search.service';
import { Router } from '@angular/router';
import { HomeService } from './services/home.service';
import { Activity } from './modal/activity';
import { CategoryType } from '../finance/search/model/category';
import { MytaskRemainder, Unapproved, Draft, PendingApproval, AwaitingApproval } from './modal/mytaskremainder';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { SharedService } from 'src/app/finance/services/shared.service';

@Component({
  selector: 'rsa-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  userdata: any = { 'welcomeMsg': 'HELLO!', 'msg1': 'what do you want to do', 'msg2': 'today?' };
  categorydata: any;
  activityData: Activity[];
  category: number;
  categoryItem: string;
  searchval = '';
  entitysearchlist: any[] = [];
  pendingApprovals: PendingApproval[] = [];
  drafts: Draft[] = [];
  unApproved: Unapproved[] = [];
  awaitingApproval: AwaitingApproval[] = [];
  invalidsearch = true;
  lobData: any = [];
  opentasks: number;
  username: string;
  entitySerachId;
  entitySerachType;
  entitySerachItem;
  titleText = 'Please select the LOB before selecting category';
  categoryselectedValue = 'Select Category';
  lobvalue = 'Select LOB';
  lob: number;
  lobItem: string;
  isVewedEnable = true;
  isDisabled = true;
  constructor(private searchService: SearchService, private homeservice: HomeService,
    private router: Router) { }

  ngOnInit() {
    this.getCategorydataData();
    this.getActivity();
    this.getMyTaskAndRemainder();
    this.getUserData();
    this.getLobData();
  }



  getCategorydataData(): void {
    this.homeservice.getCategoryData().subscribe((dropDowndata) => {
      this.categorydata = dropDowndata;
      console.log(dropDowndata, 'dropdowndata');
    });
  }

  getLobData(): void {
    this.homeservice.getLobDataList().subscribe((data) => {
      this.lobData = data;
      console.log(data, 'data');
    });
  }


  getEntitySearchListData(params): void {
    console.log('calling function' + params);
    this.homeservice.getEntitySearchListData(this.searchval)
      .subscribe((searchlistdata) => {
        this.entitysearchlist = searchlistdata;
        console.log(this.entitysearchlist, 'enti');
      });
  }

  displayCheckedItem(activity: Activity) {
    this.activityData.forEach(item => {
      if (item.item === activity.item) {
        item.checked = activity.checked;
      }
    });
  }

  getActivity(): void {
    this.homeservice.populateDropDown().subscribe((data) => {
      this.activityData = data;
    });
  }

  getMyTaskAndRemainder(): void {
    this.homeservice.getMyTaskRemainder().subscribe((mytaskremainder: MytaskRemainder) => {
      this.pendingApprovals = mytaskremainder.Mytask.PendingApprovals;
      this.drafts = mytaskremainder.Mytask.Drafts;
      this.unApproved = mytaskremainder.Mytask.Unapproved;
      this.awaitingApproval = mytaskremainder.Reminders.AwaitingApprovals;

    });
  }
  typeaheadOnSelect(typeheadobj: TypeaheadMatch): void {
    console.log('Selected value: ', typeheadobj);
    this.entitySerachId = typeheadobj.item.id;
    this.entitySerachType = typeheadobj.item.entityEnum;
    this.entitySerachItem = typeheadobj.item.name;
  }

  setCategory(category: CategoryType) {
    this.category = category.id;
    console.log(this.categoryItem);
    this.categoryItem = category.item;
    console.log(this.categoryItem);
    this.searchval = '';
  }

  setLobDefaults() {
    this.categorydata = [
      { id: 1, item: 'Policy No' },
      { id: 8, item: 'Claim No' },
      { id: 10, item: 'Quotation No' }
    ];
    this.isVewedEnable = false;
  }

  setLobDefaultsAccts() {
    this.categorydata = [
      { id: 2, item: 'Receipt No' },
      { id: 3, item: 'Payment No' },
      { id: 4, item: 'Entity' },
      { id: 5, item: 'Credit Note No' },
      { id: 6, item: 'Tax Invoice No' },
      { id: 7, item: 'Journal No' },
      { id: 11, item: 'Payee Name' },
      { id: 12, item: 'Cheque No' },
      { id: 13, item: 'Approval Code' }
    ];

  }

  setLob(lob: CategoryType) {
    this.lob = lob.id;
    this.lobItem = lob.item;
    this.searchval = '';
    this.titleText = '';
    this.isDisabled = false;
    if (lob.id == 0) {
      this.categoryselectedValue = 'Select Category';
      this.setLobDefaultsAccts();
      this.isVewedEnable = true;
    } else {
      this.categoryselectedValue = 'select category';
      this.setLobDefaults();
    }

  }

  search() {
    this.invalidsearch = (this.category !== undefined && this.category > 0) &&
      (this.lob !== undefined) &&
      (this.searchval !== undefined && this.searchval !== '' && this.searchval.length > 0);
    if (this.invalidsearch) {
      let params;
      if (this.category == 4) {
        params = {
          'id': this.entitySerachId,
          'entityType': this.entitySerachType,
          'entityUnMatched': 0,
          'categoryType': this.category,
          'entitySerachItem': this.entitySerachItem,
        };
      } else {
        params = {
          'inputData': this.searchval,
          'category': this.category,
          'categoryitem': this.categoryItem,
          'classCode': this.lob,
          'lobitem': this.lobItem,
        };
      }
      this.router.navigate(['home/search/result'], {
        queryParams: params
      });
    }
  }

  opentasksList(ev: number) {
    this.opentasks = (this.opentasks === ev) ? -1 : ev;
  }


  viewDrfat(draft) {
    console.log(draft, 'val');
    const params = {
      'totalCount': draft.TaskCount,
      'voucherName': draft.TaskName,
    };
    console.log(params);
    this.router.navigate(['home/search/draft'], {
      queryParams: params
    });
  }

  getUserData(): void {
    this.homeservice.getUserInfo().subscribe((data) => {
      if (window.localStorage) {
        localStorage.clear();
        for (const prop in data) {
          if ((data[prop]) instanceof Array) {
            localStorage.setItem(prop, JSON.stringify(data[prop]));
          } else {
            localStorage.setItem(prop, data[prop]);
          }
        }

      }

      this.username = localStorage.getItem('firstname') + ' ' + localStorage.getItem('lastname');
    });
  }

  lookUpChange(e) {
    if (e.srcElement.value.length >= 2) {
      this.getEntitySearchListData(e.srcElement.value);
    } else {
      this.entitysearchlist = [];
    }
  }



}
