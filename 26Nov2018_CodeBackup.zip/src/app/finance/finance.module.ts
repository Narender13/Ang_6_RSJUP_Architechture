import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchModule } from './search/search.module';
import { SharedModule } from '../shared/shared.module';
import { FinanceRoutingModule } from './finance-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';


import { PaymentsComponent } from './payments/payments.component';
import { GeneralComponent } from './general/general.component';
import { ChequeComponent } from './cheque/cheque.component';
import { JournalsComponent } from './journals/journals.component';
import { ReportsComponent } from './reports/reports.component';
import { EntitiesComponent } from './entities/entities.component';
import { MonthendComponent } from './monthend/monthend.component';
import { DialogComponent } from './dialog/dialog.component';
import { CreateReceiptComponent } from './receipts/create-receipt/create-receipt.component';
import { CreateAgentComponent } from './entities/create-entitie/agent/create-agent.component';
import { CreateAdvocateComponent } from './entities/create-entitie/advocate/create-advocate.component';
import { CreateBrokerComponent } from './entities/create-entitie/broker/create-broker.component';
import { CreateCustomerComponent } from './entities/create-entitie/customer/create-customer.component';
import { CreateCompanyComponent } from './entities/create-entitie/company/create-company.component';
import { CreatePoliceStationComponent } from './entities/create-entitie/police-station/create-police-station.component';
import { CreateRecoveryAgentComponent } from './entities/create-entitie/recovery-agent/create-recovery-agent.component';
import { CreateSurveyorComponent } from './entities/create-entitie/surveyor/create-surveyor.component';
import { CreateRepairerComponent } from './entities/create-entitie/repairer/create-repairer.component';
import { CreatePaymentComponent } from './payments/create-payment/create-payment.component';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { ReceiptCancelComponent } from './receipts/receipt-cancel/receipt-cancel.component';
import { SharedService } from 'src/app/finance/services/shared.service';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { PaymentpreviewComponent } from './preview/uae/paymentpreview/paymentpreview.component';
import { CreateCreditnotesComponent } from 'src/app/finance/creditnotes/create-creditnotes/create-creditnotes.component';
import { CreateDebitnotesComponent } from 'src/app/finance/debitnotes/create-debitnotes/create-debitnotes.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';
import { DraftsResultsComponent } from './drfats/drafts-results/drafts-results.component';
import { ReceiptDraftsComponent } from './drfats/drafts-results/receipt-drafts/receipt-drafts.component';
import { CreateDraftReceiptComponent } from './drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
import { CurrencyRendererComponent } from 'src/app/shared/datatable/services/currency-renderer.component';
import { ChequePrintComponent } from 'src/app/finance/payments/cheque-print/cheque-print.component';
import { ChequePrintDialogComponent } from 'src/app/finance/payments/cheque-print-model/cheque-print-model.component';

/* end */

@NgModule({
  imports: [
    CommonModule,
    SearchModule,
    SharedModule,
    FinanceRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AgGridModule.withComponents([CurrencyRendererComponent]),
    // SharedCreateEntitieModule,
    ModalModule.forRoot()
  ],
  declarations: [
 
    PaymentsComponent,
    GeneralComponent,
    ChequeComponent,
    JournalsComponent,
    CreateDebitnotesComponent,
    CreateDebitnotesComponent,
    ReportsComponent,
    EntitiesComponent,
    MonthendComponent,
    DialogComponent,
    CreateReceiptComponent,
    CreateAgentComponent,
    CreateAdvocateComponent,
    CreateBrokerComponent,
    CreateCustomerComponent,
    CreateCompanyComponent,
    CreatePoliceStationComponent,
    CreateRecoveryAgentComponent,
    CreateSurveyorComponent,
    CreateRepairerComponent,
    CreatePaymentComponent,
    ReceiptpreviewComponent,
    ReceiptCancelComponent,
    BasevoucherComponent,
    PaymentpreviewComponent,
    CreateDebitnotesComponent,
    CreateCreditnotesComponent,
    CnpreviewComponent,
    TaxinvoicepreviewComponent,
    DraftsResultsComponent,
    ReceiptDraftsComponent,
    CreateDraftReceiptComponent,
    ChequePrintComponent,
    ChequePrintDialogComponent,

  ],
  entryComponents: [
    CreateReceiptComponent,
    CreatePaymentComponent,
    ReceiptpreviewComponent,
    PaymentpreviewComponent,
    ReceiptCancelComponent,
    CreateDebitnotesComponent,
    CreateCreditnotesComponent,
    CnpreviewComponent,
    TaxinvoicepreviewComponent,
    CreateDraftReceiptComponent,
    ChequePrintDialogComponent
  ],
  providers: [
    SharedService,
    BsModalRef

  ]
})
export class FinanceModule { }
