import { Component, OnInit, Input } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateReceiptComponent } from '../receipts/create-receipt/create-receipt.component';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { CreatePaymentComponent } from '../payments/create-payment/create-payment.component';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { CreateDebitnotesComponent } from 'src/app/finance/debitnotes/create-debitnotes/create-debitnotes.component';
import { CreateCreditnotesComponent } from 'src/app/finance/creditnotes/create-creditnotes/create-creditnotes.component';

@Component({
  selector: 'rsa-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {

  private bsModalRef: BsModalRef;
  private errorMsg: string;
  private configdialog: any;

  constructor(private modalService: BsModalService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.route.queryParams.subscribe(
      param => {
        this.configdialog = param;
      },
      err => this.errorMsg = err
    );
    this.openModal();
    this.router.navigate(['/home']);
    console.log(this.configdialog.dialogname, 'dailogname');
  }

  openModal() {
    const initialState = this.configdialog;
    switch (this.configdialog.dialogname) {
      case 'Receipt':
        this.bsModalRef = this.modalService.show(CreateReceiptComponent,
          Object.assign({}, this.configdialog, { class: 'create-modal-dailog', initialState }));
        break;
      case 'Payment':
        this.bsModalRef = this.modalService.show(CreatePaymentComponent,
          Object.assign({}, this.configdialog, { class: 'create-modal-dailog', initialState }));
        break;
      case 'Receipts-Preview':
        const data = JSON.parse(initialState.data);
        this.bsModalRef = this.modalService.show(ReceiptpreviewComponent,
          Object.assign({}, this.configdialog, { class: 'preview-modal-dailog', initialState: { 'data': data } }));
        break;
      case 'CreditNote':
        this.bsModalRef = this.modalService.show(CreateCreditnotesComponent,
          Object.assign({}, this.configdialog, { class: 'create-modal-dailog', initialState }));
        break;
        case 'TaxInvoice':
        this.bsModalRef = this.modalService.show(CreateDebitnotesComponent,
          Object.assign({}, this.configdialog, { class: 'create-modal-dailog', initialState }));
        break;

        

    }
  }
}


