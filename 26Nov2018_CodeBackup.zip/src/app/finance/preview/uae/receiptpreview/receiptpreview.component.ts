import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { ActivatedRoute } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SharedService } from 'src/app/finance/services/shared.service';
import { validateEmail } from 'src/app/shared/utilites/helper';
@Component({
  selector: 'rsa-receiptpreview',
  templateUrl: './receiptpreview.component.html',
  styleUrls: ['./receiptpreview.component.scss']
})
export class ReceiptpreviewComponent implements OnInit {

  constructor(private modalService: BsModalService, public bsModalRef: BsModalRef, private createservice: CreateService,
    private route: ActivatedRoute, private alertService: AlertService, private sharedService: SharedService) { }
  data: any;
  symbol: string;
  returnValue: any;
  errorMsg: string;
  previewScreenFlag = true;
  approval = false;
  approverlist = '';
  emailVoucher = false;
  emailAddress;
  logourl;
  isUAE;
  isKSA;
  isOman;
  isBahrain;
  successmsg;
  invalidEmailAddress = true;
  checkcorrectEmail = true;
  totalAmount;
  fromCategory: any = null;
  brokerCustomerAmount: Number;
  ngOnInit() {
    setTimeout(() => {
      this.data = this.bsModalRef.content.data || this.data;
      this.totalAmount = this.bsModalRef.content.totalAmount;
      this.brokerCustomerAmount = this.bsModalRef.content.brokerCustomerAmount || 0;
      console.log(this.data, 'data');
      console.log(this.brokerCustomerAmount);
    }, 100);

    this.symbol = (localStorage.getItem('symbol'));
    this.logourl = localStorage.getItem('logourl') || 'src/assets/images/logo_rsa.svg';
    this.isUAE = (localStorage.getItem('regioncode') == '2');
    this.isKSA = (localStorage.getItem('regioncode') == '1');
    this.isOman = (localStorage.getItem('regioncode') == '3');
    this.isBahrain = (localStorage.getItem('regioncode') == '5');
  }
  print() {
    window.print();
  }

  saveReceipt(receiptID) {
    this.previewScreenFlag = false;
    this.createservice.saveReceipt(receiptID).subscribe(
      dataReturn => {

        this.returnValue = dataReturn;
        this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
      },
      errorRturn => {
        this.errorMsg = errorRturn;
      }
    );
  }

  previous() {
    this.bsModalRef.hide();
    this.sharedService.sendMessage("previous");
    this.sharedService.sendMessage({ id: this.data.ReceiptNo });

  }
  close() {
    this.bsModalRef.hide();
    this.modalService.hide(1);
    this.sharedService.sendMessage("close");
  }

  sendEmail(receiptnumber) {
    this.invalidEmailAddress = (this.emailAddress !== undefined && this.emailAddress !== '' && this.emailAddress.length > 0);
    this.checkcorrectEmail = validateEmail(this.emailAddress);
    if (this.invalidEmailAddress && this.checkcorrectEmail) {
      const param = {
        ToEmailID: this.emailAddress,
        LoggedInUserID: 181,
        IsApproved: true,
        ReceiptNo: receiptnumber
      };
      this.createservice.sendEmail(param).subscribe((data) => {
        // this.bsModalRef.hide();
        this.successmsg = data;
        this.alertService.success(data);
        console.log(data, 'data sucessfully');
      },
        errorRturn => {
          this.errorMsg = errorRturn;
        });
    }

  }
}
