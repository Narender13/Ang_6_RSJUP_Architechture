import { Component, OnInit, ViewChild, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

import { SharedService } from '../../services/shared.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { MasterDataService } from '../../services/finance.masterdata.service';
import { ChequePrintService } from './service/cheque-print.service';
import { GridOptions } from 'ag-grid-community';
import { ChequePrintGridService } from './service/cheque-print-grid.service';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { AgGridNg2 } from 'ag-grid-angular';
import { CurrencyRendererComponent } from 'src/app/shared/datatable/services/currency-renderer.component';
import { ChequePrint } from './model/cheque-print.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ChequePrintDialogComponent } from '../cheque-print-model/cheque-print-model.component';

@Component({
    // tslint:disable-next-line:component-selector
    selector: 'rsa-cheque-print',
    templateUrl: './cheque-print.component.html',
    styleUrls: ['./cheque-print.component.scss', '../../../shared/datatable/datatable.component.scss']
})
export class ChequePrintComponent implements OnInit {
    @ViewChild('agGrid') agGrid: AgGridNg2;
    title = 'Cheque Print';
    chequeForm: FormGroup;
    paymentType: string;
    payeedataBankName: any = [];
    errorMsg: string;
    isClaims = false;
    isInSpool = true;
    rowData: ChequePrint[] = [];
    selectedVouchersList: ChequePrint[] = [];
    selectedBankCode: number;
    gridApi;
    gridColumnApi;
    paginationOptions: TextValuePair[] = [];
    gridConfiguration: GridOptions = {};
    columnDefs = [];
    frameworkComponents;
    isResults = false;
    chequeStatus: TextValuePair[] = [];
    currentpageSize: number;
    currentPageStart: number;
    currentPageEnd: number;
    totalCount: number;
    // snakbar
    showSnackbar = false;
    showCreateReceiptForm;
    config = {
        backdrop: false,
        ignoreBackdropClick: false,
        class: 'create-modal-dailog'
    };
    constructor(
        public bsModalRef: BsModalRef,
        private modalService: BsModalService,
        private fb: FormBuilder,
        private chequeService: ChequePrintService,
        private masterDataService: MasterDataService,
        private gridservice: ChequePrintGridService,
        private gridApiService: GridApiService

    ) {
        this.getBankData();
        this.paginationOptions = [
            { id: 2, value: '20' },
            { id: 2, value: '100' },
            { id: 3, value: '500' },
            { id: 4, value: '1000' }
        ];

        this.chequeStatus = [
            { id: 0, value: 'In Spool' },
            { id: 1, value: 'Damaged' },
        ];

        this.frameworkComponents = {
            currencyRenderer: CurrencyRendererComponent,
        };
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.gridservice.getColumnHeaderPropertyNames(),
            rowData: this.rowData,
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 20,
            enableRangeSelection: true,
            rowSelection: 'multiple',
            rowMultiSelectWithClick: true,
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            defaultColDef: {
                enableRowGroup: false,
                enableValue: true,
                suppressMovable: true,
                minWidth: 100,
                menuTabs: ['filterMenuTab', '', '']
            },
        };
    }

    ngOnInit() {
        this._buildForm();
        this.gridApiService.isUnCheck().subscribe(() => {
            this.gridConfiguration.api.deselectAll();
        });
        this.currentpageSize = 20;
        this.currentPageStart = 1;

        if (this.rowData.length <= 0) {
            this.currentPageStart = 0;
        }
        if (this.rowData.length <= this.currentpageSize) {

            this.currentPageEnd = this.rowData.length;
        } else {
            this.currentPageEnd = this.currentpageSize;
        }
    }
    _buildForm() {
        this.chequeForm = this.fb.group({
            chequeNumber: ['', Validators.maxLength(12)],
            CountryCode: [1],
            LocationCode: [localStorage.getItem('locationcode')],
            RegionCode: [localStorage.getItem('regioncode')],
            PayeeBankCode: [''],
        });
    }
    onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
    }
    onRowSelected(params) {
        // const isSelect = params.node.isSelected();
        const selectedRows = this.gridApi.getSelectedRows();
        // const currRowData = params.data;
        const count = selectedRows.length;
        this.totalCount = count;
        if (count) {
            this.showSnackbar = true;
            this.selectedVouchersList = selectedRows;

        } else {
            this.showSnackbar = false;
        }
    }
    onPaginationChanged() {
        if (this.gridApi) {
            const currentpage = this.gridApi.paginationGetCurrentPage() + 1;

            this.currentPageStart = (this.currentpageSize * (currentpage - 1)) + 1;
            if (this.rowData.length <= this.currentpageSize * currentpage) {
                this.currentPageEnd = this.rowData.length;
            } else {
                this.currentPageEnd = this.currentpageSize * currentpage;
            }
            if (this.rowData.length <= 0) {
                this.currentPageStart = 0;
            }

        }
    }
    onPageSizeChanged(newPageSize) {
        const value = +(newPageSize.srcElement.value);
        this.gridApi.paginationSetPageSize(value);
        // this.gridApi.sizeColumnsToFit();
        this.currentpageSize = value;
    }
    onBanknameChange(e) {
        const value = +(e.srcElement.value);
        if (value) {
            this.selectedBankCode = value;
            this.getChequeData(this.isClaims, this.isInSpool);
        }
    }
    changeStatus(e) {
        this.close();

        const value = +(e.srcElement.value);
        if (value === 0) {
            if (this.gridColumnApi) {
                this.gridColumnApi.setColumnVisible('VoucherNo', true);
                this.gridColumnApi.setColumnVisible('ChequeNo', false);
                this.gridColumnApi.setColumnVisible('ChequeDate', false);
                this.gridColumnApi.setColumnVisible('VoucherDate', true);
            }
        } else if (value === 1) {
            if (this.gridColumnApi) {
                this.gridColumnApi.setColumnVisible('VoucherNo', false);
                this.gridColumnApi.setColumnVisible('ChequeNo', true);
                this.gridColumnApi.setColumnVisible('ChequeDate', true);
                this.gridColumnApi.setColumnVisible('VoucherDate', false);
            }
        }
        this.isInSpool = value === 0 ? true : false;
        this.getChequeData(this.isClaims, this.isInSpool);
    }
    checkGeneralOrClaims(e) {
        this.isClaims = !this.isClaims;
        console.log(this.isClaims);
        this.getChequeData(this.isClaims, this.isInSpool);
    }
    getBankData() {
        const loccode = localStorage.getItem('locationcode');
        const ccentre = localStorage.getItem('costcentre');
        const totcode = 1110;

        const param = 'locationCode=' + loccode +
            '&totallingAccCode=' + totcode +
            '&costCenter=' + ccentre;
        this.masterDataService.getBankData(param).subscribe(
            dataReturn => {
                this.payeedataBankName = dataReturn;
                this.selectedBankCode = this.payeedataBankName[0].BankCode || null;
                this.getChequeData(this.isClaims, this.isInSpool);
            },
            errorRturn => this.errorMsg = errorRturn
        );
    }
    getChequeData(isClaims: boolean, isInSpool: boolean) {
        const paymenttype = isClaims ? 'ClaimsPayment' : 'GenericPayment';
        const param = 'bankCode=' + this.selectedBankCode + '&paymentType=' + paymenttype;

        this.chequeService.getChequePrintData(param)
            .subscribe(
                dataReturn => {
                    this.rowData = dataReturn;
                    console.log(dataReturn, 'typeof(dataReturn)');
                    if (!isInSpool) {
                        this.rowData = this.rowData.filter(data => data.Status === 'Damaged');
                    }
                    this.isResults = true;
                },
                errorRturn => this.errorMsg = errorRturn
            );
    }

    unSelectCheckbox() {
        this.gridApiService.unCheck();
    }
    buttonHandler() {

        // update cheque status as printed
        const chequeLastNumber = parseInt(this.getFormCtrlValue('chequeNumber'), 0);
        this.setVoucherChequeNumber(chequeLastNumber);
        let selectedIds = '';
        // const userId = localStorage.getItem('userid'); -- taking default as 182
        this.selectedVouchersList.forEach(data => {
            selectedIds = selectedIds + data.VoucherNo.toString() + ',';
        });
        const countrycode = this.getFormCtrlValue('CountryCode');
        const paymenttype = this.isClaims ? 'ClaimsPayment' : 'GenericPayment';
        const param = 'strVoucherNos=' + selectedIds + '&bankCodes=' + this.selectedBankCode + '&paymentTypes=' + paymenttype
            + '&lastChequeNumber=' + chequeLastNumber + '&countryCode=' + countrycode + '&userID=182';

        this.chequeService.ChangeChequePrintPrinted(param).subscribe(data => {
            console.log(data);
        });

        // assign model values
        // tslint:disable-next-line:max-line-length
        this.bsModalRef = this.modalService.show(ChequePrintDialogComponent, { class: 'confirmation-dailog-box modal-md', backdrop: 'static', keyboard: false });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.CHEQUEPRINTSUCCESS;
        this.bsModalRef.content.modelBodyContent = this.totalCount + ' Cheque(s) Printed';
        this.bsModalRef.content.showPrint = true;
        this.bsModalRef.content.showReprint = false;
        this.bsModalRef.content.selectedVouchersList = this.selectedVouchersList;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.yesBtn = RSAMSGConstants.YESTEXT;
        this.bsModalRef.content.printBtn = RSAMSGConstants.PRINTTEXT;
        this.bsModalRef.content.noBtn = RSAMSGConstants.NOTEXT;
        this.bsModalRef.content.chequeNumber = this.chequeForm.get('chequeNumber').value;
        this.bsModalRef.content.paymentType = paymenttype;
        this.bsModalRef.content.countryCode = countrycode;
        this.bsModalRef.content.selectedBankCode = this.selectedBankCode;
        console.log('Name:' + this.chequeForm.get('chequeNumber').value);

        this.bsModalRef.content.valueChange.subscribe((newdata) => {
            // update  grid data
            this.getChequeData(this.isClaims, this.isInSpool);
            this.close();
        });
    }
    close() {
        this.showSnackbar = false;
        this.chequeForm.controls['chequeNumber'].reset();
        this.unSelectCheckbox();
    }
    setVoucherChequeNumber(chequeNumber: number) {
        this.selectedVouchersList.forEach((item, index) => {
            item.ChequeNo = chequeNumber + index + 1;
        });
    }
    getFormCtrlValue(contrlName) {

        return this.chequeForm.controls[contrlName].value;
    }
}
interface TextValuePair {
    id: number;
    value: string;
}
