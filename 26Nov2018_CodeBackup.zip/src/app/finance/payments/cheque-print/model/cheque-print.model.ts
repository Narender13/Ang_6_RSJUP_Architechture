
export interface ChequePrint {
    $id: number;
    VoucherNo: number;
    VoucherDate: Date;
    ChequeNo: number;
    ChequeDate: Date;
    PrintDate: Date;
    Payee: string;
    Particulars: string;
    Amount: number;
    AmountInWords: string;
    Status: string;
}
