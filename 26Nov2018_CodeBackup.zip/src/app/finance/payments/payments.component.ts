import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.scss']
})
export class PaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
