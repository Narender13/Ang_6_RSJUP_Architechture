import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from '../../search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreatePayment } from 'src/app/finance/search/model/create-payment';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreatePaymentService } from 'src/app/finance/payments/create-payment/service/create-payment.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';

@Component({
  selector: 'rsa-create-payment',
  templateUrl: './create-payment.component.html',
  styleUrls: ['./create-payment.component.scss']
})
export class CreatePaymentComponent extends BasevoucherComponent implements OnInit {
  title = 'Payment';
  currency = 'AED';
  errorpayee: boolean;
  errordetail: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  createPayment: CreatePayment;
  animatedClass = true;
  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreatePaymentService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    super.setMinMaxDate();
    console.log('create-payment');
  }


  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.createPaymentForm(this.paymentMode);
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllgetLookupBanksData();
    super.getAllPayeeBankData(true);
    super.getAllDeptData();
    super.getAllProjData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.getBankData(true);
    super.getModelPreviousClose();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (localStorage.getItem('symbol'));
    super.setMinMaxDate();
  }


  /* create entiti form */
  createPaymentForm(param): void {
    this.mainVoucherForm = null;
    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'MM/dd/yyyy')],
      Amount: [''],
      PaymentMode: [this.paymentMode],
      PrintDate: [new DatePipe('en-US').transform(new Date(), 'MM/dd/yyyy')],
      ReceiptType: [0],
      PreparedBy: [1],
      ApprovedBy: [1],
      ModifiedBy: ['1'],
      Approvers: this.fb.array([]),
      CustomerID: [],
      TerminalID: [],
      TerminalUserID: [20],
      TerminalUserName: [],
      CountryCode: [1],
      RegionCode: [localStorage.getItem('regioncode')],
      ReprintNo: [],
      ArabicDescription: [],
      chequeInfo: this.fb.group({
        ChequeNo: ['', Validators.required],
        ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
        PayeeBankCode: [122, Validators.required],
        PayeeBankName: ['dd', Validators.required],
      }),
      bankTransfer: this.fb.group({
        InstrumentRefNo: ['', Validators.required],
        ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
        PayeeBankCode: [122, Validators.required],
        PayeeBankName: ['dd', Validators.required],
      }),
      detailInfo: this.fb.group({
        PayeeName: ['', Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [localStorage.getItem('locationcode')],
        CostCenterCode: [11],
        TotallingAccCode: [1110],
        RecevierBankCode: [14],
      }),
      VoucherDetails: this.fb.array([this.createPaymentArrayGroup()])
    });
  }


  /* form array for recept details */
  createPaymentArrayGroup(): FormGroup {
    return this.fb.group({
      CounterPartyRef: [],
      LocationCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      CountryCode: [1],
      CostCenterCode: [localStorage.getItem('costcentre')],
      Description: [],
      Amount: ['', Validators.required],
      RefTransactionID: [],
      RefTransactionType: [3],
      IsCreditEntry: [false],
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: ['1'],
      ReceiptDate: [],
      AnalysisCode: [],
      DepartmentCode: [],
      Department: [],
      RefTransactionSerialNo: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      // ClassCode: [],
      PolicyYear: [],
      PolicyType: []
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createPaymentForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1110');
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('14');
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );

    /* for cheque */
    if (this.payeebankcodeCheque != null && this.payeebankcodeCheque !== undefined) {
      this.payeebankcodeCheque.statusChanges.subscribe(
        status => {
          this.errorbankcodeCheque = (status === 'INVALID');
        }
      );
    }

    if (this.chequedateCheque != null && this.chequedateCheque !== undefined) {
      this.chequedateCheque.statusChanges.subscribe(
        status => {
          this.errorchequedateCheque = (status === 'INVALID');
        }
      );
    }


    if (this.chequeno != null && this.chequeno !== undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequenoCheque = (status === 'INVALID');
        }
      );
    }

    if (this.payeebanknameCheque != null && this.payeebanknameCheque !== undefined) {
      this.payeebanknameCheque.statusChanges.subscribe(
        status => {
          this.errorpaayeebanknameCheque = (status === 'INVALID');
        }
      );
    }


    /* for banktransfer */

    if (this.chequedateBankT != null && this.chequedateBankT !== undefined) {
      this.chequedateBankT.statusChanges.subscribe(
        status => {
          this.errorchequedateBankT = (status === 'INVALID');
        }
      );
    }


    if (this.payeebankcodeBankt != null && this.payeebankcodeBankt !== undefined) {
      this.payeebankcodeBankt.statusChanges.subscribe(
        status => {
          this.errorbankcodeBanktransfer = (status === 'INVALID');
        }
      );
    }

    if (this.payeebanknameBankt != null && this.payeebanknameBankt !== undefined) {
      this.payeebanknameBankt.statusChanges.subscribe(
        status => {
          this.errorpaayeebanknameBanktransfer = (status === 'INVALID');
        }
      );
    }

    if (this.expirydate != null && this.expirydate !== undefined) {
      this.expirydate.statusChanges.subscribe(
        status => {
          this.errorexpirydate = (status === 'INVALID');
        }
      );
    }

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcodeCheque = false;
    this.errorbankcodeBanktransfer = false;
    this.errorpaayeebanknameCheque = false;
    this.errorpaayeebanknameBanktransfer = false;
    this.errorchequedateCheque = false;
    this.errorchequedateBankT = false;
    this.errorchequedateCreditCard = false;
    this.errorchequenoCheque = false;
    this.errorterminalID = false;
    this.errorexpirydate = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  get payeebankcodeCheque() {
    return this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode;
  }
  get payeebankcodeBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode;
  }
  get payeebanknameCheque() {
    return this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankName;
  }
  get payeebanknameBankt() {
    return this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName;
  }
  get chequedateCheque() {
    return (this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate);
  }
  get chequedateBankT() {
    return (this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate);
  }
  get instrumentrefnoBankT() {
    return (this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo);
  }
  get expirydate() { return this.mainVoucherForm.get('ExpiryDate'); }
  get chequeno() {
    return this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo;
  }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }

  /* go next valiadtion depending on receipt mode   */
  goNext() {
    if (this.paymentMode == 1) {
      this.errorpayee = this.cshpayeename.invalid;
      console.log(this.errorpayee, 'errorpayee');
      this.errordetail = this.cshdetails.invalid;
      console.log(this.errordetail, 'errordetail');
      if (!this.errorpayee && !this.errordetail) {
        this.level = 2;
        this.setDescription();
        super.getTotallingDetailData({ index: 0, flag: true });
      }
    }

    if (this.paymentMode == 2) {
      this.errorpayee = this.cshpayeename.invalid;
      console.log(this.errorpayee);
      this.errordetail = this.cshdetails.invalid;

      if (this.payeebankcodeCheque != null && this.payeebankcodeCheque !== undefined) {
        this.errorbankcodeCheque = this.payeebankcodeCheque.invalid;
        console.log(this.payeebankcodeCheque.invalid, 'this.payeebankcode.invalid');
      }

      if (this.chequedateCheque != null && this.chequedateCheque !== undefined) {
        this.errorchequedateCheque = this.chequedateCheque.invalid;
      }

      if (this.chequeno != null && this.chequeno !== undefined) {
        this.errorchequenoCheque = this.chequeno.invalid;
      }
      if (!this.errorpayee && !this.errordetail && !this.errorbankcodeCheque &&
        !this.errorchequedateCheque && !this.errorchequenoCheque) {
        this.level = 2;
        this.setDescription();
        super.getTotallingDetailData({ index: 0, flag: true });
      }
    }


    if (this.paymentMode == 5) {
      this.errorpayee = this.cshpayeename.invalid;
      console.log(this.errorpayee);
      this.errordetail = this.cshdetails.invalid;

      if (this.chequedateBankT != null && this.chequedateBankT !== undefined) {
        this.errorchequedateBankT = this.chequedateBankT.invalid;
        console.log(this.errorchequedateBankT, 'this.payeebankcode.invalid');
      }

      if (this.payeebankcodeBankt != null && this.payeebankcodeBankt !== undefined) {
        this.errorchequedateBankT = this.payeebankcodeBankt.invalid;
      }

      if (this.payeebanknameBankt != null && this.payeebanknameBankt !== undefined) {
        this.errorpaayeebanknameBanktransfer = this.payeebanknameBankt.invalid;
      }
      if (!this.errorpayee && !this.errordetail && !this.errorchequedateBankT &&
        !this.errorchequedateBankT && !this.errorpaayeebanknameBanktransfer) {
        this.level = 2;
        this.setDescription();
        super.getTotallingDetailData({ index: 0, flag: true });

      }
    }

  }

  /* add receipt in review screen */
  addReceipt(len) {
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
    if (CurrentAmount > 0) {
      control.push(this.createPaymentArrayGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      this.dtltotallingacc[len] = this.cachedDtlTot;
      this.glaccount[len] = this.cachedGL;
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }



  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.reset([localStorage.getItem('locationcode')]);
      this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.reset([localStorage.getItem('costcentre')]);
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.reset([1110]);
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.reset([14]);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);

      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([localStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([localStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });
      this.getSum();
    }
  }




  /* update  form values to create-receipt objects*/
  upDateCreatePaymentValues() {
    this.createPayment = new CreatePayment();
    const mainFormFieldArray = ['VoucherDate', 'Amount', 'PaymentMode', 'PrintDate', 'ReceiptType',
      'PreparedBy', 'ModifiedBy', 'ApprovedBy', 'CustomerID', 'TerminalUserID', 'TerminalUserName',
      'CountryCode', 'ArabicDescription', 'Approvers'];
    mainFormFieldArray.forEach(item => {
      this.createPayment[item] = this.mainVoucherForm.controls[item].value;
    });
    this.createPayment.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createPayment.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createPayment.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createPayment.RecevierBankCode = this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.value;
    this.createPayment.Name = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createPayment.E_Desc = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createPayment.PmtDetails = this.mainVoucherForm.controls['VoucherDetails'].value;

    if (this.paymentMode == 2) {
      this.createPayment.ChequeNo = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeNo.value;
      this.createPayment.ChequeDate = this.mainVoucherForm.controls.chequeInfo['controls'].ChequeDate.value;
      this.createPayment.PayeeBankCode = this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode.value;
      this.createPayment.PayeeBankName = this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankName.value;
    }

    if (this.paymentMode == 5) {
      this.createPayment.InstrumentRefNo = this.mainVoucherForm.controls.bankTransfer['controls'].InstrumentRefNo.value;
      this.createPayment.ChequeDate = this.mainVoucherForm.controls.bankTransfer['controls'].ChequeDate.value;
      this.createPayment.PayeeBankCode = this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode.value;
      this.createPayment.PayeeBankName = this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankName.value;
    }
  }

  /* create-receipt form*/
  submitForm() {
    super.validateDetailInfo();
    this.upDateCreatePaymentValues();
    console.log(this.createPayment, ' this.createPayment');
    if (this.glerrorcount > 0) {
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    if (this.totalAmount > 0) {
      if (this.totalAmount > 99999 && !this.usersReq) {
        return false;
      }
      if(this.prevPreviewID == null || this.prevPreviewID==undefined)
      this.prevPreviewID=0;
      this.createPayment["VoucherNo"]=this.prevPreviewID;

      this.createPaymentService.createPayment(JSON.stringify(this.createPayment)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          console.log(dataReturn);
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          console.log(this.returnValue, 'this.returnValue');
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(PaymentpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }
  }



}
