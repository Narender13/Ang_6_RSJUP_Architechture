import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpErrorResponse, HttpClient } from '@angular/common/http';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { RSAENDPOINTConstants } from '../../../../core/constants/rsa.api.end.points';
import { handleErrorObservable } from '../../../../shared/utilites/helper';


@Injectable({ providedIn: 'root' })
export class CreatePaymentService {
    private cachedMasterData: Observable<any>;
    private httpheaders = new HttpHeaders(
        {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Headers': 'Content-Type,Origin,content-type',
            'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Origin': '*'
        });

    constructor(private http: HttpClient) { }


    createPayment(param: any) {
        console.log(param, 'param');
        return this.http.post<any>(RSAENDPOINTConstants.CREATEPAYMENT, param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createPayment')));
    }

    cancelPayment(param) {
        const body = JSON.stringify(param);
        console.log(body, 'body');
        return this.http.post(RSAENDPOINTConstants.RECEIPTCANCEL, body, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('cancelPayment')));
    }

    savePayment(param) {
        const body = JSON.stringify({ 'vocherNo': param });
        const url = RSAENDPOINTConstants.SAVEPAYMENT + param;
        console.log(url, 'url');
        return this.http.post<any>(url, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('savePayment')));
    }

    sendEmail(param) {
        console.log(param);
        const body = JSON.stringify(param);
        const url = RSAENDPOINTConstants.RECEIPTEMAIL;
        console.log(url, 'url');
        return this.http.post<any>(url, body, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('sendEmail')));
    }


}
