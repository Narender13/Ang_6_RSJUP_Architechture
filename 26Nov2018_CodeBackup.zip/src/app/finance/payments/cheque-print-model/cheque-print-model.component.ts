import { Component, Input, ViewChild, EventEmitter, OnInit, Output, ElementRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ChequePrintService } from '../cheque-print/service/cheque-print.service';
import { ChequePrint } from '../cheque-print/model/cheque-print.model';
@Component({
    selector: 'app-chque-print-dialog',
    templateUrl: './cheque-print-model.component.html',
    styleUrls: ['./cheque-print-model.component.scss']
})
export class ChequePrintDialogComponent implements OnInit {
    noBtn: string;
    yesBtn: string;
    cancelBtn: string;
    printBtn: string;
    modelTitle: string;
    modelBodyContent: string;
    smallMessage: string;
    comment: string;
    chequeNumber: number;
    showPrint: boolean;
    showReprint: boolean;
    reprintPopup = false;
    chequeReprintForm: FormGroup;
    errorMsg: string;
    selectedVouchersList: ChequePrint[];
    selectedChequesList = [];
    paymentType: string;
    countryCode: number;
    selectedBankCode: string;
    @Output() valueChange = new EventEmitter();

    constructor(
        private fb: FormBuilder,
        private chequeService: ChequePrintService,
        public bsModalRef: BsModalRef) { }
    ngOnInit() {
        this.createForm();
    }
    get repchequenumber() { return this.chequeReprintForm.get('ChequeNumber'); }
    get repcomments() { return this.chequeReprintForm.get('Comment'); }
    createForm(): void {
        this.chequeReprintForm = this.fb.group({
            ChequeNumber: ['', Validators.maxLength(12)],
            Comment: ['', Validators.maxLength(500)],
        });
    }
    valueChanged(e) {
        this.valueChange.emit(e.srcElement.innerText);
        this.bsModalRef.hide();
    }
    reSetForm(): void {
        this.chequeReprintForm.controls['ChequeNumber'].reset();
        this.chequeReprintForm.controls['Comment'].reset();
    }
    showPrintDialog(): void {
        this.showPrint = true;
        this.showReprint = false;
        this.chequeNumber = this.chequeReprintForm.get('ChequeNumber').value;
        // update printed
        const chequeLastNumber = parseInt(this.chequeNumber.toString(), 0);
        this.setVoucherChequeNumber(chequeLastNumber);
        let selectedIds = '';
        // const userId = localStorage.getItem('userid'); -- taking default as 182
        this.selectedVouchersList.forEach(data => {
            selectedIds = selectedIds + data.VoucherNo.toString() + ',';
        });
        const param = 'strVoucherNos=' + selectedIds + '&bankCodes=' + this.selectedBankCode + '&paymentTypes=' + this.paymentType
            + '&lastChequeNumber=' + chequeLastNumber + '&countryCode=' + this.countryCode + '&userID=182';

        this.chequeService.ChangeChequePrintPrinted(param).subscribe(data => {
            console.log(data);
        });

    }
    showRePrintDialog(): void {
        this.showPrint = false;
        this.showReprint = true;
    }
    updateSelectedList(e, item, index) {
        console.log('item', item);
        const isCheckBoxSelect = e.srcElement.checked;
        if (isCheckBoxSelect) {
            this.selectedChequesList.push({ item: item, i: index });
            console.log(this.selectedChequesList, 'selectedChequesList');
        } else {
            this.selectedChequesList.splice(index, 1);
        }
    }
    updateDamagedCheques(): void {
        console.log(this.selectedChequesList, 'selectedDamagedChequesList');
        this.reprintPopup = true;

        const selectedIds = this.selectedChequesList.map(data => data.item.VoucherNo);

        const param = {
            VoucherNos: selectedIds || 0,
            paymentType: this.paymentType
        };
        this.chequeService.ChangeChequePrintDamaged(param).subscribe(data => {
            this.valueChange.emit('damaged');
        });
    }
    setVoucherChequeNumber(chequeNumber: number) {
        this.selectedVouchersList.forEach((item, index) => {
            item.ChequeNo = chequeNumber + index + 1;
        });
    }
}
