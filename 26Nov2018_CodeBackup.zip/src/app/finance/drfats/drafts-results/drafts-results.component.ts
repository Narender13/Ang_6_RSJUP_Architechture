import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DrfatService } from './services/drafts.service';

@Component({
  selector: 'rsa-drafts-results',
  templateUrl: './drafts-results.component.html',
  styleUrls: ['./drafts-results.component.scss']
})
export class DraftsResultsComponent implements OnInit {
  voucherName;
  voucherCount;
  receiptDraftsData: any = [];
  constructor(private route: ActivatedRoute, private drfatService: DrfatService) { }

  ngOnInit() {
    this.getDrfatsReceipt();
    this.route.queryParams.subscribe(params => {
      console.log(params);
      this.voucherName = params['voucherName'];
      this.voucherCount = params['voucherCount'];
    });
  }

  getDrfatsReceipt() {
    const locCode = localStorage.getItem('locationcode');
    const param = 'locationCode=' + locCode;
    this.drfatService.getDraftReceipts(param).subscribe(data => {
      this.receiptDraftsData = data;
      console.log(data, 'data');
    });
  }

}
