import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { Customvalidators } from 'src/app/shared/validators/customvalidators';
import { SharedService } from 'src/app/finance/services/shared.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';

@Component({
  selector: 'rsa-create-draft-receipt',
  templateUrl: './create-draft-receipt.component.html',
  styleUrls: ['./create-draft-receipt.component.scss']
})
export class CreateDraftReceiptComponent implements OnInit {
  title = 'Receipt';
  level: any = 1;
  amount;
  currency = 'AED';
  collapsetoheader: boolean;
  receiptForm: FormGroup;
  BankName: any;
  results: any;
  errorMsg;
  terminals;
  slided;
  returnValue;
  count;
  branchdata: any = [];
  users: any = [];
  RcptMode;
  selectedRowEntitiDataTable = [];
  getbankterminaldetails = {};
  payeedataBankName: any = [];
  receiverdataBankName: any = [];
  pjctindicator: any = [];
  department: any = [];
  placeholder: any;
  glaccount: any = [];
  totallingacc: any = [];
  transactiontype: any = [];
  private masterdata: any = [];
  private masterdata2: any = [];
  costcentredata = [];
  displayApprover = false;
  approverusers: string;
  totalAmount;
  glerrorcount = 0;
  setcredit = true;
  totalSum = 0;
  dtltotallingacc = [];
  symbol: string;
  arrUser: any = [];
  paymentname = 'CASH';
  usersReq = true;
  errorpayee: boolean;
  errordetail: boolean;
  errorbankcode: boolean;
  errorchequedate: boolean;
  errorchequeno: boolean;
  errorinstrumentrefno: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  minDate;
  total;
  minDateRd;
  maxDateRd;
  isDisabled = true;
  setPayeeName;
  currentTbIndex = 0;
  previewFlag: boolean = false;
  cachedPayeeBankData: any;
  cachedDtlTot: any;
  cachedGL;
  prevReceipt: any;
  previewDataDtl: any = [];
  receiptEditData: any;
  ReceiptModeDesc;
  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(
    private ref: ChangeDetectorRef,
    public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private createservice: CreateService,
    private masterDataService: MasterDataService,
    private modalService: BsModalService,
    private gridApiService: GridApiService,
    private alertService: AlertService,
    private sharedService: SharedService,
    private router: Router) {
    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);
  }


  ngOnInit() {
    this.getReceiptData();
  }



  getReceiptData() {
    this.RcptMode = this.receiptEditData.ReceiptMode;
    this.prevReceipt = this.receiptEditData.ReceiptNo; 
    const currentIndex = {
      '2': 0,
      '1': 2,
      '8': 1,
      '5': 3,
    };
    const selectedTab = currentIndex[this.RcptMode];
    console.log(selectedTab, 'setectedtab');
    if (this.RcptMode) {
      this.tabset.tabs[selectedTab].active = true;
      this.createReceiptEntitiRowSForm(this.RcptMode);
      this.getAllMasterData(1110);
      this.getAllMasterData2();
      this.getTotallingData(localStorage.getItem('costcentre'));
      this.getBankData(1110);
      this.symbol = (localStorage.getItem('symbol'));
      console.log(this.receiptEditData, 'this.receiptEditData');
      this.getModalFromPrevious();
      this.fieldStatusChanges();
      this.getPayeeBankData(true);
      const receiptDesc = this.receiptEditData.ReceiptModeDesc;
      this.totalAmount = this.receiptEditData.TotalAmount;
      console.log(this.totalAmount, 'totalAmount3244324');
      this.patchValueFromDrft();
      console.log(this.receiptEditData.ReceiptMode, 'receiptEditData');
      this.receiptEditData.ReceiptDetails.map((item, index) => this.addReceipt(item, (index + 1), false));
    }
    this.tabset.tabs[selectedTab].active = true;

  }

  patchValueFromDrft() {
    if (this.receiptEditData) {
      console.log(this.receiptEditData.PayeeName, 'this.receiptEditData.PayeeName');
      if (this.receiptEditData.ReceiptMode == 2) {
        console.log('anki2');
        this.receiptForm.patchValue({
          ChequeNo: this.receiptEditData.ChequeNo,
          ChequeDate: this.receiptEditData.ChequeDate,
          PayeeBankCode: this.receiptEditData.PayeeBankCode,
        });
      }
      if (this.receiptEditData.ReceiptMode == 5) {
        console.log('anki5');
        this.receiptForm.patchValue({
          ChequeDate: this.receiptEditData.ChequeDate,
          PayeeBankCode: this.receiptEditData.PayeeBankCode,
          InstrumentRefNo: this.receiptEditData.InstrumentRefNo,
        });
      }
      if (this.receiptEditData.ReceiptMode == 1) {
        console.log('anki1');
        this.receiptForm.patchValue({
          PayeeName: this.receiptEditData.PayeeName,
          EnglishDescription: this.receiptEditData.EnglishDescription,
        });
      }
      if (this.receiptEditData.ReceiptMode == 8) {
        this.receiptForm.patchValue({
          ChequeNo: this.receiptEditData.ChequeNo,
          ChequeDate: this.receiptEditData.ChequeDate,
          InstrumentRefNo: this.receiptEditData.InstrumentRefNo,
          TerminalID: this.receiptEditData.TerminalID,
        });
      }
      this.receiptForm.patchValue({
        ReceiptDate: this.receiptEditData.ReceiptDate,
        PayeeName: this.receiptEditData.PayeeName,
        EnglishDescription: this.receiptEditData.EnglishDescription,
        TotallingAccCode: this.receiptEditData.TotallingAccCode,
        RecevierBankCode: this.receiptEditData.RecevierBankCode,
        ReceiptMode: this.receiptEditData.ReceiptMode,
        PrintDate: this.receiptEditData.PrintDate,
        ReceiptType: this.receiptEditData.ReceiptType,
        PreparedBy: this.receiptEditData.PreparedBy,
        ModifiedBy: this.receiptEditData.ModifiedBy,
        CustomerID: this.receiptEditData.CustomerID,
        TerminalUserID: this.receiptEditData.TerminalUserID,
        TerminalUserName: this.receiptEditData.TerminalUserName,
        CountryCode: this.receiptEditData.CountryCode,
        LocationCode: this.receiptEditData.LocationCode,
        RegionCode: this.receiptEditData.RegionCode,
        ReprintNo: this.receiptEditData.ReprintNo,
        CostCenterCode: this.receiptEditData.CostCenterCode,
        ArabicDescription: this.receiptEditData.ArabicDescription,
      });
    }
  }

  doPatchRefFields() {
    let formarray = (<FormArray>this.receiptForm.controls['ReceiptDetails']);
    formarray.controls.map((item, index) => {
      item.get("RefTransactionID").setValue(this.previewDataDtl[index].RefTransactionID);
      item.get("RefTransactionSerialNo").setValue(this.previewDataDtl[index].RefTransactionSerialNo);
    });
  }
  getModalFromPrevious() {
    this.sharedService.getMessage().subscribe(val => {
      if (val === 'previous') {
        this.previewFlag = false;
      } else if (val === 'close') {
        this.modalService.hide(1);
      }

      if (this.prevReceipt == null || this.prevReceipt == undefined || this.prevReceipt == 0){
        this.prevReceipt = val.id;
       } 

      this.prevReceipt = val.id;
      console.log(this.prevReceipt, 'this.prevReceipt');
      this.previewDataDtl = val.data;
      if (this.previewDataDtl != null || this.previewDataDtl != undefined) {
        this.doPatchRefFields();
      }
    });
  }
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcode = false;
    this.errorchequedate = false;
    this.errorchequeno = false;
    this.errorinstrumentrefno = false;
    this.errorterminalID = false;
    this.errorexpirydate = false;
  }

  getPayeeBankData(initFlag) {
    const param = this.getFormCtrlValue('LocationCode');
    this.masterDataService.getPayeeBankData(param).subscribe(
      dataReturn => {
        this.payeedataBankName = dataReturn;
        // this.receiptForm.controls['PayeeBankCode'].setValue(this.payeedataBankName[0].BankCode);
        if (initFlag) {
          this.cachedPayeeBankData = dataReturn;
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  setFormArrayCTRLDefaultValue(contrlname, index, val) {
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].get(contrlname).setValue(val);
  }
  getFromFormArrayControlVal(contrlname, index) {
    return (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[index].get(contrlname).value;
  }
  getFormCtrlValue(contrlName) {
    console.log(this.receiptForm.controls, 'this.receiptForm.controls');
    return this.receiptForm.controls[contrlName].value;
  }


  getTotallingDetailData(index, initFlag) {
    let loccode = this.getFromFormArrayControlVal('BranchCode', index);
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);

    const param = 'locationCode=' + loccode +
      '&paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingDetailData(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;
        //alert(this.dtltotallingacc[index][0]);
        let totcode = this.dtltotallingacc[index][0].TotAccCode;
        if (!initFlag)
          this.setFormArrayCTRLDefaultValue("TotallingAccCode", index, totcode);
        if (initFlag) {
          this.cachedDtlTot = dataReturn;
        }
        this.getGLData(index, initFlag, totcode);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    if (this.payeebankcode != null && this.payeebankcode !== undefined) {
      this.payeebankcode.statusChanges.subscribe(
        status => {
          this.errorpayee = (status === 'INVALID');
        }
      );
    }
    if (this.chequedate != null && this.chequedate !== undefined) {
      this.chequedate.statusChanges.subscribe(
        status => {
          this.errorchequedate = (status === 'INVALID');
        }
      );
    }
    if (this.chequeno != null && this.chequeno !== undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequeno = (status === 'INVALID');
        }
      );
    }
    // if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
    //   this.instrumentrefno.statusChanges.subscribe(
    //     status => {
    //       this.errorinstrumentrefno = (status === 'INVALID');
    //     }
    //   );
    // }
    if (this.terminalid != null && this.terminalid !== undefined) {
      this.terminalid.statusChanges.subscribe(
        status => {
          this.errorterminalID = (status === 'INVALID');
        }
      );
    }
    if (this.expirydate != null && this.expirydate !== undefined) {
      this.expirydate.statusChanges.subscribe(
        status => {
          this.errorexpirydate = (status === 'INVALID');
        }
      );
    }

  }

  goNext() {
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;

    if (this.payeebankcode != null && this.payeebankcode !== undefined) {
      this.errorbankcode = this.payeebankcode.invalid;
      console.log(this.payeebankcode.invalid, 'this.payeebankcode.invalid');
    }

    if (this.chequedate != null && this.chequedate !== undefined) {
      this.errorchequedate = this.chequedate.invalid;
    }

    if (this.chequeno != null && this.chequeno !== undefined) {
      this.errorchequeno = this.chequeno.invalid;
    }
    // if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
    //   this.errorinstrumentrefno = this.instrumentrefno.invalid;
    // }
    if (this.terminalid != null && this.terminalid !== undefined) {
      this.errorterminalID = this.terminalid.invalid;
    }

    if (this.expirydate != null && this.expirydate !== undefined) {
      this.errorexpirydate = this.expirydate.invalid;
    }
    console.log(this.errorpayee, 'errorpayee');
    console.log(this.errordetail, 'errorpayee');
    console.log(this.errorchequedate, 'errorpayee');
    console.log(this.errorchequeno, 'errorpayee');
    console.log(this.errorterminalID, 'errorpayee');
    console.log(this.errorexpirydate, 'errorpayee');

    if (!this.errorpayee && !this.errordetail && !this.errorchequedate && !this.errorchequeno
      && !this.errorterminalID && !this.errorexpirydate) {
      this.level = 2;
      // this.getGLData(1110, 0);
      // this.getTotallingDetailData(localStorage.getItem('costcentre'), 0);
    }
  }





  setPayeName() {
    this.receiptForm.controls['PayeeName'].setValue(this.setPayeeName);
  }

  setReceiptMode(val, paymentname) {
   // alert(val + "," + paymentname);
    //this.receiptForm.controls['ReceiptMode'].setValue(val);
    this.RcptMode = val;
    this.paymentname = paymentname;
    console.log(this.RcptMode, 'set');
    this.createReceiptEntitiRowSForm(this.RcptMode);
    this.payeedataBankName = this.cachedPayeeBankData;
    this.setcurrentTbIndex(paymentname);
    this.fieldStatusChanges();
  }


  getSum() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.receiptForm.controls['ReceiptDetails'];
    ctrl.controls.forEach(val => {
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value) ||
        val.get('Amount').value == '') ? 0 : val.get('Amount').value;
      this.totalAmount += parseFloat(amt);
    });

    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;

  }
  getGLData(index, initFlag, val) {
    let loccode = this.getFromFormArrayControlVal('BranchCode', index);
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);
    let totcode = (initFlag) ? this.getFromFormArrayControlVal('TotallingAccCode', index) : val;

    let param = 'locationCode=' + loccode +
      '&totallingAccCode=' + totcode +
      '&CostCenterCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getGLData(param).subscribe(
      dataReturn => {
        this.glaccount[index] = dataReturn;
        console.log(this.glaccount, 'glacount');
        if (!initFlag)
          this.setFormArrayCTRLDefaultValue("GLCode", index, this.glaccount[index][0].GLCode);
        this.setFormArrayCTRLDefaultValue("GLCodeDesc", index, this.glaccount[index][0].GLEngDescription);
        if (initFlag) this.cachedGL = dataReturn;
        console.log(this.cachedGL, 'cachedGL');
      },
      errorRturn => this.errorMsg = errorRturn
    );
    if (this.level == 2) {
      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map(item => {
        // item.get('Amount').clearValidators();
        // item.get('GLCode').clearValidators();
        item.get('Amount').updateValueAndValidity();
        item.get('GLCode').updateValueAndValidity();
      });
    }
  }


  setBankData(val) {
    this.receiptForm.controls['RecevierBankCode'].setValue('');
    this.getBankData(val);
  }
  getBankData(totAcc) {
    console.log(totAcc, 'totAcc');
    const param = 'locationCode=' + localStorage.getItem('locationcode') +
      '&totallingAccCode=' + totAcc +
      '&costCenter=' + localStorage.getItem('costcentre');
    this.masterDataService.getBankData(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getTotallingData(val) {
    const param = 'locationCode=' + localStorage.getItem('locationcode') +
      '&paymentMode=' + this.paymentname +
      '&costCenter=' + val;

    this.masterDataService.getTotallingData(param).subscribe(
      dataReturn => {
        this.totallingacc = dataReturn;
        console.log(this.totallingacc, 'this.totallingacc');
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  getAllMasterData(totalacc): void {
    this.masterDataService.getAllMasterData(totalacc).subscribe(
      dataReturn => {
        this.masterdata = dataReturn;
        console.log(dataReturn, ' : master data');
        this.payeedataBankName = this.masterdata.LoadPayeeBanks;
        this.terminals = this.masterdata.Terminals;
        this.pjctindicator = this.masterdata.ProjectIndicators;
        this.department = this.masterdata.Departments;
        console.log(this.department, 'd');
        console.log(this.pjctindicator, 'p');
        console.log(this.terminals, 't');
        this.transactiontype = this.masterdata.TransactionType;

      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getAllMasterData2(): void {
    this.masterDataService.getAllMasterData2().subscribe(
      dataReturn => {
        this.masterdata2 = dataReturn;
        console.log(dataReturn, ' : master data');
        this.glaccount = this.masterdata2.GLCodes;
        this.users = this.masterdata2.Users;
        this.branchdata = this.masterdata2.Locations;
        this.costcentredata = this.masterdata2.CostCenter;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  onUserChange(userid: string, isChecked: boolean, username: string) {
    const userFormArray = <FormArray>this.receiptForm.controls.Approvers;
    if (isChecked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value === userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
    }
    this.approverusers = this.arrUser.join();
    console.log(this.approverusers);
  }


  createReceiptEntitiRowSForm(param): void {
    this.receiptForm = null;
    this.receiptForm = this.fb.group({
      ReceiptDate: [],
      ReceiptMode: [],
      PrintDate: [],
      ReceiptType: [],
      PreparedBy: [],
      ModifiedBy: [],
      InstrumentRefNo: [],
      Approvers: this.fb.array([]),
      CustomerID: [],
      TerminalID: [],
      TerminalUserID: [],
      TerminalUserName: [],
      CountryCode: [],
      LocationCode: [11],
      RegionCode: [],
      ReprintNo: [],
      CostCenterCode: [],
      ArabicDescription: [],
      TotallingAccCode: [],
      RecevierBankCode: [],
      PayeeName: ['', Validators.required],
      EnglishDescription: ['', Validators.required],
      ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
      ReceiptDetails: this.fb.array(this.selectedRowEntitiDataTable.map(item => {
        console.log(item, 'item');
        const group = this.entitiRowSelectionFormGroup();
        group.patchValue(item);
        return group;
      }))
      // ReceiptDetails: this.fb.array([this.getdetails()])
    });
    switch (param) {
      case 1:
        this.receiptForm.addControl('Amount', new FormControl(''));
        break;
      case 2:
        this.receiptForm.addControl('ChequeNo', new FormControl('', Validators.required));
        this.receiptForm.controls['ChequeNo'].updateValueAndValidity();
        this.receiptForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.receiptForm.controls['ChequeDate'].updateValueAndValidity();
        this.receiptForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.receiptForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankName'].updateValueAndValidity();
        break;
      case 8:
        this.receiptForm.addControl('ChequeNo', new FormControl('', [Validators.required, Customvalidators.creditcardValidator]));
        this.receiptForm.controls['ChequeNo'].updateValueAndValidity();
        this.receiptForm.addControl('InstrumentRefNo', new FormControl(''));
        //this.receiptForm.controls['InstrumentRefNo'].updateValueAndValidity();
        this.receiptForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.receiptForm.controls['ChequeDate'].updateValueAndValidity();
        this.receiptForm.addControl('TerminalID', new FormControl('', Validators.required));
        this.receiptForm.controls['TerminalID'].updateValueAndValidity();
        break;
      case 5:
        this.receiptForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.receiptForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.receiptForm.controls['PayeeBankName'].updateValueAndValidity();
        this.receiptForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.receiptForm.controls['ChequeDate'].updateValueAndValidity();
        this.receiptForm.addControl('InstrumentRefNo', new FormControl(''));
        //this.entitiRowSelectionForm.controls['InstrumentRefNo'].updateValueAndValidity();

        break;
    }
  }


  entitiRowSelectionFormGroup(): FormGroup {
    return this.fb.group({
      CounterPartyReferenceNo: [],
      LocationCode: [],
      BranchCode: [],
      LocationDesc: [],
      RefTransactionName: [],
      CountryCode: [],
      CostCenterCode: [],
      ClassCode: [],
      CostCenterName: [],
      CounterPartyRef: [],
      TotallingAccName: [],
      Class: [],
      Description: [],
      Amount: ['', Validators.required],
      Amt: [],
      LocationName: [],
      RefTransactionID: [],
      IsCreditEntry: [],
      RefTransactionType: [],
      RefTranTypeDesc: [],
      RefTranType: [],
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: [],
      ReceiptDate: [],
      AnalysisCode: [],
      DepartmentCode: [],
      DepartmentName: [],
      RefTransactionSerialNo: [],
      PlaceHolderCode: [],
      GLCode: ['', Validators.required],
      GLCodeDesc: ['', Validators.required],
      GLAccountName: [],
      GLAccount: [],
      RegionCode: [],
      TotallingAccCode: [],
      ClaimID: [],
      VoucherType: [],
      TransactionNo: [],
      PolicyYear: [],
      PolicyType: [],
      VoucherNo: [],
      RefPolicyNo: [],
      RefPolicyYear: [],
      ReferenceID1: [],
      ReferenceID2: [],
      // Aaded new formControlName to make row readonly if coming from selection rows
      newAddedRow: false
    });
  }


  setHiddenValue(ev, iter, key, setKey) {
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.item[setKey]);
  }
  setCreditEntry(ev, iter, key, data) {
    const actualData = Number(data.controls['Amount'].value);
    const curdata = -(data.controls['Amount'].value);
    data.controls['Amount'].patchValue(curdata);
    this.getSum();
    if (actualData === 0 || actualData === undefined) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.EMPTYAMOUNTCHECK;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      ev.target.checked = true;

    }
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.target.checked);
    if (this.totalAmount < 0) {
      ev.target.checked = true;
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CREDITEXCEEDMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      data.controls['Amount'].patchValue(-curdata);
      this.getSum();
    }
  }


  // setting current Tab Index to activiate tab
  setcurrentTbIndex(tab) {
    switch (tab) {
      case 'Cash':
        this.currentTbIndex = 2;
        break;
      case 'Cheque':
        this.currentTbIndex = 0;
        break;
      case 'Credit Card':
        this.currentTbIndex = 1;
        break;
      case 'Bank Transfer':
        this.currentTbIndex = 3;
    }
  }
  // Displaying the  confirmation alert on tab click
  confirmTabSwitch(event) {
    console.log(event.target.tagName);
    const parentElement = event.target.parentElement;
    const target = event.target.parentElement.text;
    if (event.target.tagName === 'SPAN' && !parentElement.classList.contains('active') && parentElement.classList.contains('nav-link')) {
      if (this.receiptForm.dirty) {
        // --- showing popup only you have added or changed something
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        // Will move the content to RSAMSGConstants once approved // 
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.PAYMENTMODECHANGEMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          console.log(data);
          // changing the currentTbIndex if user proceed
          if (data = RSAMSGConstants.BTNPROCEED) {
            console.log(this.currentTbIndex);
            setTimeout(() => {
              this.setcurrentTbIndex(target);
            }, 0);
            setTimeout(() => {
              this.tabset.tabs.forEach(item => {
                if (item.heading == target) {
                  item.active = true;
                }
              });
            }, 1);
          }
        });
      } else {
        setTimeout(() => {
          this.setcurrentTbIndex(target);
        }, 0);
        setTimeout(() => {
          this.tabset.tabs.forEach(item => {
            if (item.heading == target) {
              item.active = true;
            }
          });
        }, 1);

      }

    }
  }


  setTerminalCode(ev, key, setKey) {
    console.log(ev, 'ev');
    this.receiptForm.controls[key].setValue(ev.item[setKey]);
  }
  setBankCode(ev, iter, key) {
    this.receiptForm.controls[key].setValue(ev.item.BankCode);
  }



  addReceipt(item, len?, newAdded?) {
    const control = <FormArray>this.receiptForm.controls['ReceiptDetails'];
    console.log(control);
    console.log(item);
    const newRow = this.entitiRowSelectionFormGroup();
    newRow.patchValue(item);
    control.push(newRow);
    const CurrentAmount = (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[len - 1].get('Amount').value;
    if (newAdded) {
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      newRow.patchValue({ 'newAddedRow': true });
      this.getTotallingDetailData(len, false);
    }
    const newAddedRow = (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[len - 1].get('newAddedRow').value;
    console.log(newAddedRow, 'newaddrow');

    // if (newAddedRow && CurrentAmount > 0) {
    //   // this.getTotallingDetailData(len, false);
    //   /// (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls[len].get('Amount').value;
    // } else {
    //   this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    //   this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    //   this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
    //   this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
    //   control.removeAt(len);
    //   return false;
    // }
  }



  getReceiptDetails(entitiRowSelectionForm) {
    return entitiRowSelectionForm.controls.ReceiptDetails.controls;
  }
  get cshpayeename() { return this.receiptForm.get('PayeeName'); }
  get cshdetails() { return this.receiptForm.get('EnglishDescription'); }
  get payeebankcode() { return this.receiptForm.get('PayeeBankCode'); }
  get chequedate() { return this.receiptForm.get('ChequeDate'); }
  get instrumentrefno() { return this.receiptForm.get('InstrumentRefNo'); }
  get terminalid() { return this.receiptForm.get('TerminalID'); }
  get expirydate() { return this.receiptForm.get('ExpiryDate'); }
  get chequeno() { return this.receiptForm.get('ChequeNo'); }

  get receiptRows() { return <FormArray>this.receiptForm.get('ReceiptDetails'); }

  reSetForm(param) {
    /*set default value here and reset */
    if (param == 1) {
      const arrayFields = ['PayeeName', 'EnglishDescription', 'ChequeNo', 'ChequeDate', 'PayeeBankCode',
        'PayeeBankName', 'ExpiryDate', 'InstrumentRefNo', 'TerminalID'];
      this.receiptForm.controls['LocationCode'].reset([localStorage.getItem('locationcode')]);
      this.receiptForm.controls['CostCenterCode'].reset([localStorage.getItem('costcentre')]);
      this.receiptForm.controls['TotallingAccCode'].reset([1110]);
      this.receiptForm.controls['RecevierBankCode'].reset([14]);
      this.receiptForm.controls['PayeeName'].reset();
      this.receiptForm.controls['EnglishDescription'].reset();

      arrayFields.forEach((val) => {
        if (this.receiptForm.controls[val] != null && this.receiptForm.controls[val] != undefined) {
          this.receiptForm.controls[val].reset();
        }
      });
      this.clearerrors();
    } else if (param == 2) {
      this.receiptForm.controls['ReceiptDetails'].reset();
      (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map(item => {
        item.get('LocationCode').setValue([localStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([localStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });

      this.getSum();
    }
  }

  deleteReceipt(index: number, itemrow) {
    console.log(itemrow, 'itemrow');
    if (index >= 1) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = RSAMSGConstants.BTNPROCEED) {
          const control = <FormArray>this.receiptForm.controls['ReceiptDetails'];
          control.removeAt(index);
          this.getSum();
        }
      });
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CANTDELETEFIRSTROW;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
    }
  }

  checkIsformDirty() {
    if (this.receiptForm.dirty || this.receiptForm.touched) {
      console.log('cmg here');
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = 'Proceed') {
          this.modalService.hide(1);
        }
      });

    } else {
      this.modalService.hide(1);
    }
    this.gridApiService.unCheck();
  }

  clearGLCode(indx, val) {
    this.setFormArrayCTRLDefaultValue('GLCode', indx, '');
    this.setFormArrayCTRLDefaultValue('GLCodeDesc', indx, '');
  }

  validateDetailInfo() {
    (<FormArray>this.receiptForm.controls['ReceiptDetails']).controls.map(item => {
      item.get('Amount').updateValueAndValidity();
      item.get('Amount').markAsTouched();
      item.get('GLCode').updateValueAndValidity();
      item.get('GLCode').markAsTouched();
      this.glerrorcount = 0;
      if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
      if (item.get('Amount').value == null || item.get('Amount').value == 0 ||
        item.get('Amount').value == undefined || item.get('Amount').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
    });
  }


  submitForm(bsModalRef, receiptno) {
    this.validateDetailInfo();
    console.log(this.glerrorcount, 'glrcount');
    if (this.glerrorcount > 0) {
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    // Removing newAddedRow key from receiptForm
    this.receiptForm.value.ReceiptDetails.map((item, i) => {
      if (item.newAddedRow) {
        delete item.newAddedRow;
      }
    });
    console.log(this.receiptForm.value, 'value');
    let formval = this.receiptForm.value;
    console.log(this.receiptForm.value, 'formval');
    if (this.totalAmount > 0) {
      if (this.totalAmount > 99999 && !this.usersReq) {
        return false;
      }
      if (this.prevReceipt == null || this.prevReceipt == undefined) {
        this.prevReceipt = 0;
      }
      formval["ReceiptNo"] = this.prevReceipt;
      this.createservice.createReceipt(JSON.stringify(formval)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = false;
          this.gridApiService.unCheck();
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog' });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }

    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }

  }


  goPrevious() {
    this.level = 1;
  }
  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
    (!this.collapsetoheader) ? this.modalService._showBackdrop() : this.modalService.removeBackdrop();

  }

}
