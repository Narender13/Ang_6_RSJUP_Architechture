import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { map, catchError } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';

@Injectable({
    providedIn: 'root'
})
export class DrfatService {

    constructor(private http: HttpClient) { }
    httpheaders = new HttpHeaders(
        {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Headers': 'Content-Type,Origin,content-type',
            'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Origin': '*'
        });

    getDraftReceipts(param): Observable<any> {
        // DRAFTSRECEIPT DRAFTAPI
        return this.http.get(RSAENDPOINTConstants.DRAFTAPI + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftReceipt')));
    }

}
