import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { CreateReceiptEntitiRowSelectionComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti-row-selection/create-receipt-entiti-row-selection.component';
import { nsend } from '../../../../../../node_modules/@types/q';
import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';

@Component({
  selector: 'rsa-receipt-drafts',
  templateUrl: './receipt-drafts.component.html',
  styleUrls: ['./receipt-drafts.component.scss']
})
export class ReceiptDraftsComponent implements OnInit {
  @Input() receiptDraftData: any = [];

  pageSize = 15;
  currentpage: any = 1;
  totalAmount = 0;
  totalCount = 0;
  showSnackBar = false;
  bsModalRef: BsModalRef;
  customerName;
  selectedItems = [];
  buttonName: any = [];

  constructor(private modalService: BsModalService) { }

  ngOnInit() {
    console.log(this.receiptDraftData, 'receiptDraftsData-cpomp');
  }

  createButton(buttonNames) {
    this.buttonName = buttonNames;
  }

  pageChanged(ev) {
    this.currentpage = ev;
  }
  viewReceipt(e, data, index) {
    const isCheckBoxSelect = e.srcElement.checked;
    console.log(data, 'data');
    if (isCheckBoxSelect) {
      this.selectedItems.push({ item: data, i: index, eventRef: e.target });
      this.totalAmount += data.Amount;
      this.totalCount++;
      this.showSnackBar = true;
      this.createButton([
        { id: '11', name: 'receipt' },
      ]);
      console.log(this.selectedItems, 'selectedItems');
    } else {
      const currentIndex = this.selectedItems.findIndex((curitem) => curitem.i === index);
      this.selectedItems.splice(currentIndex, 1);
      this.totalCount--;
      this.totalAmount -= data.Amount;
      console.log(this.selectedItems, 'selectedItems');
      if (this.totalCount === 0) {
        this.showSnackBar = false;
        this.totalCount = 0;
      }
    }
  }

  createReceipt(val) {
    const config = {
      backdrop: true,
      ignoreBackdropClick: false,
      class: 'create-modal-dailog'
    };
    if (val == 11) {
      this.showSnackBar = false;
      this.bsModalRef = this.modalService.show(CreateReceiptEntitiRowSelectionComponent, config);
      this.bsModalRef.content.totalamount = this.totalAmount;
      this.bsModalRef.content.totalcount = this.totalCount;
      this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedItems;
    }
  }

  editReceipt(receiptData) {
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      receiptEditData: receiptData,
    };
    console.log(receiptData.TotalAmount, 'totalamount');
    this.bsModalRef = this.modalService.show(CreateDraftReceiptComponent, { class: 'create-modal-dailog', initialState });
    // this.bsModalRef.content.receiptData = receiptData;
    // this.bsModalRef.content.totalAmount = receiptData.TotalAmount;
  }

  viewPreview(receiptData) {
    this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
    this.bsModalRef.content.data = receiptData;
    this.bsModalRef.content.totalAmount = receiptData.TotalAmount;
    this.bsModalRef.content.backdrop = true;
  }
}
