import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { map, catchError, tap, shareReplay, share } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })

export class MasterDataService {
    private cachedMasterData: Observable<any>;
    private cachedMasterData2: Observable<any>;
    private cachedLocationData: Observable<any>;
    httpheaders = new HttpHeaders(
        {
            'Content-Type': 'application/json; charset=utf-8',
            'Access-Control-Allow-Headers': 'Content-Type,Origin,content-type',
            'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Origin': '*'
        });


    constructor(private http: HttpClient) { }


    getMasterData(totacc): Observable<any> {
        let param = 'locationCode=' + localStorage.getItem('locationcode') +
            '&costCenter=' + localStorage.getItem('costcentre') +
            '&totallingAccCode=' + totacc;
        return this.http.get<any>(RSAENDPOINTConstants.VOUCHERMASTER + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getMasterData')));
    }
    getAllMasterData(totacc) {
        if (!this.cachedMasterData) {
            this.cachedMasterData = this.getMasterData(totacc).pipe(shareReplay(1));
        }
        return this.cachedMasterData;
    }

    getMasterData2(): Observable<any> {
        let regioncode = localStorage.getItem('regioncode');
        let locationcode = localStorage.getItem('locationcode');
        let urlpart: string = 'countryCode=' + regioncode + '&locationCode=' + locationcode + '&regionCode=' + regioncode;
        let url = RSAENDPOINTConstants.ADMINMASTER + urlpart;
        console.log(urlpart, 'url');
        return this.http.get<any>(url, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getMasterData')));
    }
    getAllMasterData2() {
        if (!this.cachedMasterData2) {
            this.cachedMasterData2 = this.getMasterData2().pipe(shareReplay(1));
        }
        return this.cachedMasterData2;
    }

    getTotallingData(param) {
        return this.http.get<any>(RSAENDPOINTConstants.HDR_TOT_ACC_CODES + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTotallingData')));
    }
    getTotallingDetailData(param) {
        return this.http.get<any>(RSAENDPOINTConstants.DTL_TOT_ACC_CODES + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTotallingDetailData')));
    }
    getPayeeBankData(param) {
        return this.http.get<any>(RSAENDPOINTConstants.PAYEEBANKDATA + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPayeeBankMasterData')));
    }
    getBankData(param) {
        return this.http.get<any>(RSAENDPOINTConstants.BANKDATA + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getReceiverBankData')));
    }
    getGLData(param) {
        return this.http.get<any>(RSAENDPOINTConstants.GLDATA + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getGLData')));
    }


    /*new masteredata details services*/
    getLookupLocations() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPLOCATIONS, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupLocations')));
    }

    getLookupCostCenters(param) {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPCOSTCENTER + 'locCode=' + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupCostCenters')));
    }
    getCostCenters(param) {
        return this.http.get<any>(RSAENDPOINTConstants.RECEIPTCCFETCH + 'locationCode=' + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupCostCenters')));
    }

    getTotallingAccount(params) {
        const param = 'locCode=' + params.loccode + '&ccCode=' + params.ccode;
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPTOTALINGACCOUNT + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTotallingAccount')));
    }

    getLookupBanks(params) {
        const param = 'locCode=' + params.loccode + '&ccCode=' + params.ccode + '&totAccCode=' + params.totAccCode;
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPBANKNAMES + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupBanks')));
    }


    getPayeeBanks() {
        return this.http.get<any>(RSAENDPOINTConstants.LOADPAYEEBANKNAMES, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPayeeBanks')));
    }

    getTerminals() {
        return this.http.get<any>(RSAENDPOINTConstants.LOADTERMINALUMBER, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTerminals')));
    }

    getInstrumentTypes() {
        return this.http.get<any>(RSAENDPOINTConstants.CARDTYPE, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getInstrumentTypes')));
    }
    getLookupDefaultValue() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDEFAULTVALUES, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLookupDefaultValue')));
    }

    getDetailTotallingAccount(param) {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDETAILTOTALINGACCOUNT + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDetailTotallingAccount')));
    }

    getDetailGlAccount(param) {
        return this.http.get<any>(RSAENDPOINTConstants.GLACCOUNTINDETAILS + param, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDetailGlAccount')));
    }

    getAllTranData() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDETAILTRANS, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllTranData')));
    }
    getAllDeptData() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDETAILDEPT, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllDeptData')));
    }
    getAllProjectIndData() {
        return this.http.get<any>(RSAENDPOINTConstants.LOOKUPDETAILTPROJECTIND, { headers: this.httpheaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAllProjectIndData')));
    }
}
