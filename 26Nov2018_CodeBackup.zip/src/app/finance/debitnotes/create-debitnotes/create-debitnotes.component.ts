import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from '../../search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateDebitNotes } from 'src/app/finance/debitnotes/create-debitnotes/model/create-dn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateDebitnotesService } from 'src/app/finance/debitnotes/create-debitnotes/service/create-debitnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { TaxinvoicepreviewComponent } from  'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component'

@Component({
  selector: 'rsa-create-debitnotes',
  templateUrl: './create-debitnotes.component.html',
  styleUrls: ['./create-debitnotes.component.scss']
})
export class CreateDebitnotesComponent extends BasevoucherComponent implements OnInit {
  title = 'Payment';
  currency = 'AED';
  errorpayee: boolean;
  errordetail: boolean;
  errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createDebitNotes: CreateDebitNotes;
  animatedClass = true;
  selectedRowItem: any;
  customerName: string = "";
  ondemandFlag: boolean = true;
  formArray: any;

  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateDebitnotesService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    super.setMinMaxDate();
  }


  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.createVoucherForm(this.paymentMode);
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllProjData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (localStorage.getItem('symbol'));
    super.setMinMaxDate();
    this.getGlAccountHeader();
    this.getDetailsArrayFormGroup(); 
    super.getModelPreviousClose();
  
  }

  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;
    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ApprovedBy:[],
      ArabicDescription: [],
      Amount: [''],
      CountryCode: [1],
      CustomerID: [],
      CustCode:[],
      ModifiedBy: ['1'],
      ModifiedDate: [],
      PreparedBy: [1],
      PreparedDate: [],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate : [],
      PostedDate:[], 
      PreprintNo:[],
      Title:['CREDIT NOTE'],
      RegionCode: [localStorage.getItem('regioncode')],
      Approvers: this.fb.array([]),       
      detailInfo: this.fb.group({
        PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
        GLCode: [4, Validators.required],
        GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [localStorage.getItem('locationcode')],
        CostCenterCode: [11],
        TotallingAccCode: [1110]        
      }),
      VoucherDetails: this.fb.array([])
    });
  }

  getDetailsArrayFormGroup() {
    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (!this.ondemandFlag) {
      this.selectedRowItem.map(item => {
        let group = this.createDetailsArrayGroup();
        group.patchValue(item.item);
        group.get("newAddedRow").setValue(false);
        control.push(group);
      });
    } else {
      control.push(this.createDetailsArrayGroup())
    }
  }

  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      Amount: ['', Validators.required],
      AnalysisCode: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ClaimID:[],
      ClassCode: [],
      CauseOfLossCode:[],
      CounterPartyRef: [],
      CountryCode: [1],
      Description: [],
      DocumentCode:[],
      EntityID:[],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      LocationCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      ModifiedBy: ['1'],
      ModifiedDate:[],
      NatureOfLossCode:[],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy:[],
      PreparedDate:[],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [3],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],    
      PolicyType: [],
      newAddedRow: true,
      VoucherNo:[]
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1110');
      this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('14');
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );

    this.glCodeValue.statusChanges.subscribe(
      status => {
        this.errorglCode = (status === 'INVALID');       
      }
    );    

  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorglCode = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }
 

  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }


  /* add receipt in review screen */
  addReceipt(len) {
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
    if (CurrentAmount > 0) {
      control.push(this.createDetailsArrayGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      this.dtltotallingacc[len] = this.cachedDtlTot;
      this.glaccount[len] = this.cachedGL;
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }

  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(4);
      this.mainVoucherForm.controls.GLCodeDesc.setValue('4-HSBC BANK MIDDLE EAST - Deira');
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([localStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([localStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });
      this.getSum();
    }
  }
 
  /* update  form values to create-receipt objects*/
  createCNFormValues() {
     this.createDebitNotes = new CreateDebitNotes();
     const mainFormFieldArray = ['VoucherDate','ApprovedBy','ArabicDescription',
     'CountryCode','CustomerID','CustCode','ModifiedDate','ModifiedBy','PostedDate',
     'PreparedBy','PreparedDate','PreprintNo','PrintDate','RefreshDate','RegionCode','Title',
     'Approvers'];
    mainFormFieldArray.forEach(item => {
      console.log('this.item****',item);
        this.createDebitNotes[item] = this.mainVoucherForm.controls[item].value;
        
     });
    this.createDebitNotes.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createDebitNotes.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createDebitNotes.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createDebitNotes.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createDebitNotes.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createDebitNotes.DebitNoteDetail = this.mainVoucherForm.controls['VoucherDetails'].value;
    console.log('this.createCreditNotes****',this.createDebitNotes);
 
  }

  /* create-receipt form*/
  submitForm() {
    super.validateDetailInfo();
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    this.errorglCode = this.glCodeValue.invalid;
    if (!(!this.errorpayee && !this.errordetail  && !this.errorglCode )) {
     return false;
    }    

    if (this.glerrorcount > 0) {
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    if (this.totalAmount > 0) {
      if (this.totalAmount > 99999 && !this.usersReq) {
        return false;
      }
      this.createCNFormValues();
      console.log(this.createDebitNotes, ' this.createCreditNotes');
      if(this.prevPreviewID == null || this.prevPreviewID==undefined)
      this.prevPreviewID=0;
      this.createDebitNotes["DebitNoteNo"]=this.prevPreviewID;

      this.createPaymentService.createDebitNote(JSON.stringify(this.createDebitNotes)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(TaxinvoicepreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }
  }


  getGlAccountHeader() {
    const param = 'locCode=' + localStorage.getItem("locationcode") +
      '&totAccCode=1110' +
      '&ccCode=' + localStorage.getItem('costcentre');
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      console.log('gldata', data);
    })
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }

}