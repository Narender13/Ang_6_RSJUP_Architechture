import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { map, catchError } from 'rxjs/operators';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';


@Injectable({
  providedIn: 'root'
})
export class CreateDebitnotesService {

  private httpheaders = new HttpHeaders(
    {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Headers': 'Content-Type,Origin,content-type',
        'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Origin': '*'
    });

constructor(private http: HttpClient) { }
  createDebitNote(param: any) {
    console.log(param, 'param');
    return this.http.post<any>(RSAENDPOINTConstants.CREATEDEBITNOTE, param, { headers: this.httpheaders }).pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('createPayment')));
}

}
