import { TestBed, inject } from '@angular/core/testing';

import { CreateDebitnotesService } from './create-debitnotes.service';

describe('CreateDebitnotesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateDebitnotesService]
    });
  });

  it('should be created', inject([CreateDebitnotesService], (service: CreateDebitnotesService) => {
    expect(service).toBeTruthy();
  }));
});
