import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-create-recovery-agent',
  templateUrl: './create-recovery-agent.component.html',
  styleUrls: ['./create-recovery-agent.component.scss']
})
export class CreateRecoveryAgentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
