import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-create-customer',
  templateUrl: './create-customer.component.html',
  styleUrls: ['./create-customer.component.scss']
})
export class CreateCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
