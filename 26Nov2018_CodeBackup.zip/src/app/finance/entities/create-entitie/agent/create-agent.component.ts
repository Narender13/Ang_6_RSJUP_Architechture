import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../shared/animation/slidein';

@Component({
  selector: 'rsa-create-agent',
  templateUrl: './create-agent.component.html',
  styleUrls: ['./create-agent.component.scss'],
  animations: [slideInOut]
})
export class CreateAgentComponent implements OnInit {
  agentForm: FormGroup;
  isArabicField = false;
  address = false;
  address1 = false;
  address2 = false;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.createEntiteForm();
  }

  createEntiteForm(): void {
    this.agentForm = this.fb.group({
      agentinformation: this.fb.group({
        title: ['', Validators.required],
        Name: ['', Validators.required],
        licensenumber: ['', Validators.required],
        licenseexpiraydate: ['', Validators.required],
        vatcode: ['', Validators.required],
        vatregnumber: ['', Validators.required],
        email: ['', Validators.required],
        phonenumber: ['', Validators.required],
        mobilenumber: ['', Validators.required],
        faxnumber: ['', Validators.required],
        branch: ['', Validators.required],
        vatrate: ['', Validators.required],
        vatregcountry: ['', Validators.required]
      }),
      address: this.fb.group({
        address: ['', Validators.required],
        address1: ['', Validators.required],
        address2: ['', Validators.required],
        pobox: ['', Validators.required],
        postalcode: ['', Validators.required],
      }),
      addtionalinfo: this.fb.group({
        agentgroup: ['', Validators.required],
        remarks: ['', Validators.required],
        category: ['', Validators.required],
        apptdate: ['', Validators.required]
      }),
      status: ['', Validators.required],
      acexective: ['', Validators.required]
    });
  }

  submitForm(): void {
   
  }



}
