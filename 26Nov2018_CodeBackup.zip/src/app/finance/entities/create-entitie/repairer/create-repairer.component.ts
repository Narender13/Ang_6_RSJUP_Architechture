import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-create-repairer',
  templateUrl: './create-repairer.component.html',
  styleUrls: ['./create-repairer.component.scss']
})
export class CreateRepairerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
