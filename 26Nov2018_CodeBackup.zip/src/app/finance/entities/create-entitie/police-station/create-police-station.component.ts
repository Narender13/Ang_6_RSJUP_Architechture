import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-create-police-station',
  templateUrl: './create-police-station.component.html',
  styleUrls: ['./create-police-station.component.scss']
})
export class CreatePoliceStationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
