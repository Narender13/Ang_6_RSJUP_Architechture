import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-create-company',
  templateUrl: './create-company.component.html',
  styleUrls: ['./create-company.component.scss']
})
export class CreateCompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
