import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BasevoucherComponent } from './basevoucher.component';

describe('BasevoucherComponent', () => {
  let component: BasevoucherComponent;
  let fixture: ComponentFixture<BasevoucherComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BasevoucherComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BasevoucherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
