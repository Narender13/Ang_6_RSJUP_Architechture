import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/finance/services/shared.service';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
@Component({
  selector: 'rsa-basevoucher',
  templateUrl: './basevoucher.component.html',
  styleUrls: ['./basevoucher.component.scss']
})
export class BasevoucherComponent implements OnInit {
  totallingacc: any = [];
  users: any = [];
  costcentredata: any = [];
  branchdata: any = [];
  receiverdataBankName: any = [];
  payeedataBankName: any = [];
  flagInit: boolean;
  paymentMode = 2;
  cachedReceiverBankData: any = [];
  cachedPayeeBankData: any = [];
  cachedDtlTot: any = [];
  cachedBranchdata = [];
  cachedCostcentredata = [];
  cachedTotAcc: any = [];
  cachedGL: any = [];
  errorMsg;
  mainVoucherForm: FormGroup;
  paymentname;
  dtltotallingacc: any = [];
  level: any = 1;
  collapsetoheader: boolean;
  masterdata: any = [];
  masterdata2: any = [];
  terminals = [];
  pjctindicator: any = [];
  department: any = [];
  transactiontype: any = [];
  currentTbIndex = 0;
  totalAmount = 0;
  glerrorcount = 0;
  previewFlag = false;
  glaccount: any = [];
  arrUser: any = [];
  approverusers: string;
  minDateRd: any;
  maxDateRd: any;
  prevPreviewID:any;
  previewDataDtl:any = [];
 
  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(protected masterDataService: MasterDataService, protected sharedService: SharedService,
    protected modalService: BsModalService,
    protected utilityClass: UtilityClass,
    protected bsModalRef: BsModalRef) {
    console.log('basvocher');
  }
  ngOnInit() {

  }

  /* go Previous screen in modal */
  goPrevious() {
    this.level = 1;
  }
  /* collapse modal header */
  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
    if (this.collapsetoheader) {
      this.sharedService.sendMessage('collapse');
    } else {
      this.sharedService.sendMessage('not-collapse');
    }
  }

  /* get all branch data for header and details */
  getAllBranchData() {
    this.masterDataService.getLookupLocations().subscribe((data) => {
      this.branchdata = data;
      console.log(data, 'branchdata');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all transcation data for  details */
  getAllTranData() {
    this.masterDataService.getAllTranData().subscribe((data) => {
      this.transactiontype = data;
      console.log(data, 'transactiontype');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all department data for  details */
  getAllDeptData() {
    this.masterDataService.getAllDeptData().subscribe((data) => {
      this.department = data;
      console.log(data, 'department');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all project indicator data for  details */
  getAllProjData() {
    this.masterDataService.getAllProjectIndData().subscribe((data) => {
      this.pjctindicator = data;
      console.log(data, 'pjctindicator');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all cost Centre  data for  header and details */
  getAllCostCenterData(ev) {
    const loccode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.masterDataService.getLookupCostCenters(loccode).subscribe((data) => {
      this.costcentredata = data;
      console.log(data, 'costcentredata');
      this.getTotallingDetailData(ev);
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* get all payeedataBankName  data for  header  */
  getAllPayeeBankData(cachedflag) {
    this.masterDataService.getPayeeBanks().subscribe((data) => {
      this.payeedataBankName = data;
      this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode.setValue(this.payeedataBankName[0].Code);
      if (cachedflag) {
        this.cachedPayeeBankData = data;
      }
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  /*get All users data from masterservice to approvers */
  getAllMasterData2(): void {
    this.masterDataService.getAllMasterData2().subscribe(
      dataReturn => {
        this.users = dataReturn.Users;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  /*get Totalling account data for headers */
  getAllTotallingData(initflag) {
    const loccode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    const ccode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    const param = {
      loccode: loccode,
      ccode: ccode,
    };
    this.masterDataService.getTotallingAccount(param).subscribe((data) => {
      this.totallingacc = data;
      console.log(data, 'getAllTotallingData');
      if (initflag) {
        this.cachedTotAcc = data;
      }
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  /*get AllgetLookupBanksData  data for headers */
  getAllgetLookupBanksData() {
    const loccode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    const ccode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    const totAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    const param = {
      loccode: loccode,
      ccode: ccode,
      totAccCode: totAccCode
    };
    this.masterDataService.getLookupBanks(param).subscribe((data) => {
      this.receiverdataBankName = data;
      console.log(data, 'receiverdataBankName');
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  /* after changing the branch in details */
  changeCostcenter(ev) {
    this.getAllCostCenterData(ev);
  }


  /* after changing the payee bank in headers */
  setBankData(ev) {
    console.log(ev, 'ev');
    this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('');
    this.getBankData(ev.flag);
  }

  /* after changing the payee bank in headers */
  getBankData(flagInit) {
    const loccode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    const ccentre = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    const totcode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    const param = {
      loccode: loccode,
      ccode: ccentre,
      totAccCode: totcode
    };
    this.masterDataService.getLookupBanks(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
        if (!flagInit) {
          this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue(this.receiverdataBankName[0].BankCode);
        }
        if (flagInit) {
          this.cachedReceiverBankData = dataReturn;
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* check the perious and display the model using for edit screen  */
  getModelPreviousClose() {
    this.sharedService.getMessage().subscribe(val => {
      if (val === 'previous') {
        this.previewFlag = false;
      } else if (val === 'close') {
        this.modalService.hide(1);
      }
      this.prevPreviewID = val.id;
      this.previewDataDtl = val.data;
      if (this.previewDataDtl != null || this.previewDataDtl != undefined){
        this.doPatchRefFields(); }

    });
  }
  doPatchRefFields() {
    let formarray = (<FormArray>this.mainVoucherForm.controls['VoucherDetails'])
    formarray.controls.map((item,index) => {
      item.get("RefTransactionID").setValue(this.previewDataDtl[index].RefTransactionID);
      item.get("RefTransactionSerialNo").setValue(this.previewDataDtl[index].RefTransactionSerialNo);
    });
  }
  // closing modal dialog box
  closeModel() {
    this.utilityClass.isModalShow().subscribe((data) => {
      if (data) {
        this.modalService.hide(1);
      }
      this.modalService.hide(1);
    });
  }


  /* after changing TotallingDetailData  details */
  getTotallingDetailData(ev) {
    console.log(ev);
    const index = ev.index;
    const initFlag = ev.flag;
    const loccode = this.getFromFormArrayControlVal('LocationCode', index);
    const ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);

    const param = 'locCode=' + loccode +
      '&ccCode=' + ccentre;

    this.masterDataService.getDetailTotallingAccount(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;
        const totcode = this.dtltotallingacc[index][0].Code;
        if (!initFlag) {
          this.setFormArrayCTRLDefaultValue('TotallingAccCode', index, totcode);
        }
        if (initFlag) {
          this.cachedDtlTot = dataReturn;
        }
        this.getGLData({ ev: totcode, index: index, flag: initFlag });
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  /*get gldata  */
  getGLData(ev) {
    console.log(ev);
    const index = ev.index;
    const initFlag = ev.flag;
    const val = ev.ev;
    const loccode = this.getFromFormArrayControlVal('LocationCode', index);
    const ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);
    const totcode = (initFlag) ? this.getFromFormArrayControlVal('TotallingAccCode', index) : val;

    const param = 'locCode=' + loccode +
      '&totAccCode=' + totcode +
      '&ccCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getDetailGlAccount(param).subscribe(
      dataReturn => {
        console.log(dataReturn, 'dataretrun');
        this.glaccount[index] = dataReturn;
        if (!initFlag) {
          this.setFormArrayCTRLDefaultValue('GLCode', index, this.glaccount[index][0].Code);
          this.setFormArrayCTRLDefaultValue('GLCodeDesc', index, this.glaccount[index][0].E_Code_Desc);
        }
        if (initFlag) {
          this.cachedGL = dataReturn;
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
    if (this.level == 2) {
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('Amount').updateValueAndValidity();
        item.get('GLCode').updateValueAndValidity();
      });
    }
  }


  /* clear glcode on reset */
  clearGLCode(ev) {
    this.setFormArrayCTRLDefaultValue('GLCode', ev.index, '');
    this.setFormArrayCTRLDefaultValue('GLCodeDesc', ev.index, '');
  }
  /*generic function to take controls of recepdetails Totalling Data  */
  setFormArrayCTRLDefaultValue(contrlname, index, val) {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get(contrlname).setValue(val);
  }

  getFromFormArrayControlVal(contrlname, index) {
    return (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[index].get(contrlname).value;
  }

  // setting minimum and maximum date
  setMinMaxDate() {
    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);
  }

  /* for approvals change results */
  onUserChange(parmas) {
    console.log(parmas, 'params');
    const isCheked = parmas.event.target.checked;
    const userid = parmas.item.UserID;
    const username = parmas.item.UserEngName;

    const userFormArray = <FormArray>this.mainVoucherForm.controls.Approvers;
    if (isCheked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value == userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
    }
    this.approverusers = this.arrUser.join();

    console.log(this.approverusers, 'approvals');
  }

  /* calculating credit and debit when switch changes */
  setCreditEntry(ev) {
    console.log(ev, 'key');
    const actualData = Number(ev.data.controls['Amount'].value);
    const curdata = -(ev.data.controls['Amount'].value);
    ev.data.controls['Amount'].patchValue(curdata);
    this.getSum();
    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.EMPTYAMOUNTCHECK,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = true;

    }
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails'])
      .controls[ev.index].get(ev.iscredit).setValue(ev.event.target.checked);
    if (this.totalAmount < 0) {
      ev.event.target.checked = true;
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.CREDITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.data.controls['Amount'].patchValue(-curdata);
      this.getSum();
    }

  }

  /* set value for glcode */
  setHiddenValue(val) {
    console.log(val);
    const ev = val.event.item.Code;
    const iter = val.index;
    const key = val.item;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[iter].get(key).setValue(ev);
  }
  // diplay confirmation dialog box
  displayAlertModal(obj: any) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent,
      { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = obj.title;
    this.bsModalRef.content.modelBodyContent = obj.txt;
    this.bsModalRef.content.cancelBtn = obj.btncancel;
    this.bsModalRef.content.actionBtn = obj.btnaction;

  }
  /* check form is validateDetailInfo */
  validateDetailInfo() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
      item.get('Amount').updateValueAndValidity();
      item.get('GLCode').updateValueAndValidity();
      item.get('Amount').markAsTouched();
      item.get('GLCode').markAsTouched();
      this.glerrorcount = 0;
      if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == '') {
        this.glerrorcount = this.glerrorcount + 1;
      }
      if (item.get('Amount').value == null || item.get('Amount').value == 0 ||
        item.get('Amount').value == undefined || item.get('Amount').value == '') {
        this.glerrorcount = this.glerrorcount + 1;
      }
    });
  }

  // getting total of amount
  getSum() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    ctrl.controls.forEach(val => {
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value) ||
        val.get('Amount').value == '') ? 0 : val.get('Amount').value;
      this.totalAmount += parseFloat(amt);
    });
    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;
  }
  // checking voucher detail form array length
  get voucherDetailsLength() {
    return this.mainVoucherForm.controls.VoucherDetails['controls'].length > 1;
  }
  /* get VoucherDetails controls*/
  get voucherRows() { return <FormArray>this.mainVoucherForm.get('VoucherDetails'); }

  /* check form is dirty */
  checkIsformDirty() {
    this.utilityClass.checkIsformDirty(this.mainVoucherForm);
  }

  /* delete receitdetails row */
  deleteReceipt(ev) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = RSAMSGConstants.BTNPROCEED) {
        const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
        control.removeAt(ev.index);
        this.getSum();
      }
    });
  }

  // setting current Tab Index to activiate tab
  setcurrentTbIndex(tab) {
    switch (tab) {
      case 'Cheque':
        this.currentTbIndex = 0;
        break;
      case 'Cash':
        this.currentTbIndex = 1;
        break;
      case 'Bank Transfer':
        this.currentTbIndex = 2;
        break;
      // case 'Credit Card':
      //   this.currentTbIndex = 3;
      //   break;
    }
  }


  // Displaying the  confirmation alert on tab click
  confirmTabSwitch(event) {
    const target = event.target.parentElement.text;
    if (event.target.tagName === 'SPAN') {
      if (this.mainVoucherForm.dirty) {
        // --- showing popup only you have added or changed something      
        this.displayAlertModal({
          'title': RSAMSGConstants.MODELTITLE,
          'txt': RSAMSGConstants.PAYMENTMODECHANGEMSG,
          'btnaction': RSAMSGConstants.BTNPROCEED,
          'btncancel': RSAMSGConstants.BTNCANCEL,
        });



        this.bsModalRef.content.valueChange.subscribe((data) => {
          console.log(data);
          // changing the currentTbIndex if user proceed
          if (data = RSAMSGConstants.BTNPROCEED) {
            console.log(this.currentTbIndex);
            setTimeout(() => {
              this.setcurrentTbIndex(target);
            }, 0);
            setTimeout(() => {
              this.tabset.tabs.forEach(item => {
                if (item.heading == target) {
                  item.active = true;
                }
              });
            }, 1);
          }
        });
      } else {
        setTimeout(() => {
          this.setcurrentTbIndex(target);
        }, 0);
        setTimeout(() => {

          this.tabset.tabs.forEach(item => {
            if (item.heading == target) {
              item.active = true;
            }
          });
        }, 1);

      }

    }
  }

  /* set default Header Data   */
  setdefaultHeaderData() {
    console.log(this.terminals[0]);
    console.log(this.payeedataBankName[0].Code);

    if (this.paymentMode == 2) {
      this.mainVoucherForm.controls.chequeInfo['controls'].PayeeBankCode
        .setValue(this.payeedataBankName[0].Code);
    }

    if (this.paymentMode == 5) {
      this.mainVoucherForm.controls.bankTransfer['controls'].PayeeBankCode
        .setValue(this.payeedataBankName[0].Code);
    }

  }

  /* using for reseting the form */
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      console.log(formGroup.controls);
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.reset();
      }
      if (control instanceof FormGroup) {
        control.reset();
      }
    });
  }
}


