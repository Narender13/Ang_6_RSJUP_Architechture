import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BsModalRef } from 'ngx-bootstrap';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { Subject } from 'rxjs';
import { MessageService } from 'src/app/core/message/service/message.service';

@Component({
  selector: 'rsa-receipt-cancel',
  templateUrl: './receipt-cancel.component.html',
  styleUrls: ['./receipt-cancel.component.scss']
})
export class ReceiptCancelComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    public bsModalRef: BsModalRef,
    private createService: CreateService, private messageService: MessageService) { }
  public onClose: Subject<any>;
  cancelreceiptform: FormGroup;
  dataresult: any;
  ev: any;
  ReceiptID: any;
  enableFlag: boolean = false;
  viewscreen: boolean = false;
  PaymentNo: any;
  errorMsg: string;
  Defaulttext;

  ngOnInit() {
    this.cancelreceiptform = this.fb.group({
      comments: [],
      ReceiptNo: []
    });
    this.Defaulttext = `Receipt No:${this.ReceiptID} reversed for ReceiptName`;
  }
  changeComments() {
    let ctrl = this.cancelreceiptform.get("comments");
    this.enableFlag = ctrl.pristine || ctrl.value.length > 0;
    console.log(this.enableFlag, 'this.enableFlag');
  }
  closeModal(ev) {
    this.bsModalRef.hide();
    ev.checked = false;
  }
  cancelReceipt(recptid) {
    this.cancelreceiptform.controls["ReceiptNo"].setValue(parseInt(recptid));
    console.log(this.cancelreceiptform.value, 'this.cancelreceiptform.value');
    this.viewscreen = true;
    this.createService.cancelReceipt(this.cancelreceiptform.value).subscribe(
      (data) => {
        this.dataresult = data;
        this.PaymentNo = data.PaymentNo;
        this.viewscreen = true;
        //this.bsModalRef.hide();
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  viewReceipt() {
    this.messageService.sendMessage(true);
    this.bsModalRef.hide();
  }
}
