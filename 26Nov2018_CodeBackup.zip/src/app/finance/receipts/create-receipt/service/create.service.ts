import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';


@Injectable({ providedIn: 'root' })
export class CreateService {
  private cachedMasterData: Observable<any>;
  private cachedMasterData2: Observable<any>;
  httpheaders = new HttpHeaders(
    {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Headers': 'Content-Type,Origin,content-type',
      'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Origin': '*'
    });


  constructor(private http: HttpClient) { }

  createReceipt(param: any) {
    console.log(param, 'param');
    return this.http.post<any>(RSAENDPOINTConstants.RECEIPTPREVIEWSAVE, param, { headers: this.httpheaders }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('createReceipt')));
  }

  cancelReceipt(param) {
    let body = JSON.stringify(param);
      console.log(body, "body");
      return this.http.post(RSAENDPOINTConstants.RECEIPTCANCEL ,body, { headers: this.httpheaders }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('cancelReceipt')));
  }
  saveReceipt(param) {
    let body = JSON.stringify({ "receiptNo": param });
    let url = RSAENDPOINTConstants.SAVERECEIPT + param;
    console.log(url, 'url');
    return this.http.put<any>(url, { headers: this.httpheaders }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }
  saveCreditNote(param) {
    let body = JSON.stringify({ "CreditNote": param });
    let url = RSAENDPOINTConstants.SAVECREDITNOTE + param;
    console.log(url, 'url');
    return this.http.put<any>(url, { headers: this.httpheaders }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }
  saveDebitNote(param) {
    let body = JSON.stringify({ "DebitNote": param });
    let url = RSAENDPOINTConstants.SAVEDEBITNOTE + param;
    console.log(url, 'url');
    return this.http.put<any>(url, { headers: this.httpheaders }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }
  sendEmail(param) {
    let body = JSON.stringify(param);
    let url = RSAENDPOINTConstants.RECEIPTEMAIL;
    console.log(url, 'url');
    return this.http.post<any>(url, body, { headers: this.httpheaders }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveReceipt')));
  }
}
