import { Component, OnInit, Input } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';

@Component({
  selector: 'rsa-endorsementnumber',
  templateUrl: './endorsement-number.component.html',
  styleUrls: ['./endorsement-number.component.scss']
})
export class EndorsementnumberComponent extends BaseSearchComponent implements OnInit {
  @Input() category;
  @Input('endorsementnumber') endorsementnumber: any;
  @Input() resultdata;
  glnumber: string;
  showtabledata: number;
  idnumber = '201838683';
  name = ' ';
  constructor() {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

}
