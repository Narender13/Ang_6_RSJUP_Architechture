import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SearchService } from '../service/search.service';
import { RSAENDPOINTConstants } from '../../../core/constants/rsa.api.end.points';
import { LoaderService } from 'src/app/core/loader/loader-service';
import { MatchUnMatchService } from 'src/app/finance/search/service/match-unmatch.service';
@Component({
  selector: 'rsa-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.scss']
})
export class SearchResultsComponent implements OnInit {

  constructor(private searchService: SearchService, private route: ActivatedRoute,
    private loaderService: LoaderService, private matchUnMatchService: MatchUnMatchService) {

  }
  private inputData: string;
  searchResults: any = [];
  errorMsg: string;
  private categoryItem: string;
  category: number;
  private filtercolumndata: any;
  private thEntityProperty: any;
  private ReceiptNo: any;
  headerdata: any;
  settingsdata: any;
  configurl: string;
  entitySerachId;
  entitySerachType;
  categoryType;
  paramURL: any;
  isResults = false;
  defaultName: string;
  classcode: string;
  lobTitle: string;

  ngOnInit() {
    const res = this.loaderService.isLoading();
    console.log(res, 'resloading');
    this.route.queryParams.subscribe(params => {
      this.category = +params['category'];
      this.inputData = params['inputData'];
      this.categoryItem = params['categoryitem'];
      this.classcode = params['classCode'];
      this.lobTitle = params['lobitem'];
      this.entitySerachId = +params['id'];
      this.entitySerachType = +params['entityType'];
      this.categoryType = +params['categoryType'];
      this.defaultName = params['entitySerachItem'];
      console.log(this.entitySerachId, this.entitySerachType, 'entitySerachId');
      let param;
      if (this.categoryType == 4) {
        param = {
          'id': this.entitySerachId,
          'entityType': this.entitySerachType,
          'entityUnMatched': 0,
          'categoryType': this.categoryType,
        };
        this.paramURL = param;
      } else {
        param = {
          'category': this.category,
          'inputData': this.inputData,
          'categoryitem': this.categoryItem,

        };
        if (this.classcode !== '0') {
          param['classCode'] = this.classcode;

        }
      }

      this.getSearchResultsData(param);

      /*  getting column heads for the table display for result page */

      if (param.category == 12 || param.category == 13 || param.category == 11) {
        this.configurl = RSAENDPOINTConstants.COULMNHEADERCONFIG;
      } else if (param.category == 2) {
        this.configurl = RSAENDPOINTConstants.COULMNHEADERCONFIGRECEIPT;
      } else if (param.category == 5 || param.category == 6) {
        this.configurl = RSAENDPOINTConstants.COULMNHEADERCONFIGCN;
      } else if (param.category == 7) {
        this.configurl = RSAENDPOINTConstants.COULMNHEADERCONFIGJV;
      }

      this.getCoulmnHeaderConfig();

      /* end of the logic */
    });


    this.getmatchedData();
  }

  getSearchResultsData(params) {
    console.log("param----------->", params);
    this.searchService.getSearchResults(params).subscribe(
      dataReturn => {
        this.ReceiptNo = ((params.category == 2 || params.category == 12 || params.category == 13) && (dataReturn != null &&
          dataReturn != undefined && dataReturn.ReceiptNo != null)) ? dataReturn.ReceiptNo : '';
        this.searchResults = [];
        console.log(dataReturn, 'typeof(dataReturn)');
        this.searchResults.push(dataReturn);
        this.isResults = true;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getCoulmnHeaderConfig(): void {
    this.searchService.getCoulmnHeaderConfig(this.configurl).subscribe((data) => {
      this.headerdata = data;
      this.settingsdata = data.map(x => Object.assign({}, x));
    });
  }

  getmatchedData(): void {
    this.matchUnMatchService.getMatchUnMatchObserable().subscribe((res) => {
      this.paramURL.entityUnMatched = res.id;
      this.getSearchResultsData(this.paramURL);
    });
  }


}
