import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { RSAENDPOINTConstants } from '../../../../core/constants/rsa.api.end.points';
import { SearchService } from '../../service/search.service';

@Component({
  selector: 'rsa-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  isopen: boolean;
  headerData: any;
  errormsg = false;
  errormsgHide = false;
  @Input() displayflag: boolean;
  @Output() thdata = new EventEmitter();
  @Input() settingsdata: any;
  constructor(private searchService: SearchService) { }

  ngOnInit() {

  }


  toggleSettings() {
    this.isopen = !this.isopen;
    this.errormsg = false;
  }
  onSelectionCheckbox(e) {
    if (this.getCount() > 7) {
      e.target.checked = false;
      this.errormsg = true;

    }
  }
  changeHandler() {
    if (this.getCount() < 8) {
      this.errormsg = false;
    }
  }
  setTableCoulmn(): void {
    this.headerData = this.settingsdata.map(x => Object.assign({}, x));
    this.isopen = false;
    this.thdata.emit(this.headerData);
  }
  getCount(): number {
    let count = 0;
    this.settingsdata.forEach(item => {
      if (item.checked) {
        count++;
      }
    });
    return count;
  }
  closePopup(): void {
    this.isopen = false;
    this.errormsg = false;
  }
}
