import { Component, OnInit, Input, } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ReceiptCancelComponent } from 'src/app/finance/receipts/receipt-cancel/receipt-cancel.component';
import { MessageService } from 'src/app/core/message/service/message.service';
import { SearchService } from 'src/app/finance/search/service/search.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';

@Component({
  selector: 'rsa-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.scss'],
})
export class ReceiptComponent extends BaseSearchComponent implements OnInit {
  @Input('resultdata') resultdata: any = [];
  @Input('receiptNo') receiptNo: any;
  @Input('category') category: any;
  @Input() settingsdata: any;
  @Input() headerdata: any;
  bsModalRef: BsModalRef;
  showCancelDialog: boolean;
  buttonName: any = [];
  glnumber: string;
  idnumber = '';
  name = '';
  pageSize = 15;
  currentpage: any = 1;
  isopen: boolean;
  displayFlag: boolean;
  ReceiptId: string;
  previewresult:any;
  eventRef: any;
  errorMsg:string;
  constructor(
    private router: Router,
    private modalService: BsModalService ,private searchService: SearchService, private messageService: MessageService) {
    super();
  }

  createButton(buttonNames) {
    this.buttonName = buttonNames;
  }

  cancelReceipt(ev, receiptId) {
    console.log(ev);
    this.eventRef = ev;
    if (ev.target.checked) {
      this.showCancelDialog = true;
      this.createButton([{ id: '9', name: ' Cancel Receipt' },]);
      this.ReceiptId = receiptId;
    } else {
      this.showCancelDialog = false;
    }
  }
  showCancelReceiptDialog() {
    this.showCancelDialog = false;
    const initialState = {
      ReceiptID: this.ReceiptId,
      backdrop: true,
      ignoreBackdropClick: true,
      class: 'receipt-cancel-model',
      ev: this.eventRef.target
    };
    this.bsModalRef = this.modalService.show(ReceiptCancelComponent,
      Object.assign({}, { backdrop: true },
        { ignoreBackdropClick: true }, { initialState }, { class: 'receipt-cancel-model' })
    );
    this.messageService.getMessage().subscribe(result => {
      console.log('results', result);
      // this.messageService.clearMessage();
    });
  }
  hideSnackBar() {
    this.showCancelDialog = false;
    this.eventRef.target.checked = false;
  }
  ngOnInit() {
    super.ngOnInit();

  }

  previewReceipt(data) {
   this.searchService.getPreviewReceipt(data).subscribe(
     (data) => {
       this.previewresult = data;
       console.log( this.previewresult,'this.previewresult');
       this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.previewresult;
          this.bsModalRef.content.fromCategory = 2;
          this.bsModalRef.content.totalAmount = this.previewresult.totalAmount;
          this.bsModalRef.content.backdrop = true;
      },
     errorRturn => {
      this.errorMsg = errorRturn;
    }
   )
  }

  ngafterViewInit() {
  }

  pageChanged(ev) {
    this.currentpage = ev;
  }
  updateTableHeader(data) {
    this.headerdata = data;

  }

}
