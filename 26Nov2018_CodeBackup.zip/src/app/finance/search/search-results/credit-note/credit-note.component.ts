import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from '../../service/search.service';
import { RSAENDPOINTConstants } from '../../../../core/constants/rsa.api.end.points';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component'
@Component({
  selector: 'rsa-creditnote',
  templateUrl: './credit-note.component.html',
  styleUrls: ['./credit-note.component.scss']
})
export class CreditnoteComponent extends BaseSearchComponent implements OnInit {

  @Input('resultdata') resultdata: any = [];
  @Input('creditNoteNo') creditNoteNo: any;
  @Input('category') category: any;
  @Input() settingsdata: any;
  @Input() headerdata: any;

  glnumber: string;
  idnumber = '';
  name = ' ';
  pageSize = 15;
  currentpage: any = 1;

  constructor(private searchService: SearchService) { super() }

  ngOnInit() {
    super.ngOnInit();
  }
  pageChanged(ev) {
    this.currentpage = ev;
  }
  updateTableHeader(data) {
    this.headerdata = data;
  }
}
