import { Component, OnInit, Input } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component'
import { SearchService } from '../../service/search.service';
@Component({
  selector: 'rsa-debitnote',
  templateUrl: './tax.component.html',
  styleUrls: ['./tax.component.scss']
})
export class TaxComponent extends BaseSearchComponent implements OnInit {

  @Input('resultdata') resultdata: any = [];
  @Input('debitNoteNo') debitNoteNo: any;
  @Input('category') category: any;
  @Input() settingsdata: any;
  @Input() headerdata: any;


  glnumber: string;
  idnumber = '';
  name = '';
  pageSize = 15;
  currentpage: any = 1;

  constructor(private searchService: SearchService) { super() }

  ngOnInit() {
    super.ngOnInit();
  }
  pageChanged(ev) {
    this.currentpage = ev;
  }
  updateTableHeader(data) {
    this.headerdata = data;
  }
}
