import { Component, OnInit, Input } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { Router } from '@angular/router';
@Component({
  selector: 'rsa-quotationnumber',
  templateUrl: './quotation-number.component.html',
  styleUrls: ['./quotation-number.component.scss']
})
export class QuotationnumberComponent extends BaseSearchComponent implements OnInit {
  @Input() category;
  @Input('quotationnumber') quotationnumber: any;
  @Input() resultdata;
  @Input() classcode;
  @Input() lobtitle;
  glnumber: string;
  showtabledata: number;
  idnumber = '201838683';
  name = ' ';
  constructor(private router: Router) {
    super()
    console.log(this.category, 'category');
  }

  ngOnInit() {
    super.ngOnInit();
  }
  searchPolicy(event, data) {
    console.log(data);
    const polyiceNumber = data.PolicyNumber;
    const params = {
      'inputData': polyiceNumber,
      'category': 1,
      'categoryitem': 'Policy No',
      'classCode': this.classcode,
      'lobitem' : this.lobtitle
    };
    this.router.navigate(['home/search/result'], {
      queryParams: params
    });
  }
}
