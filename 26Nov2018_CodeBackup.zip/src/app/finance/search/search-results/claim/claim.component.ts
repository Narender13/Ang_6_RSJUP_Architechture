import { Component, OnInit, Input } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateClaimReceiptComponent } from 'src/app/finance/search/search-results/claim/create-claim-receipt/create-claim-receipt.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { LocaleDataIndex } from '@angular/common/src/i18n/locale_data';
import { CreateCreditnotesComponent } from 'src/app/finance/creditnotes/create-creditnotes/create-creditnotes.component';

@Component({
  selector: 'rsa-claim',
  templateUrl: './claim.component.html',
  styleUrls: ['./claim.component.scss']
})
export class ClaimComponent extends BaseSearchComponent implements OnInit {
  @Input('resultdata') resultdata: any = [];
  @Input('claimNo') claimNo: any;
  @Input('category') category: any;
  @Input('userdata') userdata: any;
  selectedClaimboxLists = [];
  name = ' ';
  idnumber = '201838683';
  showtabledata: number;
  res;
  showSnackBar: boolean;
  totalAmount;
  totalCount;
  bsModalRef: BsModalRef;
  customerName: string;
  selectedTransactionType: string;
  private ClaimPaymentType: Array<string> = ['EXCESS', 'SALVAGE', 'THIRDPARTYRECOVERY'];
  private ClaimPaymentTypeOthers: Array<string> = ['CLAIM', 'SALVAGE FEE'];

  constructor(private router: Router, private modalService: BsModalService,
    private alertService: AlertService) { super() }

  ngOnInit() {
    this.customerName = this.resultdata[0].CustomerName;
    console.log(this.customerName, 'customername');
  }

  toggle(index: number): void {
    this.showtabledata = (this.showtabledata !== index) ? index : -1;
  }


  /* get all transactionType and return the current type */
  private getTransactionType(transaction: string): 'CLAIM' | 'OTHERS' {
    if (this.ClaimPaymentType.includes(transaction)) {
      return 'CLAIM';
    } if (this.ClaimPaymentTypeOthers.includes(transaction)) {
      return 'OTHERS';
    }
  }

  /*checkbox set true or false */
  getCheckBoxState(index) {
    return this.selectedClaimboxLists.some((cur) => cur.i === index);
  }

  updateSelectedList(e, item, index) {
    console.log('item', item);
    const isCheckBoxSelect = e.srcElement.checked;

    /*get current payment type */
    const curPamentType = this.getTransactionType(item.PaymentType);

    /*set current transcation payemnt type*/
    if (isCheckBoxSelect && !this.selectedTransactionType) {
      this.selectedTransactionType = curPamentType;
      console.log(this.selectedTransactionType, 'selctedtranstype');
    }


    /* campare item with getTransactionType with selected payment and ingnore other transaction type */
    if (isCheckBoxSelect && this.selectedTransactionType && curPamentType !== this.selectedTransactionType) {
      this.alertService.warn(`you cant include ${this.selectedTransactionType} TransactionType with other TransactionType`);
      e.srcElement.checked = false;
      return;
    }

    /*after selecting the checkbox push to some variable and campare  */

    if (isCheckBoxSelect) {
      this.selectedClaimboxLists.push({ item: item, i: index });
      console.log(this.selectedClaimboxLists, 'selectedClaimboxLists');
      if (this.selectedTransactionType === 'CLAIM') {
        this.totalAmount = this.selectedClaimboxLists.reduce((prevVal, elem) => prevVal + elem.item.Amount, 0);
        console.log(this.totalAmount, 'cliamamount');
        this.totalCount = this.selectedClaimboxLists.length;
        console.log(this.totalCount, 'cliamamount');
        this.createButton([
          { id: '8', name: 'Receipt' },
          { id: '6', name: 'Credit Note' },
        ]);
        // this.createButton([
        //   { id: '6', name: 'Credit Note' },
        // ]);
        this.showSnackBar = true;
      }
      // if (this.selectedTransactionType === 'OTHERS') {
      //   this.totalAmount = this.selectedClaimboxLists.reduce((prevVal, elem) => prevVal + elem.item.Amount, 0);
      //   console.log(this.totalAmount, 'cliamamount');
      //   this.totalCount = this.selectedClaimboxLists.length;
      //   console.log(this.totalCount, 'cliamamount');
      //   this.createButton([
      //     { id: '8', name: 'Others' },
      //   ]);
      //   this.showSnackBar = true;
      // }
    } else {
      const currentIndex = this.selectedClaimboxLists.findIndex((curitem) => curitem.i === index);
      this.selectedClaimboxLists.splice(currentIndex, 1);
      console.log(this.selectedClaimboxLists, 'selectedClaimboxLists');
      if (!this.selectedClaimboxLists.length) {
        this.selectedTransactionType = undefined;
        this.showSnackBar = false;
      }
      this.totalAmount = this.selectedClaimboxLists.reduce((prevVal, elem) => prevVal + elem.item.Amount, 0);
      this.totalCount = this.selectedClaimboxLists.length;
    }
  }

  /* create claim receipt using snackbar  */
  buttonHandler(e) {
    if (e === '8') {
      this.showSnackBar = false;
      this.bsModalRef = this.modalService.show(CreateClaimReceiptComponent, { class: 'create-modal-dailog' });
      this.bsModalRef.content.totalAmount = this.totalAmount;
      this.bsModalRef.content.selectedRowItem = this.selectedClaimboxLists;
      this.bsModalRef.content.customerName = this.customerName;
    }
    if (e === '6') {
      this.showSnackBar = false;
      const initialState = {
        selectedRowItem: this.selectedClaimboxLists,
        totalAmount: this.totalAmount,
        customerName: this.customerName,
        ondemandFlag: false
      }
      this.bsModalRef = this.modalService.show(CreateCreditnotesComponent, { class: 'create-modal-dailog', initialState });
      this.bsModalRef.content.title = 'Credit Note';

    }
  }

  /* hide snackbar == make selected checkbox empty and reset selected TransactionType */
  hideSnackBar(e) {
    this.showSnackBar = false;
    this.selectedClaimboxLists = [];
    this.selectedTransactionType = undefined;
  }



}
