import { Component, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { INVALID } from '@angular/forms/src/model';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { SharedService } from 'src/app/finance/services/shared.service';
@Component({
  selector: 'rsa-create-claim-receipt',
  templateUrl: './create-claim-receipt.component.html',
  styleUrls: ['./create-claim-receipt.component.scss']
})
export class CreateClaimReceiptComponent implements OnInit {

  title = 'Receipt';
  level: any = 1;
  amount = 0;
  currency: any;
  collapsetoheader: boolean;
  createReceiptForm: FormGroup;
  payeedataBankName: any = [];
  receiverdataBankName: any = [];
  terminals: any = [];
  getbankterminaldetails = {};
  getglcodeanduser: any;
  errorMsg: string;
  searchkey: any;
  id: any;
  isExpaned = false;
  returnValue: any;
  results: any;
  slided;
  pjctindicator: any = [];
  department: any = [];
  placeholder: any;
  glaccount: any = [];
  totallingacc: any = [];
  hdrtotallingacc: any = [];
  transactiontype: any = [];
  private masterdata: any = [];
  private masterdata2: any = [];
  costcentredata: any = [];
  branchdata: any = [];
  users: any = [];
  RcptMode = 2;
  displayApprover = false;
  approverusers: string;
  totalAmount = 0;
  symbol: string;
  arrUser: any = [];
  minDateRd;
  maxDateRd;
  minDateCr;
  userlist;
  usersReq = true;
  glerrorcount = 0;
  paymentname = 'CASH';
  errorpayee: boolean;
  errordetail: boolean;
  errorbankcode: boolean;
  errorchequedate: boolean;
  errorchequeno: boolean;
  errorinstrumentrefno: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  dtltotallingacc = [];
  selectedTableData = [];
  customerName;
  currentTbIndex = 0;
  cachedGL: any = [];
  previewFlag = false;
  prevReceipt: any;
  previewDataDtl: any = [];
  cachedPayeeBankData: any = [];
  cachedDtlTot: any = [];

  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(
    private ref: ChangeDetectorRef,
    public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private createservice: CreateService,
    private masterDataService: MasterDataService,
    private modalService: BsModalService,
    private alertService: AlertService,
    private sharedService: SharedService,
    private router: Router) {
    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);
  }


  ngOnInit() {
    console.log(this.RcptMode, 'RcptMode');
    this.getAllMasterData(1110);
    this.getAllMasterData2();
    this.getTotallingData(localStorage.getItem('costcentre'));
    this.getBankData(1110);
    this.createReceiptFormD(this.RcptMode);
    this.symbol = (localStorage.getItem('symbol'));
    this.minDateCr = new Date();
    this.minDateCr.setDate(this.minDateCr.getDate() - 0);
    this.fieldStatusChanges();
    this.getPayeeBankData(true);
    this.getSeletedData();
    this.getSum();
    this.previousFromPreview();


  }
  previousFromPreview() {
    this.sharedService.getMessage().subscribe(val => {
      if (val == 'previous') {
        this.previewFlag = false;
      } else if (val == 'close') {
        this.modalService.hide(1);
      }
      this.prevReceipt = val.id;
      this.previewDataDtl = val.data;
      if (this.previewDataDtl != null || this.previewDataDtl != undefined) {
        this.doPatchRefFields();
      }
    });
  }

  getSeletedData() {
    setTimeout(() => {
      this.totalAmount = this.bsModalRef.content.totalAmount;
      this.selectedTableData = this.bsModalRef.content.selectedRowItem;
      this.selectedTableData.map((item, index) => this.addReceipt(item.item, index + 1, false));
      this.customerName = this.bsModalRef.content.customerName;
      console.log(this.totalAmount, 'claimdata');
      this.setPayeName();
    }, 10);
  }

  doPatchRefFields() {
    let formarray = (<FormArray>this.createReceiptForm.controls['ReceiptDetails']);
    formarray.controls.map((item, index) => {
      item.get("RefTransactionID").setValue(this.previewDataDtl[index].RefTransactionID);
      item.get("RefTransactionSerialNo").setValue(this.previewDataDtl[index].RefTransactionSerialNo);
    });
  }
  setPayeName() {
    this.createReceiptForm.controls['PayeeName'].setValue(this.customerName);
  }

  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcode = false;
    this.errorchequedate = false;
    this.errorchequeno = false;
    this.errorinstrumentrefno = false;
    this.errorterminalID = false;
    this.errorexpirydate = false;
  }

  getFromFormArrayControlVal(contrlname, index) {
    return (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls[index].get(contrlname).value;
  }

  getTotallingDetailData(index, initFlag) {
    let loccode = this.getFromFormArrayControlVal('BranchCode', index);
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);

    const param = 'locationCode=' + loccode +
      '&paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingDetailData(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;
        //alert(this.dtltotallingacc[index][0]);
        let totcode = this.dtltotallingacc[index][0].TotAccCode;
        if (!initFlag)
          this.setFormArrayCTRLDefaultValue("TotallingAccCode", index, totcode);
        if (initFlag) {
          this.cachedDtlTot = dataReturn;
        }
        this.getGLData(index, initFlag, totcode);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  fieldStatusChanges() {

    this.clearerrors();

    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status == 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status == 'INVALID');
      }
    );
    if (this.payeebankcode != null && this.payeebankcode != undefined) {
      this.payeebankcode.statusChanges.subscribe(
        status => {
          this.errorbankcode = (status == 'INVALID');
        }
      );
    }
    if (this.chequedate != null && this.chequedate != undefined) {
      this.chequedate.statusChanges.subscribe(
        status => {
          this.errorchequedate = (status == 'INVALID');
        }
      );
    }
    if (this.chequeno != null && this.chequeno != undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequeno = (status == 'INVALID');
        }
      );
    }
    // if (this.instrumentrefno != null && this.instrumentrefno != undefined) {
    //   this.instrumentrefno.statusChanges.subscribe(
    //     status => {
    //       this.errorinstrumentrefno = (status == 'INVALID');
    //     }
    //   );
    // }
    if (this.terminalid != null && this.terminalid != undefined) {
      this.terminalid.statusChanges.subscribe(
        status => {
          this.errorterminalID = (status == 'INVALID');
        }
      );
    }
    if (this.expirydate != null && this.expirydate != undefined) {
      this.expirydate.statusChanges.subscribe(
        status => {
          this.errorexpirydate = (status == 'INVALID');
        }
      );
    }

  }
  goNext() {
    //this.cshpayeename.markAsTouched();

    console.log(this.cshdetails.value, 'this.cshdetails');

    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;

    if (this.payeebankcode != null && this.payeebankcode !== undefined) {
      this.errorbankcode = this.payeebankcode.invalid;
      console.log(this.payeebankcode.invalid, 'this.payeebankcode.invalid');
    }

    if (this.chequedate != null && this.chequedate !== undefined) {
      this.errorchequedate = this.chequedate.invalid;
    }


    if (this.chequeno != null && this.chequeno !== undefined) {
      this.errorchequeno = this.chequeno.invalid;
    }


    // if (this.instrumentrefno != null && this.instrumentrefno != undefined)
    //   this.errorinstrumentrefno = this.instrumentrefno.invalid;

    if (this.terminalid != null && this.terminalid !== undefined) {
      this.errorterminalID = this.terminalid.invalid;
    }


    if (this.expirydate != null && this.expirydate !== undefined) {
      this.errorexpirydate = this.expirydate.invalid;
    }




    if (!this.errorpayee && !this.errordetail && !this.errorchequedate && !this.errorchequeno
      && !this.errorterminalID && !this.errorexpirydate) {
      (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
      this.level = 2;
      // this.getGLData(1110, 0);
      // this.getTotallingDetailData(localStorage.getItem('costcentre'), 0);

    }

  }

  getSum() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.createReceiptForm.controls['ReceiptDetails'];
    ctrl.controls.forEach(val => {
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value) ||
        val.get('Amount').value == '') ? 0 : val.get('Amount').value;
      this.totalAmount += parseFloat(amt);
    });

    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;

  }

  setReceiptMode(val, paymentname) {
    this.createReceiptForm.controls['ReceiptMode'].setValue(val);
    this.RcptMode = val;
    this.paymentname = paymentname;
    console.log(this.RcptMode, 'set');
    this.createReceiptFormD(this.RcptMode);


    if (this.RcptMode == 1) {
      this.createReceiptForm.controls.TotallingAccCode.setValue('1210');
    }
    else {
      this.createReceiptForm.controls['TotallingAccCode'].setValue('1110');
      this.createReceiptForm.controls['RecevierBankCode'].setValue('14');
    }

    this.fieldStatusChanges();
    this.setPayeName();
  }



  setBankData(val) {
    this.createReceiptForm.controls['RecevierBankCode'].setValue('');
    this.getBankData(val);
  }

  getGLData(index, initFlag, val) {
    let loccode = this.getFromFormArrayControlVal('BranchCode', index);
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);
    let totcode = (initFlag) ? this.getFromFormArrayControlVal('TotallingAccCode', index) : val;

    let param = 'locationCode=' + loccode +
      '&totallingAccCode=' + totcode +
      '&CostCenterCode=' + ccentre;
    console.log('param-GL', param);


    this.masterDataService.getGLData(param).subscribe(
      dataReturn => {
        this.glaccount[index] = dataReturn;
        console.log(this.glaccount, 'glacount');
        if (!initFlag)
          this.setFormArrayCTRLDefaultValue("GLCode", index, this.glaccount[index][0].GLCode);
        this.setFormArrayCTRLDefaultValue("GLCodeDesc", index, this.glaccount[index][0].GLEngDescription);
        if (initFlag) this.cachedGL = dataReturn;
        console.log(this.cachedGL, 'cachedGL');
      },
      errorRturn => this.errorMsg = errorRturn
    );
    if (this.level == 2) {
      (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls.map(item => {
        // item.get('Amount').clearValidators();
        // item.get('GLCode').clearValidators();
        item.get('Amount').updateValueAndValidity();
        item.get('GLCode').updateValueAndValidity();
      });
    }
  }

  getFormCtrlValue(contrlName) {
    return this.createReceiptForm.controls[contrlName].value;
  }

  getPayeeBankData(initFlag) {
    const param = this.getFormCtrlValue('LocationCode');
    this.masterDataService.getPayeeBankData(param).subscribe(
      dataReturn => {
        this.payeedataBankName = dataReturn;
        this.createReceiptForm.controls['PayeeBankCode'].setValue(this.payeedataBankName[0].BankCode);
        if (initFlag) {
          this.cachedPayeeBankData = dataReturn;
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  getBankData(totAcc) {
    console.log(totAcc, 'totAcc');
    const param = 'locationCode=' + localStorage.getItem('locationcode') +
      '&totallingAccCode=' + totAcc +
      '&costCenter=' + localStorage.getItem('costcentre');
    this.masterDataService.getBankData(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getTotallingData(val) {
    const param = 'locationCode=' + localStorage.getItem('locationcode') +
      '&paymentMode=' + this.paymentname +
      '&costCenter=' + val;

    this.masterDataService.getTotallingData(param).subscribe(
      dataReturn => {
        this.totallingacc = dataReturn;
        console.log(this.totallingacc, 'this.totallingacc');
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  getAllMasterData(totalacc): void {
    this.masterDataService.getAllMasterData(totalacc).subscribe(
      dataReturn => {
        this.masterdata = dataReturn;
        console.log(dataReturn, ' : master data');
        this.payeedataBankName = this.masterdata.LoadPayeeBanks;
        this.terminals = this.masterdata.Terminals;
        this.pjctindicator = this.masterdata.ProjectIndicators;
        this.department = this.masterdata.Departments;
        console.log(this.department, 'd');
        console.log(this.pjctindicator, 'p');
        console.log(this.terminals, 't');
        this.transactiontype = this.masterdata.TransactionType;

      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getAllMasterData2(): void {
    this.masterDataService.getAllMasterData2().subscribe(
      dataReturn => {
        this.masterdata2 = dataReturn;
        console.log(dataReturn, ' : master data');
        this.glaccount = this.masterdata2.GLCodes;
        this.users = this.masterdata2.Users;
        this.branchdata = this.masterdata2.Locations;
        this.costcentredata = this.masterdata2.CostCenter;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  onUserChange(userid: string, isChecked: boolean, username: string) {
    const userFormArray = <FormArray>this.createReceiptForm.controls.Approvers;
    if (isChecked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value == userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
    }
    this.approverusers = this.arrUser.join();
    console.log(this.approverusers);
  }

  createReceiptFormD(param): void {
    this.createReceiptForm = this.fb.group({
      ReceiptDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptMode: [this.RcptMode],
      PrintDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptType: [0],
      PreparedBy: [1],
      ModifiedBy: ['1'],
      Approvers: this.fb.array([]),
      CustomerID: [],
      TerminalUserID: [20],
      TerminalUserName: [],
      CountryCode: [1],
      LocationCode: [localStorage.getItem('locationcode')],
      RegionCode: [localStorage.getItem('regioncode')],
      ReprintNo: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ArabicDescription: [],
      TotallingAccCode: [1110],
      RecevierBankCode: [14],
      PayeeName: ['', Validators.required],
      EnglishDescription: ['', Validators.required],
      ReceiptDetails: this.fb.array(this.selectedTableData.map(item => {
        const group = this.createNewcreateReceiptFormGroup();
        group.patchValue(item.item);
        return group;
      }))
    });
    switch (param) {
      case 1:
       // this.createReceiptForm.addControl('Amount', new FormControl(''));
        break;
      case 2:
        this.createReceiptForm.addControl('ChequeNo', new FormControl('', [Validators.required, Validators.maxLength(12)]));
        this.createReceiptForm.controls['ChequeNo'].updateValueAndValidity();
        this.createReceiptForm.addControl('ChequeDate', new FormControl(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required));
        this.createReceiptForm.controls['ChequeDate'].updateValueAndValidity();
        this.createReceiptForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.createReceiptForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.createReceiptForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.createReceiptForm.controls['PayeeBankName'].updateValueAndValidity();
        break;
      case 8:
        this.createReceiptForm.addControl('ChequeNo', new FormControl('', [Validators.required]));
        this.createReceiptForm.controls['ChequeNo'].updateValueAndValidity();
        this.createReceiptForm.addControl('InstrumentRefNo', new FormControl('', Validators.required));
        this.createReceiptForm.controls['InstrumentRefNo'].updateValueAndValidity();
        this.createReceiptForm.addControl('ChequeDate', new FormControl(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required));
        this.createReceiptForm.controls['ChequeDate'].updateValueAndValidity();
        this.createReceiptForm.addControl('TerminalID', new FormControl('', Validators.required));
        this.createReceiptForm.controls['TerminalID'].updateValueAndValidity();
        break;
      case 5:
        this.createReceiptForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.createReceiptForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.createReceiptForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.createReceiptForm.controls['PayeeBankName'].updateValueAndValidity();
        this.createReceiptForm.addControl('ChequeDate', new FormControl(new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required));
        this.createReceiptForm.controls['ChequeDate'].updateValueAndValidity();
        this.createReceiptForm.addControl('InstrumentRefNo', new FormControl('', Validators.required));
        this.createReceiptForm.controls['InstrumentRefNo'].updateValueAndValidity();

        break;
    }
  }


  createNewcreateReceiptFormGroup(): FormGroup {
    return this.fb.group({
      CounterPartyReferenceNo: [],
      LocationCode: [localStorage.getItem('locationcode')],
      BranchCode: [localStorage.getItem('locationcode')],
      LocationDesc: [],
      CountryCode: [],
      CostCenterCode: [11],
      ClassCode: [],
      LocationName: [],
      CostCenter: [],
      CounterPartyRef: [],
      TotallingAccName: [],
      Class: [],
      Description: [],
      Amount: ['', Validators.required],
      Amt: [],
      BranchName: [],
      RefTransactionID: [],
      IsCreditEntry: [true],
      RefTransactionType: [3],
      RefTranTypeDesc: [],
      RefTranType: [],
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: [],
      ReceiptDate: [],
      AnalysisCode: [],
      DepartmentCode: [],
      DepartmentName: [],
      Department: [],
      RefTransactionSerialNo: [],
      PlaceHolderCode: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      GLAccountName: [],
      GLAccount: [],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      ClaimID: [],
      VoucherType: [],
      TransactionNo: [],
      PolicyYear: [],
      PolicyType: [],
      VoucherNo: [],
      RefPolicyNo: [],
      RefPolicyYear: [],
      ReferenceID1: [],
      ReferenceID2: [],
      // Aaded new formControlName to make row readonly if coming from selection rows
      newAddedRow: false
    });
  }


  // setting current Tab Index to activiate tab
  setcurrentTbIndex(tab) {
    switch (tab) {
      case 'Cash':
        this.currentTbIndex = 2;
        break;
      case 'Cheque':
        this.currentTbIndex = 0;
        break;
      case 'Credit Card':
        this.currentTbIndex = 1;
        break;
      case 'Bank Transfer':
        this.currentTbIndex = 3;
    }
  }
  // Displaying the  confirmation alert on tab click
  confirmTabSwitch(event) {
    console.log(event.target.tagName);
    const parentElement = event.target.parentElement;
    const target = event.target.parentElement.text;
    if (event.target.tagName === 'SPAN' && !parentElement.classList.contains('active') && parentElement.classList.contains('nav-link')) {
      if (this.createReceiptForm.dirty) {
        // --- showing popup only you have added or changed something
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        // Will move the content to RSAMSGConstants once approved // 
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.PAYMENTMODECHANGEMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          console.log(data);
          // changing the currentTbIndex if user proceed
          if (data = RSAMSGConstants.BTNPROCEED) {
            console.log(this.currentTbIndex);
            setTimeout(() => {
              this.setcurrentTbIndex(target);
            }, 0);
            setTimeout(() => {
              this.tabset.tabs[this.currentTbIndex].active = true;
            }, 1);
          }
        });
      } else {
        setTimeout(() => {
          this.setcurrentTbIndex(target);
        }, 0);
        setTimeout(() => {
          this.tabset.tabs[this.currentTbIndex].active = true;
        }, 1);

      }

    }
  }

    setFormArrayCTRLDefaultValue(contrlname, index, val) {
    (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls[index].get(contrlname).setValue(val);
  }
  addReceipt(item, len?, newAdded?) {
    const control = <FormArray>this.createReceiptForm.controls['ReceiptDetails'];
    console.log(control);
    console.log(item);
    const newRow = this.createNewcreateReceiptFormGroup();
    newRow.patchValue(item);
    control.push(newRow);
    const CurrentAmount = (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls[len - 1].get('Amount').value;
    if (newAdded) {
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      newRow.patchValue({ 'newAddedRow': true });
      this.getTotallingDetailData(len, false);
    }
    const newAddedRow = (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls[len - 1].get('newAddedRow').value;
    console.log(newAddedRow, 'newaddrow');

    // if (newAddedRow && CurrentAmount > 0) {
    //   // this.getTotallingDetailData(len, false);
    //   /// (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls[len].get('Amount').value;
    // } else {
    //   this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    //   this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    //   this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
    //   this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
    //   control.removeAt(len);
    //   return false;
    // }
  }


  // addReceipt(len) {
  //   const control = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
  //   const CurrentAmount = (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[len - 1].get('Amount').value;
  //   if (CurrentAmount > 0) {
  //     control.push(this.createNewcreateReceiptEntitiFormGroup());
  //     (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[len - 1].get('GLCode').setValue(4);
  //     this.getTotallingDetailData(11, len);
  //     this.getGLData(1110, len);
  //   } else {
  //     this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
  //     this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
  //     this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
  //     this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
  //     return false;
  //   }
  // }

  setHiddenValue(ev, iter, key, setKey) {
    (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.item[setKey]);
  }
  setCreditEntry(ev, iter, key, data) {
    console.log(iter, 'key');
    const curdata = -(data.controls['Amount'].value);
    data.controls['Amount'].patchValue(curdata);
    this.getSum();
    (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.target.checked);
    if (this.totalAmount < 0) {
      ev.target.checked = true;
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CREDITEXCEEDMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      data.controls['Amount'].patchValue(-curdata);
      this.getSum();
    }

  }
  setTerminalCode(ev, key, setKey) {
    console.log(ev, 'ev');
    this.createReceiptForm.controls[key].setValue(ev.item[setKey]);
  }
  setBankCode(ev, iter, key) {
    this.createReceiptForm.controls[key].setValue(ev.item.BankCode);
  }

  get cshpayeename() { return this.createReceiptForm.get('PayeeName'); }
  get cshdetails() { return this.createReceiptForm.get('EnglishDescription'); }
  get payeebankcode() { return this.createReceiptForm.get('PayeeBankCode'); }
  get chequedate() { return this.createReceiptForm.get('ChequeDate'); }
  get instrumentrefno() { return this.createReceiptForm.get('InstrumentRefNo'); }
  get terminalid() { return this.createReceiptForm.get('TerminalID'); }
  get expirydate() { return this.createReceiptForm.get('ExpiryDate'); }
  get chequeno() { return this.createReceiptForm.get('ChequeNo'); }

  get receiptRows() { return <FormArray>this.createReceiptForm.get('ReceiptDetails'); }

  reSetForm(param) {
    /*set default value here and reset */
    if (param == 1) {
      const arrayFields = ['PayeeName', 'EnglishDescription', 'ChequeNo', 'ChequeDate', 'PayeeBankCode',
        'PayeeBankName', 'ExpiryDate', 'InstrumentRefNo', 'TerminalID'];
      this.createReceiptForm.controls['LocationCode'].reset([localStorage.getItem('locationcode')]);
      this.createReceiptForm.controls['CostCenterCode'].reset([localStorage.getItem('costcentre')]);
      this.createReceiptForm.controls['TotallingAccCode'].reset([1110]);
      this.createReceiptForm.controls['RecevierBankCode'].reset([14]);
      this.createReceiptForm.controls['PayeeName'].reset();
      this.createReceiptForm.controls['EnglishDescription'].reset();

      arrayFields.forEach((val) => {
        if (this.createReceiptForm.controls[val] != null && this.createReceiptForm.controls[val] != undefined) {
          this.createReceiptForm.controls[val].reset();
        }
      });
      this.clearerrors();
    } else if (param == 2) {
      this.createReceiptForm.controls['ReceiptDetails'].reset();
      this.getSum();
    }
  }

  deleteReceipt(index: number, itemrow) {
    console.log(itemrow, 'itemrow');
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = RSAMSGConstants.BTNPROCEED) {
        const control = <FormArray>this.createReceiptForm.controls['ReceiptDetails'];
        control.removeAt(index);
        this.getSum();
      }
    });

  }

  checkIsformDirty() {
    if (this.createReceiptForm.dirty || this.createReceiptForm.touched) {
      console.log('cmg here');
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = 'Proceed') {
          this.modalService.hide(1);
        }
      });

    } else {
      this.modalService.hide(1);
    }
  }

  validateDetailInfo() {
    (<FormArray>this.createReceiptForm.controls['ReceiptDetails']).controls.map(item => {
      item.get('Amount').markAsTouched();
      item.get('GLCode').markAsTouched();
      this.glerrorcount = 0;
      if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
    });
  }

  submitForm(bsModalRef, receiptno) {
    // const chequeDate = this.createReceiptForm.get('ChequeDate').value;
    // this.createReceiptForm.controls['ChequeDate']
    //   .setValue(getShortDate(new Date(chequeDate)));
    this.validateDetailInfo();
    // if (this.glerrorcount > 0) {
    //   return false;
    // }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    let formval = this.createReceiptForm.value;
    console.log(formval, 'value');
    if (this.totalAmount > 0) {
      if (this.totalAmount > 99999 && !this.usersReq) {
        return false;
      }
      if (this.prevReceipt == null || this.prevReceipt == undefined)
        this.prevReceipt = 0;
      formval["ReceiptNo"] = this.prevReceipt;

      this.createservice.createReceipt(JSON.stringify(formval)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          console.log(this.returnValue, 'value');
          this.returnValue['approverlist'] = this.approverusers;
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
    }
  }


  goPrevious() {
    this.level = 1;
  }
  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
  }

}
