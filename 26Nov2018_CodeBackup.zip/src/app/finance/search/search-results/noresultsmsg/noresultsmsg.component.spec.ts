import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoresultsmsgComponent } from './noresultsmsg.component';

describe('NoresultsmsgComponent', () => {
  let component: NoresultsmsgComponent;
  let fixture: ComponentFixture<NoresultsmsgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoresultsmsgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoresultsmsgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
