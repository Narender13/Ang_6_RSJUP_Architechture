import { Injectable } from '@angular/core';


@Injectable({
    providedIn: 'root'
})

export class GridService {
    getEntityColumnHeaderPropertyNames() {
        return [
            {
                headerName: 'GlCode',
                field: 'GlCode',
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
                checkboxSelection: true,
                type: 'numberColumn',
                filter: 'agSetColumnFilter',
                cellRenderer: 'group',
                cellRendererParams: { suppressCount: true },
                filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },


            },
            {
                headerName: 'VoucherNo',
                field: 'VoucherNo',
                type: 'numericColumn',
                filter: 'agNumberColumnFilter',
            },
            {
                headerName: 'VoucherType',
                field: 'VoucherType',
                filter: 'agSetColumnFilter',
                // cellStyle: function (params) {
                //     console.log(params);
                //     if (params.value === 'Debit Note') {
                //         return { color: 'red', backgroundColor: 'green' };
                //     } else {
                //         return null;
                //     }
                // },
                cellClass: function (params) {
                    return (params.value === 'Credit Note' ? 'credit' : '');
                }
            },
            {
                headerName: 'VoucherDate',
                field: 'VoucherDate',
                filter: 'agDateColumnFilter',

            },
            {
                headerName: 'TransactionType',
                field: 'TransactionType',
                filter: 'agSetColumnFilter',
            },
            {
                headerName: 'Class',
                field: 'Class',
                filter: 'agSetColumnFilter',

            },
            {
                headerName: 'TransactionNo',
                field: 'TransactionNo',
                filter: 'agTextColumnFilter',

            },
            {
                headerName: 'CustomerName',
                field: 'CustomerName',
                filter: 'agSetColumnFilter',
            },
            {
                headerName: 'Amount',
                field: 'Amount',
                type: 'numericColumn',
                filter: 'agNumberColumnFilter',

            }
        ];
    }

}
