
import { Component, OnInit, ViewChild, AfterViewInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { Entitie } from 'src/app/finance/search/search-results/datatable/model/entitie';
import { GridService } from 'src/app/finance/search/search-results/datatable/services/grid-service';

@Component({
  selector: 'app-datatable',
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.scss']
})
export class DatatableComponent implements OnInit, AfterViewInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi;
  gridColumnApi;
  paginationOptions = [];
  selectedData;
  detailRowHeight;
  detailCellRendererParams;
  gridConfiguration: GridOptions = {};
  @Input('rowData') rowData: Entitie[];
  columnDefs = [];
  constructor(private http: HttpClient, private gridservice: GridService) {
    console.log(this.rowData, 'rowData');
    this.paginationOptions = [
      { label: 'Ten', value: '10' },
      { label: 'hundred', value: '100' },
      { label: 'fivehundred', value: '500' },
      { label: 'thousand', value: '1000' }
    ];


    this.gridConfiguration = <GridOptions>{
      columnDefs: this.gridservice.getEntityColumnHeaderPropertyNames(),
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 10,
      enableRangeSelection: true,
      rowSelection: 'multiple',
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      masterDetail: true,
      suppressContextMenu: true,
      enableSorting: true,
      suppressRowClickSelection: false,
      defaultColDef: {
        enableRowGroup: false, enableValue: true,
        minWidth: 100, menuTabs: ['filterMenuTab', '', '']
      },
    };
    this.detailRowHeight = 190;
    this.detailCellRendererParams = {
      getDetailRowData: function (params) {
        console.log(params);
        setTimeout(function () {
          params.successCallback(params.data);
        }, 1000);
      },

      template: function (params) {
        const counterpartyRefNo = params.data.CounterPartyReferenceNumber;
        const recptDesc = params.data.Description;
        const refId = params.data.RefTranID;
        const refType = params.data.RefTranType;
        const refTranNo = params.data.RefTranSerialNo;
        const dept = params.data.DepartmentName;
        const prInd = params.data.ProjectIndicator;
        const placeholder = params.data.PlaceHolder;
        const preBy = params.data.PreparedBy;
        const predate = params.data.PreparedDate;
        const aprBy = params.data.ApprovedBy;
        const aprDate = params.data.ApprovedDate;

        return (
          '<div class="entity-parent">' +
          '<div class="entitie-detail">' +

          '<div class="flex-inline row">' +
          '<div class="block col-lg-3 ">' +
          '<div class="e-title">Counter Party Ref No.' +
          '</div>' +
          '<div class="e-title-re">' + counterpartyRefNo +
          '</div>' +
          '</div>' +

          '<div class="block col-lg-3 ">' +
          '<div class="e-title">Receipt Description' +
          '</div>' +
          '<div class="e-title-re">' + recptDesc +
          '</div>' +
          '</div>' +

          '<div class="block col-lg-3 ">' +
          '<div class="e-title">ReferenceID' +
          '</div>' +
          '<div class="e-title-re">' + refId +
          '</div>' +
          '</div>' +

          '<div class="block col-lg-3 ">' +
          '<div class="e-title">ReferencTransType' +
          '</div>' +
          '<div class="e-title-re">' + refType +
          '</div>' +
          '</div>' +
          '</div>' +

          '<div class="flex-inline row">' +
          '<div class="block col-lg-3 ">' +
          '<div class="e-title">ReferenceTranSNo' +
          '</div>' +
          '<div class="e-title-re">' + refTranNo +
          '</div>' +
          '</div>' +

          '<div class="block col-lg-3 ">' +
          '<div class="e-title">Dept' +
          '</div>' +
          '<div class="e-title-re">' + dept +
          '</div>' +
          '</div>' +

          '<div class="block col-lg-3 ">' +
          '<div class="e-title">projectindicator' +
          '</div>' +
          '<div class="e-title-re">' + prInd +
          '</div>' +
          '</div>' +

          '<div class="block col-lg-3 ">' +
          '<div class="e-title">Placeholder' +
          '</div>' +
          '<div class="e-title-re">' + placeholder +
          '</div>' +
          '</div>' +
          '</div>' +

          '<div class="flex-inline row">' +
          '<div class="block col-lg-3 ">' +
          '<div class="e-title">PreparedBy' +
          '</div>' +
          '<div class="e-title-re">' + preBy +
          '</div>' +
          '</div>' +

          '<div class="block col-lg-3 ">' +
          '<div class="e-title">PreparedDate' +
          '</div>' +
          '<div class="e-title-re">' + predate +
          '</div>' +
          '</div>' +

          '<div class="block col-lg-3 ">' +
          '<div class="e-title">ApprovedBy' +
          '</div>' +
          '<div class="e-title-re">' + aprBy +
          '</div>' +
          '</div>' +

          '<div class="block col-lg-3 ">' +
          '<div class="e-title">ApprovedDate' +
          '</div>' +
          '<div class="e-title-re">' + aprDate +
          '</div>' +
          '</div>' +
          '</div>' +

          '</div>' +
          '</div>'
        );

      }
    };

  }


  ngOnInit() {
    console.log(this.rowData, 'rowData');
  }

  ngAfterViewInit() {
    this.gridConfiguration.api.sizeColumnsToFit();
  }
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(4);
    this.gridConfiguration.api.sizeColumnsToFit();
  }


  getSelectedRows() {
    const selectedNodes = this.agGrid.api.getSelectedNodes();
    console.log(selectedNodes);
    this.selectedData = selectedNodes.map(node => node.data);
    console.log(this.selectedData[0].GLCode);
    const selectedDataStringPresentation = this.selectedData.map(node => node.GLCode + ' ' + node.VoucherNo).join(',');
    console.log(`Selected nodes: ${selectedDataStringPresentation}`);
  }

  // onFilterTextBoxChanged(e): any {
  //   const value = e.srcElement.value;
  //   this.gridApi.setQuickFilter(value);
  // }

  onPageSizeChanged(newPageSize: HTMLSelectElement) {
    const value = +(newPageSize.srcElement.value);
    console.log(value, 'newPageSize');
    this.gridApi.paginationSetPageSize(value);
    this.gridApi.sizeColumnsToFit();
  }


  onQuickFilterChanged(e) {
    this.gridApi.setQuickFilter(e.data);
  }
}
