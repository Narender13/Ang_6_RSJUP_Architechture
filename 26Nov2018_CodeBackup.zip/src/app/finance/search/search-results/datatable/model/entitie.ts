export interface Entitie {
    EntityCode: number;
    EntityType: string;
    GlCode: number;
    VoucherNo: number;
    VoucherType: string;
    VoucherDate: Date;
    TransactionType: string;
    Class: number;
    TransactionNo: number;
    Amount: number;
    CustomerName: string;
    CounterPartyReferenceNo?: any;
    Description: string;
    RefTranID: number;
    RefTranType: string;
    RefTranSerialNo: number;
    DepartmentName?: any;
    ProjectIndicator?: any;
    PlaceHolder?: any;
    PreparedBy?: any;
    ApprovedBy?: any;
    ApprovedDate?: any;
    PreparedDate?: any;
    Matched?: number;
    PolicyId?: number;
    ClaimId?: number;
    Endt_ID?: number;
    Policy_No?: number;
}

