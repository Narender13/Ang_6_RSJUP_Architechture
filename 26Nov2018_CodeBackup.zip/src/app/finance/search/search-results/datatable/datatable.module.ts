
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { DatatableComponent } from 'src/app/finance/search/search-results/datatable/datatable.component';


@NgModule({
    declarations: [
        /* components */
        DatatableComponent,


        /* directives */

        /* Pipes */


    ],
    imports: [
        CommonModule,
        HttpClientModule,
        AgGridModule,
        AgGridModule.withComponents([

        ])


    ],
    providers: [],
    exports: [
        /* components */
        DatatableComponent,

        /* directives */

        /* Pipes */

        /* modules */

    ]
})
export class DataTableModule { }
