import { Component, OnInit, Input, ViewChild, ElementRef, AfterViewInit, QueryList } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component'
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CreateClaimReceiptComponent } from 'src/app/finance/search/search-results/claim/create-claim-receipt/create-claim-receipt.component';
import { SharedService } from 'src/app/finance/services/shared.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';

@Component({
  selector: 'rsa-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.scss']
})
export class PolicyComponent extends BaseSearchComponent implements OnInit, AfterViewInit {
  @Input() category: string;
  @Input('resultdata') resultdata: any = [];
  @Input('policynumber') policynumber: any;
  @Input() lobtitle;
  @ViewChild('isCheckedRef')
  private isCheckedTempRef: QueryList<ElementRef>;
  showtabledata: number;
  glnumber: string;
  idnumber: number;
  name: string;
  totalAmount = 0;
  totalCount = 0;
  showSnackBar = true;
  bsModalRef: BsModalRef;
  customerName;
  selectedItems = [];
  constructor(private modalService: BsModalService, private sharedService: SharedService, private alertService: AlertService) { super() }

  ngOnInit() {
    this.idnumber = 201838683;
    this.glnumber = '';
    this.name = ' ';
    this.customerName = this.resultdata[0].CustomerName;
    console.log(this.customerName, 'customername');
    super.ngOnInit();
    this.createButton([
      { id: '11', name: 'receipt' },
      // { id: '12', name: 'payment' },
      // { id: '13', name: 'debit note' },
      // { id: '14', name: 'credit note' },
      // { id: '15', name: 'journal' },
    ]);
    // this.resultdata.push({
    //   id23: 'anki',
    // });
  }

  ngAfterViewInit() {
    console.log(this.isCheckedTempRef, 'isChecked');
  }

  /*checkbox set true or false */
  getCheckBoxState(index) {
    return this.selectedItems.some((cur) => cur.i === index);
  }

  updateSelectedOutstandingList(e, data, index) {
    const isCheckBoxSelect = e.srcElement.checked;

    // /* adding details feild to selected array */
    // const modifyArrayData = data;
    // modifyArrayData.TotallingAccCode = data1.TotallingAccCode;
    // modifyArrayData.RefTransactionID = data1.RefTransactionID;
    // modifyArrayData.RefTransactionSerialNo = data1.RefTransactionSerialNo;
    // modifyArrayData.RefTransactionType = data1.RefTransactionType;
    // modifyArrayData.GLCode = data1.GLCode;
    // modifyArrayData.GLCodeDesc = data1.GLCodeDesc;
    // modifyArrayData.PolicyNumber = data1.PolicyNumber;
    // modifyArrayData.CostCenter = data1.CostCenter;
    // modifyArrayData.Endt_ID = data1.Endt_ID;
    // modifyArrayData.TotallingAccName = data1.TotallingAccName;
    // modifyArrayData.CounterPartyReferenceNo = data1.CounterPartyReferenceNo;
    // modifyArrayData.LocationName = data1.LocationName;
    // modifyArrayData.LocationCode = data1.LocationCode;
    // modifyArrayData.CostCenterCode = data1.CostCenterCode;
    // modifyArrayData.CustomerName = data1.CustomerName;


    if (isCheckBoxSelect) {
      this.selectedItems.push({ item: data, i: index, eventRef: e.target });
      this.totalAmount += data.Amount ? data.Amount : data.claimIntimationDetails.Amount;
      console.log(this.selectedItems, 'selectedItems');
      this.totalCount++;
      this.showSnackBar = true;
    } else {
      this.totalCount--;
      this.totalAmount -= data.Amount ? data.Amount : data.claimIntimationDetails.Amount;
      const currentIndex = this.selectedItems.findIndex((curitem) => curitem.i === index);
      this.selectedItems.splice(currentIndex, 1);
      if (this.totalCount === 0) {
        this.showSnackBar = false;
        this.totalCount = 0;
      }
    }
  }

  buttonHandler(e) {
    if (e === '11' && this.totalAmount > 0) {
      this.showSnackBar = false;
      this.bsModalRef = this.modalService.show(CreateClaimReceiptComponent, { class: 'create-modal-dailog' });
      this.bsModalRef.content.totalAmount = this.totalAmount;
      this.bsModalRef.content.customerName = this.customerName;
      this.bsModalRef.content.selectedRowItem = this.selectedItems;
    } else {
      this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
    }
  }

  /* to unceck all the selected box*/
  unCheckAllSelectedCheckbox() {
    this.selectedItems.map(element => {
      element.eventRef.checked = false;
      this.selectedItems = [];
    });
  }

  hideSnackBar(e) {
    this.showSnackBar = false;
    this.unCheckAllSelectedCheckbox();
    this.totalAmount = 0;
    this.totalCount = 0;
  }

}
