import { Component, OnInit, Input } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component'

@Component({
  selector: 'rsa-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent extends BaseSearchComponent implements OnInit {

  @Input('resultdata') resultdata: any = [];
  @Input('paymentNo') paymentNo: any;
  @Input('category') category: any;
  glnumber: string;
  showtabledata = -1;
  idnumber = '201838683';
  name = ' ';
  pageSize = 15;
  currentpage: any = 1;
  constructor() { super() }

  ngOnInit() {
    super.ngOnInit();
  }
  toggle(index: number): void {
    this.showtabledata = (this.showtabledata !== index) ? index : -1;
  }
  checkbox(index: number, resuldata) {

  }
  pageChanged(ev) {
    this.currentpage = ev;
  }

}
