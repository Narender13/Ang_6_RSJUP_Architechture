import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalService } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { BatchUploadService } from 'src/app/finance/search/service/batch-upload.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { Customvalidators } from 'src/app/shared/validators/customvalidators';
import { SharedService } from 'src/app/finance/services/shared.service';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { ExcelService } from 'src/app/finance/search/service/excel.service';
import { TouchSequence } from 'selenium-webdriver';
@Component({
  selector: 'rsa-create-receipt-entiti',
  templateUrl: './create-receipt-entiti.component.html',
  styleUrls: ['./create-receipt-entiti.component.scss']
})
export class CreateReceiptEntitiComponent implements OnInit {
  title = 'Receipt';
  level: any = 1;
  amount: number;
  currency = 'AED';
  collapsetoheader: boolean;
  createReceiptEntitiForm: FormGroup;
  unmatchedForm: FormGroup;
  newMatchedRecordForm: FormGroup;
  BankName: any;
  results: any;
  errorMsg: string;
  isMatched = true;
  count;
  value;
  unmatchedRecords = [];
  matchedRecords = [];
  unmatchedDetails = [];
  matchedDetails = [];
  isUploadUnmatched;
  pjctindicator: any = [];
  department: any = [];
  placeholder: any;
  glaccount: any = [];
  totallingacc: any = [];
  transactiontype: any = [];
  private masterdata: any = [];
  private masterdata2: any = [];
  payeedataBankName: any = [];
  receiverdataBankName: any = [];
  branchdata = [];
  glerrorcount = 0;
  costcentredata = [];
  paymentname = 'CASH';
  errorpayee: boolean;
  errordetail: boolean;
  errorbankcode: boolean;
  errorchequedate: boolean;
  errorchequeno: boolean;
  errorinstrumentrefno: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  usersReq = true;
  payeeBankDefaultSelect;
  users: any = [];
  arrUser: any = [];
  terminals = [];
  bulkuploadData = [];
  slided;
  returnValue;
  isBatch = false;
  ifUploadSuccess = true;
  isMatchedOrUnmatched = true;
  RcptMode = 2;
  totalAmount = 0;
  dtltotallingacc = [];
  approverusers: string;
  displayApprover = false;
  symbol: string;
  minDateRd;
  maxDateRd;
  customerName: string;
  currentTbIndex = 0;
  selectedRow: Number;
  /* added for caching dropdown master data */
  cachedReceiverBankData: any;
  cachedTotAcc: any;
  cachedPayeeBankData: any;
  cachedBranchdata: any;
  cachedCostcentredata: any;
  cachedDtlTot: any;
  cachedGL: any;
  glnumber: any;
  idnumber: any;
  previewFlag = false;
  isMatchedOrUnmatchedDownload = false;
  totalMatchedUnmatched;
  prevReceipt: any;
  batchTotalAmt: any;
  brokerCustomerAmount = 0;
  @ViewChild('tabset') tabset: TabsetComponent;
  constructor(public bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private masterDataService: MasterDataService,
    private createservice: CreateService,
    private modalService: BsModalService,
    private batchUploadService: BatchUploadService,
    private alertService: AlertService,
    private sharedService: SharedService,
    private excelService: ExcelService,
    private router: Router) {
    this.minDateRd = new Date();
    this.maxDateRd = new Date();
    this.minDateRd.setDate(this.minDateRd.getDate() - 0);
    this.maxDateRd.setDate(this.maxDateRd.getDate() - 0);

  }


  ngOnInit() {
    this.getAllMasterData(1110);
    this.getAllMasterData2(true);
    this.createEntitiForm(this.RcptMode);
    this.getTotalAmount();
    this.getPayeeBankData(true);
    this.getTotallingData(true);
    this.getBankData(true);
    this.buildnewMatchedRecordForm();

    this.symbol = (localStorage.getItem('symbol'));
    setTimeout(() => {
      this.customerName = this.bsModalRef.content.CustomerName;
      this.setPayeName();
    }, 0);
    this.fieldStatusChanges();
    this.sharedService.getMessage().subscribe(val => {
      if (val == "previous")
        this.previewFlag = false;
      else if (val == "close") {
        this.modalService.hide(1);
      }
      this.prevReceipt = val.id;
    });

  }

  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    this.errorbankcode = false;
    this.errorchequedate = false;
    this.errorchequeno = false;
    this.errorinstrumentrefno = false;
    this.errorterminalID = false;
    this.errorexpirydate = false;
  }
  getTotallingDetailData(index, initFlag) {
    let loccode = this.getFromFormArrayControlVal('LocationCode', index);
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);

    const param = 'locationCode=' + loccode +
      '&paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingDetailData(param).subscribe(
      dataReturn => {
        this.dtltotallingacc[index] = dataReturn;
        let totcode = this.dtltotallingacc[index][0].TotAccCode;
        if (!initFlag)
          this.setFormArrayCTRLDefaultValue("TotallingAccCode", index, totcode);
        if (initFlag) {
          this.cachedDtlTot = dataReturn;
        }
        this.getGLData(index, initFlag, totcode);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getSum() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
    ctrl.controls.forEach(val => {
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value) ||
        val.get('Amount').value == '') ? 0 : val.get('Amount').value;
      this.totalAmount += parseFloat(amt);
    });
    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;
  }
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );
    if (this.payeebankcode != null && this.payeebankcode !== undefined) {
      this.payeebankcode.statusChanges.subscribe(
        status => {
          this.errorpayee = (status === 'INVALID');
        }
      );
    }
    if (this.chequedate != null && this.chequedate !== undefined) {
      this.chequedate.statusChanges.subscribe(
        status => {
          this.errorchequedate = (status === 'INVALID');
        }
      );
    }
    if (this.chequeno != null && this.chequeno !== undefined) {
      this.chequeno.statusChanges.subscribe(
        status => {
          this.errorchequeno = (status === 'INVALID');
        }
      );
    }
    // if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
    //   this.instrumentrefno.statusChanges.subscribe(
    //     status => {
    //       this.errorinstrumentrefno = (status === 'INVALID');
    //     }
    //   );
    // }
    if (this.terminalid != null && this.terminalid !== undefined) {
      this.terminalid.statusChanges.subscribe(
        status => {
          this.errorterminalID = (status === 'INVALID');
        }
      );
    }
    if (this.expirydate != null && this.expirydate !== undefined) {
      this.expirydate.statusChanges.subscribe(
        status => {
          this.errorexpirydate = (status === 'INVALID');
        }
      );
    }

  }

  setPayeName() {
    this.createReceiptEntitiForm.controls['PayeeName'].setValue(this.customerName);
  }

  goNext() {
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;

    if (this.payeebankcode != null && this.payeebankcode !== undefined) {
      this.errorbankcode = this.payeebankcode.invalid;
      console.log(this.payeebankcode.invalid, 'this.payeebankcode.invalid');
    }

    if (this.chequedate != null && this.chequedate !== undefined) {
      this.errorchequedate = this.chequedate.invalid;
    }

    if (this.chequeno != null && this.chequeno !== undefined) {
      this.errorchequeno = this.chequeno.invalid;
    }
    // if (this.instrumentrefno != null && this.instrumentrefno !== undefined) {
    //   this.errorinstrumentrefno = this.instrumentrefno.invalid;
    // }
    if (this.terminalid != null && this.terminalid !== undefined) {
      this.errorterminalID = this.terminalid.invalid;
    }

    if (this.expirydate != null && this.expirydate !== undefined) {
      this.errorexpirydate = this.expirydate.invalid;
    }

    if (!this.errorpayee && !this.errordetail && !this.errorchequedate && !this.errorchequeno
      && !this.errorterminalID && !this.errorexpirydate) {
      (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
      this.getTotallingDetailData(0, true);
      this.level = 2;
    }
  }

  // setting current Tab Index to activiate tab
  setcurrentTbIndex(tab) {
    switch (tab) {
      case 'Cash':
        this.currentTbIndex = 2;
        break;
      case 'Cheque':
        this.currentTbIndex = 0;
        break;
      case 'Credit Card':
        this.currentTbIndex = 1;
        break;
      case 'Bank Transfer':
        this.currentTbIndex = 3;
    }
  }
  // Displaying the  confirmation alert on tab click
  confirmTabSwitch(event) {
    console.log(event.target.tagName);
    const parentElement = event.target.parentElement;
    const target = event.target.parentElement.text;
    if (event.target.tagName === 'SPAN' && !parentElement.classList.contains('active') && parentElement.classList.contains('nav-link')) {
      if (this.createReceiptEntitiForm.dirty) {
        // --- showing popup only you have added or changed something
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        // Will move the content to RSAMSGConstants once approved // 
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.PAYMENTMODECHANGEMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
        this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
        this.bsModalRef.content.valueChange.subscribe((data) => {
          console.log(data);
          // changing the currentTbIndex if user proceed
          if (data = RSAMSGConstants.BTNPROCEED) {
            console.log(this.currentTbIndex);
            setTimeout(() => {
              this.setcurrentTbIndex(target);
            }, 0);
            setTimeout(() => {
              this.tabset.tabs[this.currentTbIndex].active = true;
            }, 1);
          }
        });
      } else {
        setTimeout(() => {
          this.setcurrentTbIndex(target);
        }, 0);
        setTimeout(() => {
          this.tabset.tabs[this.currentTbIndex].active = true;
        }, 1);

      }

    }
  }
  clearGLCode(indx, val) {

    this.setFormArrayCTRLDefaultValue('GLCode', indx, '');
    this.setFormArrayCTRLDefaultValue('GLCodeDesc', indx, '');

  }
  setReceiptMode(val, paymentname) {
    this.createReceiptEntitiForm.controls['ReceiptMode'].setValue(val);
    this.RcptMode = val;
    this.paymentname = paymentname;
    this.createEntitiForm(this.RcptMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.RcptMode == 1)
      this.createReceiptEntitiForm.controls['TotallingAccCode'].setValue('1210');
    else
      this.createReceiptEntitiForm.controls['TotallingAccCode'].setValue('1110');
    this.createReceiptEntitiForm.controls['RecevierBankCode'].setValue('14');
    this.setPayeName();
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
  }
  getPayeeBankData(initFlag) {
    let param = this.getFormCtrlValue('LocationCode');
    this.masterDataService.getPayeeBankData(param).subscribe(
      dataReturn => {
        this.payeedataBankName = dataReturn;
        this.createReceiptEntitiForm.controls['PayeeBankCode'].setValue(this.payeedataBankName[0].BankCode);
        if (initFlag)
          this.cachedPayeeBankData = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );

  }
  getBankData(flagInit) {
    let loccode = this.getFormCtrlValue('LocationCode');
    let ccentre = this.getFormCtrlValue('CostCenterCode');
    let totcode = this.getFormCtrlValue('TotallingAccCode');

    let param = 'locationCode=' + loccode +
      '&totallingAccCode=' + totcode +
      '&costCenter=' + ccentre;
    this.masterDataService.getBankData(param).subscribe(
      dataReturn => {
        this.receiverdataBankName = dataReturn;
        if (!flagInit)
          this.createReceiptEntitiForm.controls['RecevierBankCode'].setValue(this.receiverdataBankName[0].BankCode);
        if (flagInit)
          this.cachedReceiverBankData = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  setBankData(val) {
    this.createReceiptEntitiForm.controls['RecevierBankCode'].setValue('');
    this.getBankData(false);
  }
  setdefaultHeaderData() {
    if (this.RcptMode == 8)
      this.createReceiptEntitiForm.controls['TerminalID'].setValue(this.terminals[0].TerminalID);
    if (this.RcptMode == 2 || this.RcptMode == 5)
      this.createReceiptEntitiForm.controls['PayeeBankCode'].setValue(this.payeedataBankName[0].BankCode);
  }
  getTotallingData(initflag) {
    let loccode = this.getFormCtrlValue('LocationCode');
    let ccentre = this.getFormCtrlValue('CostCenterCode');
    const param = 'locationCode=' + loccode +
      '&paymentMode=' + this.paymentname +
      '&costCenter=' + ccentre;

    this.masterDataService.getTotallingData(param).subscribe(
      dataReturn => {
        this.totallingacc = dataReturn;
        if (initflag)
          this.cachedTotAcc = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  setFormArrayCTRLDefaultValue(contrlname, index, val) {
    (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[index].get(contrlname).setValue(val);
  }
  getFromFormArrayControlVal(contrlname, index) {
    return (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[index].get(contrlname).value;
  }
  getFormCtrlValue(contrlName) {
    console.log(this.createReceiptEntitiForm.controls, 'this.receiptForm.controls');
    return this.createReceiptEntitiForm.controls[contrlName].value;
  }
  getGLData(index, initFlag, val) {
    let loccode = this.getFromFormArrayControlVal('LocationCode', index);
    let ccentre = this.getFromFormArrayControlVal('CostCenterCode', index);
    let totcode = (initFlag) ? this.getFromFormArrayControlVal('TotallingAccCode', index) : val;

    let param = 'locationCode=' + loccode +
      '&totallingAccCode=' + totcode +
      '&CostCenterCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getGLData(param).subscribe(
      dataReturn => {
        this.glaccount[index] = dataReturn;
        if (!initFlag)
          this.setFormArrayCTRLDefaultValue("GLCode", index, this.glaccount[index][0].GLCode);
        this.setFormArrayCTRLDefaultValue("GLCodeDesc", index, this.glaccount[index][0].GLEngDescription);
        if (initFlag) this.cachedGL = dataReturn;
      },
      errorRturn => this.errorMsg = errorRturn
    );
    if (this.level == 2) {
      (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls.map(item => {
        // item.get('Amount').clearValidators();
        // item.get('GLCode').clearValidators();
        item.get('Amount').updateValueAndValidity();
        item.get('GLCode').updateValueAndValidity();
      });
    }
  }

  getTotalAmount() {
    this.totalAmount = 0;
    const ctrl = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
    ctrl.controls.forEach(val => {
      const amt = (val.get('Amount').value == null || isNaN(val.get('Amount').value ||
        val.get('Amount').value === '')) ? 0 : val.get('Amount').value;
      this.totalAmount += parseFloat(amt);
    });

    this.totalAmount = (isNaN(this.totalAmount)) ? 0 : this.totalAmount;
  }



  getAllMasterData(totalacc): void {

    this.masterDataService.getAllMasterData(totalacc).subscribe(
      dataReturn => {
        this.masterdata = dataReturn;
        console.log(dataReturn, ' : master data');
        //this.payeedataBankName = this.masterdata.LoadPayeeBanks;
        this.terminals = this.masterdata.Terminals;
        this.pjctindicator = this.masterdata.ProjectIndicators;
        this.department = this.masterdata.Departments;
        this.transactiontype = this.masterdata.TransactionType;

      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getAllMasterData2(initFlag): void {
    this.masterDataService.getAllMasterData2().subscribe(
      dataReturn => {
        this.masterdata2 = dataReturn;
        console.log(dataReturn, ' : master data');
        //this.glaccount = this.masterdata2.GLCodes;
        this.users = this.masterdata2.Users;
        // console.log(this.users, 'USERS');
        this.branchdata = this.masterdata2.Locations;
        this.costcentredata = this.masterdata2.CostCenter;
        if (initFlag) {
          this.cachedBranchdata = this.masterdata2.Locations;
          this.cachedCostcentredata = this.masterdata2.CostCenter;
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  onUserChange(userid: string, isChecked: boolean, username: string) {
    const userFormArray = <FormArray>this.createReceiptEntitiForm.controls.Approvers;
    if (isChecked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value == userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
    }
    this.approverusers = this.arrUser.join();
  }

  createEntitiForm(param): void {
    this.createReceiptEntitiForm = null;
    this.createReceiptEntitiForm = this.fb.group({
      ReceiptDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      Amount: [''],
      ReceiptMode: [this.RcptMode],
      PrintDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')],
      ReceiptType: [0],
      PreparedBy: [1],
      ModifiedBy: ['1'],
      Approvers: this.fb.array([]),
      CustomerID: [],
      TerminalID: [],
      TerminalUserID: [20],
      TerminalUserName: [],
      CountryCode: [1],
      LocationCode: [localStorage.getItem('locationcode')],
      RegionCode: [localStorage.getItem('regioncode')],
      ReprintNo: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ArabicDescription: [],
      TotallingAccCode: [1110],
      RecevierBankCode: [14],
      PayeeBankCode: ['', Validators.required],
      PayeeName: [this.customerName, Validators.required],
      EnglishDescription: ['', Validators.required],
      ChequeDate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
      ReceiptDetails: this.fb.array([this.createNewcreateReceiptEntitiFormGroup()])
    });
    switch (param) {
      case 1:
        this.createReceiptEntitiForm.addControl('Amount', new FormControl(''));
        break;
      case 2:
        this.createReceiptEntitiForm.addControl('ChequeNo', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['ChequeNo'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['ChequeDate'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['PayeeBankName'].updateValueAndValidity();
        break;
      case 8:
        this.createReceiptEntitiForm.addControl('ChequeNo', new FormControl('', [Validators.required, Customvalidators.creditcardValidator]));
        this.createReceiptEntitiForm.controls['ChequeNo'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('InstrumentRefNo', new FormControl(''));
        //this.createReceiptEntitiForm.controls['InstrumentRefNo'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['ChequeDate'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('TerminalID', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['TerminalID'].updateValueAndValidity();
        break;
      case 5:
        this.createReceiptEntitiForm.addControl('PayeeBankCode', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['PayeeBankCode'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('PayeeBankName', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['PayeeBankName'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('ChequeDate', new FormControl('', Validators.required));
        this.createReceiptEntitiForm.controls['ChequeDate'].updateValueAndValidity();
        this.createReceiptEntitiForm.addControl('InstrumentRefNo', new FormControl(''));
        //this.createReceiptEntitiForm.controls['InstrumentRefNo'].updateValueAndValidity();

        break;
    }
  }
  createNewcreateReceiptEntitiFormGroup(): FormGroup {
    return this.fb.group({
      CounterPartyRef: [],
      LocationCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      CountryCode: [1],
      CostCenterCode: [localStorage.getItem('costcentre')],
      Description: [],
      Amount: ['', Validators.required],
      RefTransactionID: [],
      RefTransactionType: [3],
      // RefTranTypeDesc: ['Receipt'],
      IsCreditEntry: [false],
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: ['1'],
      ReceiptDate: [],
      // ProjectIndicator: [],
      AnalysisCode: [],
      DepartmentCode: [],
      Department: [],
      RefTransactionSerialNo: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      //GLCodeDesc: [],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      // TotallingAccCodeDesc: ['1110 BANK CURRENT A/C'],
      ClassCode: ['1'],
      PolicyYear: [],
      PolicyType: []
    });
  }

  setHiddenValue(ev, iter, key, setKey) {
    (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.item[setKey]);
  }
  setCreditEntry(ev, iter, key, data) {
    console.log(iter, 'key');
    const actualData = Number(data.controls['Amount'].value);
    const curdata = -(data.controls['Amount'].value);
    data.controls['Amount'].patchValue(curdata);
    this.getSum();
    if (actualData === 0 || actualData === undefined) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.EMPTYAMOUNTCHECK;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      ev.target.checked = true;

    }
    (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[iter].get(key).setValue(ev.target.checked);
    if (this.totalAmount < 0) {
      ev.target.checked = true;
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CREDITEXCEEDMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      data.controls['Amount'].patchValue(-curdata);
      this.getSum();
    }

  }

  setTerminalCode(ev, key, setKey) {
    console.log(ev, 'ev');
    this.createReceiptEntitiForm.controls[key].setValue(ev.item[setKey]);
  }
  setBankCode(ev, iter, key) {
    this.createReceiptEntitiForm.controls[key].setValue(ev.item.BankCode);
  }
  get cshpayeename() { return this.createReceiptEntitiForm.get('PayeeName'); }
  get cshdetails() { return this.createReceiptEntitiForm.get('EnglishDescription'); }
  get payeebankcode() { return this.createReceiptEntitiForm.get('PayeeBankCode'); }
  get chequedate() { return this.createReceiptEntitiForm.get('ChequeDate'); }
  get instrumentrefno() { return this.createReceiptEntitiForm.get('InstrumentRefNo'); }
  get terminalid() { return this.createReceiptEntitiForm.get('TerminalID'); }
  get expirydate() { return this.createReceiptEntitiForm.get('ExpiryDate'); }
  get chequeno() { return this.createReceiptEntitiForm.get('ChequeNo'); }

  // addReceipt(len): void {
  //   const control = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
  //   control.push(this.createNewcreateReceiptEntitiFormGroup());
  //   this.getTotallingDetailData(11, len);
  //   this.getGLData(1110, len);
  // }

  addReceipt(len) {
    const control = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
    const CurrentAmount = (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls[len - 1].get('Amount').value;
    if (CurrentAmount > 0) {
      control.push(this.createNewcreateReceiptEntitiFormGroup());
      this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
      this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
      this.dtltotallingacc[len] = this.cachedDtlTot;
      this.glaccount[len] = this.cachedGL;
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
      return false;
    }
  }

  reSetForm(param) {
    /*set default value here and reset */
    if (param == 1) {
      const arrayFields = ['PayeeName', 'EnglishDescription', 'ChequeNo', 'ChequeDate', 'PayeeBankCode',
        'PayeeBankName', 'ExpiryDate', 'InstrumentRefNo', 'TerminalID'];
      this.createReceiptEntitiForm.controls['LocationCode'].reset([localStorage.getItem('locationcode')]);
      this.createReceiptEntitiForm.controls['CostCenterCode'].reset([localStorage.getItem('costcentre')]);
      this.createReceiptEntitiForm.controls['TotallingAccCode'].reset([1110]);
      this.createReceiptEntitiForm.controls['RecevierBankCode'].reset([14]);
      this.createReceiptEntitiForm.controls['PayeeName'].reset();
      this.createReceiptEntitiForm.controls['EnglishDescription'].reset();

      arrayFields.forEach((val) => {
        if (this.createReceiptEntitiForm.controls[val] != null && this.createReceiptEntitiForm.controls[val] != undefined) {
          this.createReceiptEntitiForm.controls[val].reset();
        }
      });
      this.clearerrors();
    } else if (param == 2) {
      this.createReceiptEntitiForm.controls['ReceiptDetails'].reset();
      (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls.map(item => {
        item.get('LocationCode').setValue([localStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([localStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });
      this.getSum();
    }
  }

  deleteReceipt(index: number, itemrow) {
    console.log(itemrow, 'itemrow');
    if (index >= 1) {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DELETEMSGRECEIPTL;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = RSAMSGConstants.BTNPROCEED) {
          const control = <FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails'];
          control.removeAt(index);
        }
      });
    } else {
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.CANTDELETEFIRSTROW;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
    }
  }

  get receiptRows() { return <FormArray>this.createReceiptEntitiForm.get('ReceiptDetails'); }

  checkIsformDirty() {
    if (this.createReceiptEntitiForm.dirty || this.createReceiptEntitiForm.touched) {
      console.log('cmg here');
      this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
      this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
      this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
      this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = 'Proceed') {
          this.modalService.hide(1);
        }
      });

    } else {
      this.modalService.hide(1);
    }
  }

  validateDetailInfo() {
    (<FormArray>this.createReceiptEntitiForm.controls['ReceiptDetails']).controls.map(item => {
      item.get('Amount').updateValueAndValidity();
      item.get('Amount').markAsTouched();
      item.get('GLCode').updateValueAndValidity();
      item.get('GLCode').markAsTouched();
      this.glerrorcount = 0;
      if (item.get('GLCode').value == null || item.get('GLCode').value == undefined || item.get('GLCode').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
      if (item.get('Amount').value == null || item.get('Amount').value == 0 || item.get('Amount').value == undefined || item.get('Amount').value == "") {
        this.glerrorcount = this.glerrorcount + 1;
      }
    });
  }

  submitForm(bsModalRef, receiptno) {
    if (this.isBatch && this.isMatchedOrUnmatched) {
      console.log(this.totalAmount);
      console.log(this.totalMatchedUnmatched);
      if (Number(this.totalMatchedUnmatched) > Number(this.totalAmount)) {
        this.alertService.warn('Transactions Amount exceeds the Receipt Amount !!');
        return false;
      } else {
        const formval = this.createReceiptEntitiForm.value;
        formval['ReceiptDetails'] = this.matchedDetails;
        console.log(formval['ReceiptDetails']);
        this.createservice.createReceipt(JSON.stringify(formval)).subscribe(
          dataReturn => {
            this.returnValue = dataReturn;
            console.log(this.returnValue, 'value');
            this.returnValue['approverlist'] = this.approverusers;
            this.returnValue['ondemand'] = true;
            // this.bsModalRef.hide();
            this.previewFlag = true;
            this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog' });
            this.bsModalRef.content.data = this.returnValue;
            this.bsModalRef.content.totalAmount = this.totalAmount;
            this.bsModalRef.content.brokerCustomerAmount = this.brokerCustomerAmount;
            this.bsModalRef.content.backdrop = true;
          },
          errorRturn => {
            this.errorMsg = errorRturn;
          }
        );
      }

    } else {
      // const chequeDate = this.createReceiptEntitiForm.get('ChequeDate').value;
      // this.createReceiptEntitiForm.controls['ChequeDate']
      //   .setValue(getShortDate(new Date(chequeDate)));
      this.validateDetailInfo();
      if (this.glerrorcount > 0) {
        return false;
      }
      this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
        this.approverusers.length > 0);
      const formval = this.createReceiptEntitiForm.value;
      console.log(formval['ReceiptDetails']);
      console.log(formval, 'value');
      if (this.totalAmount > 0) {
        if (this.totalAmount > 99999 && !this.usersReq) {
          return false;
        }
        this.createservice.createReceipt(JSON.stringify(formval)).subscribe(
          dataReturn => {
            this.returnValue = dataReturn;
            console.log(this.returnValue, 'value');
            this.returnValue['approverlist'] = this.approverusers;
            this.returnValue['ondemand'] = true;
            //this.bsModalRef.hide();
            this.previewFlag = true;
            this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog' });
            this.bsModalRef.content.data = this.returnValue;
            this.bsModalRef.content.totalAmount = this.totalAmount;
            this.bsModalRef.content.backdrop = true;
          },
          errorRturn => {
            this.errorMsg = errorRturn;
          }
        );
      }
      if (this.totalAmount <= 0) {
        this.alertService.warn(RSAMSGConstants.AMOUNTTEXTREQ);
      }
    }
  }
  goPrevious() {
    this.level = 1;
  }

  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
    if (this.collapsetoheader) {
      this.sharedService.sendMessage('collapse');
    } else {
      this.sharedService.sendMessage('not-collapse');
    }
  }


  checkSingleOrbatch(e) {
    this.isBatch = !this.isBatch;
    console.log(this.isBatch);
  }

  buildnewMatchedRecordForm() {
    this.newMatchedRecordForm = this.fb.group({
      Amount: ['', Validators.required],
      VoucherNo: ['', Validators.required],
      VoucherDate: [],
      PolicyID: [],
      GLCode: '1115',
      Commision: ['', Validators.required],
      PolicyNumber: ['', Validators.required],
      PolicyYear: [],
      DepartmentCode: [],
      DepartmentName: [],
      Description: ['', Validators.required],
      LocationCode: [],
      ClassCode: ['', Validators.required],
      CityCode: [],
      PolicyType: [],
      CountryCode: [1],
      RegionCode: localStorage.getItem('regioncode'),
      CostCenterCode: localStorage.getItem('costcentre'),
      TotallingAccCode: '1410',
      RefTransactionID: [],
      RefTransactionType: ['', Validators.required],
      SerialNo: ['0', Validators.required],
      ModifiedBy: [],
    });
  }
  calculateNetAmount() {
    const Amt = (this.newMatchedRecordForm.get('Amount').value == null) || (isNaN(this.newMatchedRecordForm.get('Amount').value)) ||
      (this.newMatchedRecordForm.get('Amount').value == '') ? 0 : this.newMatchedRecordForm.get('Amount').value;
    const Comm = (this.newMatchedRecordForm.get('Commision').value == null) || (isNaN(this.newMatchedRecordForm.get('Commision').value)) ||
      (this.newMatchedRecordForm.get('Commision').value == '') ? 0 : this.newMatchedRecordForm.get('Commision').value;
    return Number(Amt) + Number(Comm);

  }
  buildUnmachedForm() {
    this.unmatchedForm = this.fb.group({
      unmatchedList: this.fb.array([
        this.fb.group({
          Amount: [],
          VoucherNo: [],
          VoucherDate: [],
          PolicyID: [],
          GLCode: [],
          Commision: [],
          NetAmount: [this.calculateNetAmount()] || 0,
          PolicyNumber: [],
          PolicyYear: [],
          DepartmentCode: [],
          DepartmentName: [],
          Description: [],
          LocationCode: [],
          ClassCode: [],
          CityCode: [],
          PolicyType: [],
          CountryCode: [],
          RegionCode: [],
          CostCenterCode: [],
          TotallingAccCode: [],
          RefTransactionID: [],
          RefTransactionType: [],
          RefTransactionSerialNo: [],
          ModifiedBy: [],
          SerialNo: []
        }),

      ])
    });
  }

  uploadXlsFile(e) {
    // console.log(this.unmatchedForm.value);
    if (e.target.files && e.target.files.length) {
      const selectedFiles = e.target.files;
      console.log(selectedFiles.item(0), 'selectedFiles.item(0)');
      this.batchUploadService.uploadBatchFile(selectedFiles.item(0),
        { 'gl': this.glnumber, 'acc': this.idnumber }).subscribe((data) => {
          console.log(data);
          this.ifUploadSuccess = false;
          this.buildUnmachedForm();
          this.bulkuploadData = data;
          this.unmatchedRecords = data.filter(item => item.Matched === false) || [];
          this.matchedRecords = data.filter(item => item.Matched !== false) || [];
          console.log(this.unmatchedRecords);
          this.setMatchedUnmatched(this.matchedRecords);
        });
    } else {
      console.log('Error while file selection');
    }
  }

  setMatchedUnmatched(data: any[]) {
    if (Array.isArray(data) && data.length) {
      if (this.isMatchedOrUnmatched) {
        this.matchedDetails = [];
      } else if (!this.isMatchedOrUnmatched) {
        this.unmatchedDetails = [];
      }
      let receiptDetails = {};
      for (const item of data) {
        receiptDetails = {
          Amount: item.GrossAmount || item.Amount,
          VoucherNo: item.VoucherNo,
          VoucherDate: new DatePipe('en-US').transform(item.VoucherDate, 'dd/MM/yyyy'),
          PolicyID: '',
          GLCode: '1115',
          NetAmount: item.NetAmount ? item.NetAmount : Number(item['GrossAmount'] || item['Amount']) + Number(item['Commision']),
          Commision: item.Commision,
          PolicyNumber: item.PolicyNumber,
          PolicyYear: '',
          DepartmentCode: '',
          DepartmentName: '',
          Description: item.Description,
          LocationCode: item.RegionCode,
          ClassCode: item.ClassCode,
          CityCode: item.CityCode,
          PolicyType: '',
          CountryCode: item.Branch,
          RegionCode: localStorage.getItem('regioncode'),
          CostCenterCode: localStorage.getItem('costcentre'),
          TotallingAccCode: '1410',
          RefTransactionID: '',
          RefTransactionType: item.TransactionType || item.RefTransactionType,
          RefTransactionSerialNo: item.SerialNo,
          ModifiedBy: item.ModifyBy,
        };
        this.totalMatchedUnmatched = 0;
        if (this.isMatchedOrUnmatched) {
          this.matchedDetails.push(receiptDetails);
          this.totalMatchedUnmatched = this.getMatchedUnmatchedAmtsum(this.matchedDetails);

        } else if (!this.isMatchedOrUnmatched) {
          this.unmatchedDetails.push(receiptDetails);
          this.totalMatchedUnmatched = this.getMatchedUnmatchedAmtsum(this.unmatchedDetails);

        }
        // this.bulkuploadData.push(receiptDetails);
      }
    }
  }

  exportAsXlsx(): void {
    const unmatchdata = this.unmatchedForm.controls.unmatchedList.value.map((item) => {
      return {
        TransactionType: item.RefTransactionType,
        VoucherNo: item.VoucherNo,
        VoucherDate: item.VoucherDate,
        SNo: item.RefTransactionSerialNo,
        PolicyNo: item.PolicyNumber,
        Description: item.Description,
        Gross: item.Amount,
        Comm: item.Commision,
        CityCode: item.CityCode,
        RegionCode: item.RegionCode,
        Branch: item.CountryCode,
        classcode: item.ClassCode,
      };

    });
    if (unmatchdata.length) {
      this.excelService.exportAsExcelFile(unmatchdata, 'Unmatched');
      this.isUploadUnmatched = true;
    } else {
      this.alertService.warn('No record found');
    }
  }

  checkMatchedOrUnmatched(e) {
    this.isMatchedOrUnmatched = !this.isMatchedOrUnmatched;
    if (this.isMatchedOrUnmatched) {
      this.setMatchedUnmatched(this.matchedRecords);
      // this.isMatchedOrUnmatchedDownload = false;
    } else {
      this.setMatchedUnmatched(this.unmatchedRecords || []);
      console.log(this.unmatchedRecords);
      console.log(this.unmatchedDetails);
      const list = this.unmatchedDetails.map((item) => {
        return this.fb.group({
          Amount: [item.Amount],
          VoucherNo: [item.VoucherNo],
          VoucherDate: [item.VoucherDate],
          PolicyID: [item.PolicyID],
          GLCode: [item.GLCode],
          Commision: [item.Commision],
          NetAmount: [item.NetAmount],
          PolicyNumber: [item.PolicyNumber],
          PolicyYear: [item.PolicyYear],
          DepartmentCode: [item.DepartmentCode],
          DepartmentName: [item.DepartmentName],
          Description: [item.Description],
          LocationCode: [item.LocationCode],
          ClassCode: [item.ClassCode],
          CityCode: [item.CityCode],
          PolicyType: [item.PolicyType],
          CountryCode: [item.CountryCode],
          RegionCode: [item.RegionCode],
          CostCenterCode: [item.CostCenterCode],
          TotallingAccCode: [item.TotallingAccCode],
          RefTransactionID: [item.RefTransactionID],
          RefTransactionType: [item.RefTransactionType],
          RefTransactionSerialNo: [item.RefTransactionSerialNo],
          ModifiedBy: [item.ModifiedBy],
          SerialNo: [item.RefTransactionSerialNo]

        });
      });
      const arrayList = this.fb.array(list);
      this.unmatchedForm.setControl('unmatchedList', arrayList);

    }
    // this.isMatched = !this.isMatched;
  }

  setClickedRow(e, index) {
    this.selectedRow = index;
  }
  deleteMatchedRecord(index, row) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = 'Do you want to remove this record';
    this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
    this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'Proceed') {
        this.matchedRecords.splice(index, 1);
        this.setMatchedUnmatched(this.matchedRecords);
      }
    });

  }
  updateRecord(i, t) {
    this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
    this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
    this.bsModalRef.content.modelBodyContent = 'Do you want make more correction with this record.';
    this.bsModalRef.content.cancelBtn = 'Yes';
    this.bsModalRef.content.actionBtn = 'No';
    this.bsModalRef.content.valueChange.subscribe((data) => {
      if (data = 'No') {
        let selecteddata;
        this.unmatchedForm.controls.unmatchedList.value.map((row) => {
          if (t.PolicyNumber === row.PolicyNumber) {
            selecteddata = row;
            console.log(row);
            this.matchedRecords.push(row);
            this.setMatchedUnmatched(this.matchedRecords);
          }

        });
        // control refers to your formarray
        const control = <FormArray>this.unmatchedForm.controls['unmatchedList'];
        // remove the chosen row
        control.removeAt(i);
        if (selecteddata) {
          this.unmatchedRecords = this.unmatchedRecords.filter((item) => {
            return item.PolicyNumber !== selecteddata.PolicyNumber;
          });
          this.setMatchedUnmatched(this.unmatchedRecords);
        }
      }
    });

  }

  getMatchedUnmatchedAmtsum(data: any[]) {
    if (toString.call(data) !== '[object Array]') {
      return false;
    }
    let total = 0;
    for (let i = 0; i < data.length; i++) {
      if (isNaN(data[i].Amount)) {
        continue;
      }
      total += Number(data[i].Amount);
    }
    return total.toFixed(2);
  }
  getbatchTotalAmt(val) {
    console.log(val);
    if (this.isBatch) {
      this.totalAmount = val;
    }

  }
  calculateBrokerCustomerAmount() {
    this.brokerCustomerAmount += Number(this.newMatchedRecordForm.get('Amount'));

  }
  addRowModal(template: TemplateRef<any>) {
    this.bsModalRef = this.modalService.show(
      template,
      Object.assign({}, { class: 'gray modal-lg' })
    );
  }
  AddNewMatchedRecord() {
    if (this.newMatchedRecordForm.valid) {
      this.matchedRecords.push(this.newMatchedRecordForm.value);
      this.setMatchedUnmatched(this.matchedRecords);
      this.calculateBrokerCustomerAmount();
      this.bsModalRef.hide();
    }

  }
}
