import { Router, NavigationExtras } from '@angular/router';
import { Component, OnInit, Input, AfterViewInit, ViewChild } from '@angular/core';
import { NgXDonutChartSlice } from 'ngx-donutchart/ngx-donutchart.type';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { SearchService } from 'src/app/finance/search/service/search.service';
import { CreditDebit } from 'src/app/finance/search/model/credit-debit';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

import { CreateReceiptEntitiComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti/create-receipt-entiti.component';
import { CreateReceiptEntitiRowSelectionComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti-row-selection/create-receipt-entiti-row-selection.component';
import { MatchUnMatchService } from 'src/app/finance/search/service/match-unmatch.service';
import { CreatePaymentEntityComponent } from './create-payment-entity/create-payment-entity.component';
import { CreatePaymentNewComponent } from 'src/app/finance/search/search-results/entity/create-payment-new/create-payment-new.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
@Component({
  selector: 'rsa-entity',
  templateUrl: './entity.component.html',
  styleUrls: ['./entity.component.scss']
})
export class EntityComponent extends BaseSearchComponent implements OnInit {
  @Input('resultdata') resultdata: any = [];
  @Input('entityNo') entityNo: any;
  @Input('category') category: any;
  @Input('filtercolumndata') filtercolumndata: any;
  @Input('propertyNames') propertyNames: any;
  @Input('userdata') userdata: any;
  @Input('searchedname') searchedname: string;
  rowopen = true;
  size = 90;
  innerRadius = 30;
  slices: NgXDonutChartSlice[] | any[];
  creditlimit: number;
  donutdropdata: any;
  idnumber: number;
  glnumber = [];
  name: string;
  creditData: CreditDebit[] = [];
  creditLimitDetails: CreditDebit[] = [];
  selectedValue = 'All';
  debitlimit: number;
  total: number;
  showSnackbar = false;
  totalVoucherAmount: any = 0;
  totalVoucherCount = 0;
  gridOptions: GridOptions;
  isRecepit;
  selectedRowEntitiDataTable;
  bsModalRef: BsModalRef;
  isMatched;
  showCreateReceiptForm;

  constructor(private searchService: SearchService, private router: Router,
    private gridApiService: GridApiService, private modalService: BsModalService,
    private matchUnMatchService: MatchUnMatchService, private alertService: AlertService) {
    super();
  }

  ngOnInit() {
    this.getCreditData();
    this.idnumber = 201838683;
    this.name = this.searchedname;
    console.log(this.name, 'name');
    const unique = (value, index, self) => {
      return self.indexOf(value) === index;
    };
    this.glnumber = this.resultdata[0].map(i => i.GlCode).filter(unique);
    this.donutdropdata = [
      { item: 'All' },
      { item: 'pl' },
      { item: 'cl' },
      { item: 'sme/spl' }
    ];

    console.log(this.totalVoucherAmount, 'totlaampount');
  }

  fillSlicerData(debit, total) {
    this.slices = [
      {
        value: debit,
        color: '#00b5d5',
        message: ''
      },
      {
        value: total,
        color: '#ef5ba1',
        message: 'Payment Due(>90 Days)'
      },

    ];
  }


  getCreditData(): void {
    this.searchService.getCreditData().subscribe((data) => {
      this.creditData = data;
      if (this.selectedValue === 'All') {
        this.creditLimitDetails = this.creditData.filter(i => i.name === this.selectedValue);
        console.log(this.creditLimitDetails);
        this.debitlimit = this.creditLimitDetails[0].debitlimit;
        this.total = this.creditLimitDetails[0].total;
        this.fillSlicerData(this.debitlimit, this.total);
      }
    });
  }

  getDountDropdownData(e) {
    console.log(e);
    this.selectedValue = e.item.item;
    this.creditLimitDetails = this.creditData.filter(i => i.name === e.item.item);
    this.debitlimit = this.creditLimitDetails[0].debitlimit;
    this.total = this.creditLimitDetails[0].total;
    this.fillSlicerData(this.debitlimit, this.total);
  }

  createNewRecepit() {
    this.totalVoucherAmount = null;
    this.totalVoucherCount = null;
    this.createButton([
      { id: '1', name: 'receipt' },
      { id: '4', name: 'payment' },
    ]);
    this.unSelectCheckbox();
    setTimeout(() => {
      this.showSnackbar = true;
    }, 200);

  }

  buttonHandler(e) {
    const config = {
      backdrop: true,
      ignoreBackdropClick: false,
      class: 'create-modal-dailog'
    };


    if (e === '1') {
      this.showSnackbar = false;
      const initialState = {
        'glnumber': this.glnumber,
        'idnumber': this.idnumber
      };
      this.bsModalRef = this.modalService.show(CreateReceiptEntitiComponent, { class: 'create-modal-dailog', initialState });
      this.bsModalRef.content.CustomerName = this.name;
    }
    if (e == '4') {
      this.showSnackbar = false;
      this.bsModalRef = this.modalService.show(CreatePaymentNewComponent, { class: 'create-modal-dailog' });
      this.bsModalRef.content.CustomerName = this.name;
    }
    if (e == '3' && this.totalVoucherAmount < 0) {
      this.showSnackbar = false;
      this.bsModalRef = this.modalService.show(CreatePaymentEntityComponent, config);
      this.bsModalRef.content.totalamount = this.totalVoucherAmount;
      this.bsModalRef.content.totalcount = this.totalVoucherCount;
      this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable;
    }
    if (this.totalVoucherAmount > 0 && e === '3') {
      this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
    }
    if (this.totalVoucherAmount > 0 && e === '2') {
      this.showSnackbar = false;
      this.bsModalRef = this.modalService.show(CreateReceiptEntitiRowSelectionComponent, config);
      this.bsModalRef.content.totalamount = this.totalVoucherAmount;
      this.bsModalRef.content.totalcount = this.totalVoucherCount;
      this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable;
    }
    if (this.totalVoucherAmount < 0 && e === '2') {
      this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
    }
  }

  setErorrMsgForTotalAmount() {
    this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
  }
  selectedRowDetails(event) {
    const e = event.vocherEmitedDetails;
    console.log(e.amount);
    if (e.count) {
      this.createButton([
        { id: '2', name: 'receipt' },
        { id: '3', name: 'payment' },
        { id: '22', name: 'Journal' },
        { id: '22', name: 'Debit note' },
        { id: '22', name: 'credit note' }
      ]);
      // if (e.transactionType === 'DEBIT') {
      //   this.createButton([
      //     { id: '2', name: 'receipt' },
      //     { id: '22', name: 'Journal' }
      //   ]);
      // } else if (e.transactionType === 'CREDIT') {
      //   this.createButton([
      //     { id: '3', name: 'payment' },
      //     { id: '32', name: 'Journal' }
      //   ]);
      // }
      this.showSnackbar = true;
    } else {
      // alert('amount should ne gretaherthan zero');
      this.showSnackbar = false;
    }
    this.totalVoucherAmount = e.amount;
    this.totalVoucherCount = e.count;
    this.selectedRowEntitiDataTable = e.selectedrow;
    console.log(this.totalVoucherAmount, 'totalVoucherAmount');
  }

  hideSnackBar(e) {
    this.unSelectCheckbox();
    this.showSnackbar = false;
  }

  hideSnackBarDataT(ev) {
    if (ev === 1) {
      console.log(ev);
      this.showSnackbar = false;
    }
  }

  unSelectCheckbox() {
    this.gridApiService.unCheck();
  }
}

