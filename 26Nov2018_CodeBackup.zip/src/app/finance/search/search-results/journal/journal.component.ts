import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from '../../service/search.service';
import { RSAENDPOINTConstants } from '../../../../core/constants/rsa.api.end.points';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component'
@Component({
  selector: 'rsa-journal',
  templateUrl: './journal.component.html',
  styleUrls: ['./journal.component.scss']
})
export class JournalComponent extends BaseSearchComponent implements OnInit {

  errormsg: string;
  cathecoulmnHeaderConfigData: any;
  coulmnHeaderConfigData: any;
  isopen: boolean;
  @Input('resultdata') resultdata: any = [];
  @Input('journalNo') journalNo: any;
  @Input('category') category: any;
  @Input() settingsdata: any;
  @Input() headerdata: any;

  glnumber: string;
  idnumber = '';
  name = ' ';
  pageSize = 15;
  currentpage: any = 1;


  constructor(private searchService: SearchService) {
    super()
  }

  ngOnInit() {
    super.ngOnInit();
  }

  pageChanged(ev) {
    this.currentpage = ev;
  }
  updateTableHeader(data) {
    this.headerdata = data;
  }
}
