
export class CreatePayment {
    VoucherDate: string;
    VoucherNo: string;
    RePrintNo: string;
    A_Desc: string;
    E_Desc: string;
    PaymentMode: string;
    PaymentModeDesc: string;
    ChequeNo?: any;
    ChequeDate?: string;
    ChequeType: string;
    ChequeTypeDesc: string;
    PaymentType: string;
    PaymentTypeDesc?: string;
    BankCode: string;
    BankCodeDesc: string;
    PreparedBy: string;
    ApprovedBy: string;
    PrintDate: string;
    ReceiptType: number;
    CustCode: string;
    Approvers: any[];
    CustomerID?: any;
    TerminalUserID: number;
    TerminalUserName?: any;
    CountryCode: number;
    CountryCodeDesc: string;
    RegionCodeDesc: string;
    LocationCode: string;
    LocationCodeDesc: string;
    ExchangeRate: string;
    RegionCode: string;
    TerminalID: any;
    ReprintNo?: any;
    PreparedDate?: string;
    ModifiedBy?: string;
    InstrumentRefNo?: any;
    CostCenterCode: string;
    CostCenterDesc: string;
    ArabicDescription?: any;
    TotallingAccCode: string;
    TotallingAccCodeDesc: string;
    ModifiedDate: string;
    Name: string;
    PostedDate: string;
    RefreshDate: string;
    vendorCode: string;
    ReleaseDate: string;
    RecevierBankCode: string;
    PayeeBankCode: string;
    PayeeBankName: string;
    PayeeName: string;
    TotalAmount: string;
    TotalAmountInWords: string;
    EnglishDescription: string;
    PmtDetails: PaymentDetail[];
    Amount: string;
}



export class PaymentDetail {
    VoucherNo: string;
    VoucherDate: string;
    ReferenceID1: string;
    ReferenceID2: string;
    CounterPartyRef?: any;
    LocationCode: string;
    LocationDesc: string;
    CountryCode: number;
    CostCenterCode: string;
    Description: string;
    Amount: string;
    RefTransactionID?: any;
    RefTransactionType: number;
    IsCreditEntry: boolean;
    PolicyID?: any;
    PolicyNumber?: any;
    ModifiedBy: string;
    ReceiptDate?: any;
    AnalysisCode: string;
    DepartmentCode?: any;
    OfficeCode?: string;
    Department?: any;
    RefTransactionSerialNo?: any;
    GLCode: number;
    SLCode: number;
    GLCodeDesc: string;
    RegionCode: string;
    TotallingAccCode: number;
    ClassCode: string;
    PolicyYear?: any;
    PolicyType?: any;
    RefPolicyNo?: string;
    RefPolicyYear: string;
    ClassCodeDes?: any;
    DocumentCode?: any;
    EndtID?: string;
    CostCentreDesc?: string;
    PreparedBy?: any;
    PreparedDate?: string;
    ModifiedDate?: string;
    Lob?: any;
    Channel?: string;
    IsDebitEntry?: string;
}



