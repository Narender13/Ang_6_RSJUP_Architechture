
export class CreditDebit {
    id: number;
    name: string;
    creditLimit: number;
    debitlimit: number;
    total: number;
}

