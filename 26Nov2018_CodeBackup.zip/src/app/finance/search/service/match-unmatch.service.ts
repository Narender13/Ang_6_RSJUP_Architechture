import { Injectable } from '@angular/core';
import { Subject, Observable, BehaviorSubject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class MatchUnMatchService {

    private readonly isMatchUnMatchServiceSrc = new Subject<any>();

    getMatchUnMatchObserable(): Observable<any> {
        return this.isMatchUnMatchServiceSrc.asObservable();
    }
    getMatchUnMatch(id) {
        this.isMatchUnMatchServiceSrc.next({ id: id });
    }
}
