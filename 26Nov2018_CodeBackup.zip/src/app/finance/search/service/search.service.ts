import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap, shareReplay, switchMap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { CreditDebit } from 'src/app/finance/search/model/credit-debit';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';

@Injectable()
export class SearchService {

    constructor(private http: HttpClient) { }

    getSearchResults(param): Observable<any> {
        console.log(param, 'params');
        const httpHeaders = new HttpHeaders();
        httpHeaders.append('Accept', 'application/json');
        httpHeaders.append('Access-Control-Allow-Origin', '*');
        let params = new HttpParams();
        if (param.categoryType == 4) {
            params = params.append('id', param.id);
            params = params.append('entityType', param.entityType);
            params = params.append('entityUnMatched', param.entityUnMatched);
        } else {
            params = params.append('category', param.category);
            params = params.append('inputData', param.inputData);
            params = params.append('categoryitem', param.categoryitem);
        }
        // ENTITYSEARCHRESULTS

        const urlstr = `${RSAENDPOINTConstants.SERVERAPI_SEARCHRESULT}`;

        const fakeUrl = `src/assets/json/${param.category}.json`;
        const under_writer_policy_url = `${RSAENDPOINTConstants.SERVER_API_UNDERWRITING_POLICY}`;
        const endorsement_url = `${RSAENDPOINTConstants.SERVER_API_ENDORSEMENT}`;
        const under_writer_quotation_url = `${RSAENDPOINTConstants.SERVER_API_UNDERWRITING_QUOTATION}`;
        const entity_url = `${RSAENDPOINTConstants.SEARCH_API_ADMIN_ENTITY}`;

        const category = param.category;
        let url = '';
        if (category == 1) {
            url = under_writer_policy_url;
            params = params.append('policyNo', param.inputData);
            params = params.append('classCode', param.classCode);
        } else if (category == 9) {
            url = endorsement_url;
            params = params.append('policyNo', param.inputData);
            params = params.append('endNo', param.inputData);
        } else if (category == 10) {
            url = under_writer_quotation_url;
            params = params.append('quoNo', param.inputData);
            params = params.append('classCode', param.classCode);
        } else if (param.categoryType == 4) {
            url = entity_url;
        } else { url = urlstr; }
        return this.http.get<any>(url, { params: params, headers: httpHeaders }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getSearchResults')));
    }

    getCoulmnHeaderConfig(headerConfig): Observable<any> {
        return this.http.get<any>(headerConfig).pipe(
            map(res => res));
    }
    getCreditData(): Observable<CreditDebit[]> {
        return this.http.get<CreditDebit[]>(RSAENDPOINTConstants.CREDITJSON).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCreditData')));
    }
    getPreviewReceipt(receipt: any) {
        let url: string = RSAENDPOINTConstants.GETRECEIPTPREVIEW + receipt;
        return this.http.get<CreditDebit[]>(url).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPreviewData')));
    }


}
