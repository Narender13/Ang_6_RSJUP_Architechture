import { Injectable } from '@angular/core';
import { Subject, Observable, BehaviorSubject } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class BatchUploadService {
    httpheaders = new HttpHeaders(
        {
            'Access-Control-Allow-Headers': 'Content-Type,Origin,content-type',
            'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Origin': '*',
            'Content-Disposition': 'form-data',
            'enctype': 'multipart/form-data'
        });

    constructor(private http: HttpClient) { }

    uploadBatchFile(file: File, param): Observable<any> {
        console.log(param.acc + '----------acc');
        console.log(param.gl + '----------gl');
        const formdata: FormData = new FormData();
         // formdata.append('AccountCode', param.acc);
         // formdata.append('GlCode', param.gl);
         formdata.append('filename', file, file.name);
         formdata.append('GLCode', '1115');
         formdata.append('AccountCode', '1410');
        // Remove once get correct data from API //
         // return this.http.get<any>(RSAENDPOINTConstants.MATCHED_UNMATCHED).pipe(
        return this.http.post<any>(RSAENDPOINTConstants.BULKUPLOAD, formdata, {
            reportProgress: true,
            headers: this.httpheaders
        }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('uploadBatchFile')));
    }
}
