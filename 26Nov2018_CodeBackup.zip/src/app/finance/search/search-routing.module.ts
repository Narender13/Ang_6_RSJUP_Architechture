import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchResultsComponent } from './search-results/search-results.component';
import { CustomComponentModelComponent } from 'src/app/shared/custom-component-model/custom-component-model.component';


const routes: Routes = [
    { path: '', redirectTo: '/result', pathMatch: 'full' },
    {
        path: 'result', component: SearchResultsComponent, data: { breadcrumb: 'home' }
    },
    {
        path: 'create', component: CustomComponentModelComponent, data: { breadcrumb: 'create' }
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SearchRoutingModule { }
