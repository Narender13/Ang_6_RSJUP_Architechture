
export class CreateCreditNotes {
    VoucherDate:string;
    ApprovedBy?: string;
    ArabicDescription?: any;
    CostCenterCode?: string;
    CountryCode: number;
    CustomerID?: any;
    CustCode?: string;
    EnglishDescription: string;
    GLCode: number;
    LocationCode: string;
    ModifiedDate?: string;
    ModifiedBy?: string;
    PayeeName: string;
    PostedDate?: string;
    PreparedBy: string;
    PreparedDate?: string;
    PreprintNo?:string;
    PrintDate?: string;
    RefreshDate?: string;
    RegionCode: string;
    Title:string;
    TotallingAccCode?:string;
    Approvers?: any[];    
    CreditNoteDetail: CreditNotesDetail[];    
}

export class CreditNotesDetail {
    Amount: string;
    AnalysisCode: string;
    CostCenterCode: string;
    ClaimID:number;
    ClassCode: string;
    CauseOfLossCode?:number;
    CounterPartyRef?: any;
    CountryCode: number;
    Description: string;
    DocumentCode?: any;
    EntityID?:any;
    GLCode: number;
    LocationCode: string;
    ModifiedBy: string;
    ModifiedDate?: string;
    NatureOfLossCode?:number;
    PolicyID?: any; 
    PolicyYear?: any;
    PreparedBy?: any;
    PreparedDate?: string;
    RefTransactionID?: any;
    RefTransactionSerialNo?: any;
    RefTransactionType: number;    
    RegionCode: string;
    TotallingAccCode: number;
    newAddedRow?:boolean;
    VoucherNo?:number;
}
