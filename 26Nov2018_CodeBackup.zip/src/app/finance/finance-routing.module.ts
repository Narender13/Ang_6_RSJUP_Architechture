import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DialogComponent } from './dialog/dialog.component';
import { EntitiesComponent } from './entities/entities.component';
import { ChequePrintComponent } from './payments/cheque-print/cheque-print.component';
import { DraftsResultsComponent } from 'src/app/finance/drfats/drafts-results/drafts-results.component';
// import { CnpreviewComponent } from './preview/oman/cnpreview/cnpreview.component';
const routes: Routes = [


    {
        path: '',
        children: [
            {
                path: 'receipt/new',
                component: DialogComponent
            },
            { path: 'payment/new', component: DialogComponent },
            { path: 'receipt/preview', component: DialogComponent },
            { path: 'receipt/cancel', component: DialogComponent },
            { path: 'creditnotes/new', component: DialogComponent },
            { path: 'debitnotes/new', component: DialogComponent },
            { path: 'receipt/new/entiti', component: DialogComponent },
            { path: 'receipt/rowselection/entiti', component: DialogComponent },
            { path: 'receipt/claim', component: DialogComponent },
            { path: 'entiti/preview', component: DialogComponent },
            {
                path: 'entitie/new', component: EntitiesComponent, data: {
                    breadcrumb: 'Create Entitie'
                }
            },
            { path: 'result', loadChildren: 'src/app/finance/search/search.module#SearchModule' },
            {
                path: 'draft', component: DraftsResultsComponent, data: { breadcrumb: 'home' }
            },

            { path: 'finance/cheque', component: ChequePrintComponent },
        ]
    }



];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FinanceRoutingModule { }
