import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'rsa-payment-mode-credit-card-form-feilds',
  templateUrl: './payment-mode-credit-card-form-feilds.component.html',
  styleUrls: ['./payment-mode-credit-card-form-feilds.component.scss']
})
export class PaymentModeCreditCardFormFeildsComponent implements OnInit {

  @Input() credirCard: FormGroup;
  @Input() errorterminalID;
  @Input() errorchequedate;
  @Input() errorchequeno;
  @Input() terminals = [];
  constructor() { }

  ngOnInit() {
    console.log(this.errorchequeno, 'chequeInfo');
  }


  get getTerminalCode() {
    return this.credirCard['controls'].TerminalID;
  }

  get chequedate() {
    return this.credirCard.controls.ChequeDate;
  }


  get chequeno() {
    return this.credirCard.controls.ChequeNo;
  }


}
