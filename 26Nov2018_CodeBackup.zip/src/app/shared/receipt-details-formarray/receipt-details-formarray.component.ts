import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';

@Component({
  selector: 'rsa-voucher-details-formarray',
  templateUrl: './receipt-details-formarray.component.html',
  styleUrls: ['./receipt-details-formarray.component.scss']
})
export class VoucherDetailsFormarrayComponent implements OnInit {
  @Input() voucherDetails: FormGroup;
  @Input() index;
  @Input() pjctindicator = [];
  @Input() department = [];
  @Input() transactiontype = [];
  @Input() glaccount = [];
  @Input() isEntityPaymentFeildReq;
  @Input() dtltotallingacc = [];
  @Input() costcentredata = [];
  @Input() branchdata = [];
  @Input() voucherDetailsLength;
  @Output() getTotalAmount = new EventEmitter();
  @Output() deleteReceiptRow = new EventEmitter();
  @Output() debitCreditEvent = new EventEmitter();
  @Output() getGLdataO = new EventEmitter();
  @Output() getTotallingDetailDataO = new EventEmitter();
  @Output() setHiddenValueO = new EventEmitter();
  @Output() clearGLCodeO = new EventEmitter();
  @Output() changeCostcenterO = new EventEmitter();
  @Input() ondemandFlag = false;
  @Input() cndnflag;
  constructor() { }

  ngOnInit() {
    console.log(this.voucherDetailsLength, 'receiptDetails');
  }

  getSum() {
    this.getTotalAmount.emit();
  }
  deleteReceipt(ev, i, data?) {
    this.deleteReceiptRow.emit({ event: ev, index: i, data: data });
  }
  setCreditEntry(ev, i, iscredit, data?) {
    this.debitCreditEvent.emit({ event: ev, index: i, iscredit: iscredit, data: data });
  }
  getGLData(ev, index, flag) {
    this.getGLdataO.emit({ ev: ev.target.value, index: index, flag: flag });
  }

  getTotallingDetailData(index, flag) {
    this.getTotallingDetailDataO.emit({ index: index, flag: flag });
  }
  setHiddenValue(event, index, item, item1) {
    this.setHiddenValueO.emit({ event: event, index: index, item: item, item1: item1 });
  }
  clearGLCode(ev, index) {
    this.clearGLCodeO.emit({ event: ev, index: index });
  }

  changeCostcenter(ev, index, flag) {
    this.changeCostcenterO.emit({ event: ev, index: index, flag: flag });
  }

}
