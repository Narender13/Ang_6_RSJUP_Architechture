import { HttpErrorResponse } from '@angular/common/http';
import { throwError, Observable, of } from 'rxjs';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { BsModalService } from 'ngx-bootstrap/modal';
import { DOCUMENT } from '@angular/common';


export const handleErrorObservable = function <T>(operation = 'operation', result?: T) {
    // if (error.error instanceof ErrorEvent) {
    //     console.error('Error sending a request", error.error.message');
    // } else {
    //     console.log('error', error);
    //     console.error(
    //         `Backend returned code ${error.status}, ` +
    //         `body was: ${error.error}`);
    // }
    // return throwError(
    //     'Something bad happened; please try again later.');
    return (error: any): Observable<T> => {

        // TODO: send the error to remote logging infrastructure
        console.error(error); // log to console instead

        // TODO: better job of transforming error for user consumption
        console.log(`${operation} failed: ${error.message}`);

        // Let the app keep running by returning an empty result.
        return of(result as T);
    };
};


export function getShortDate(dateVal: Date) {
    console.log(dateVal);
    const month_names = ['1', '2', '3',
        '4', '5', '6',
        '7', '8', '9',
        '10', '11', '12'];

    const day = dateVal.getDate();
    const month_index = dateVal.getMonth();
    const year = dateVal.getFullYear();

    return '' + day + '/' + month_names[month_index] + '/' + year;
}



export function getShortDateCreditCard(dateVal: Date) {
    console.log(dateVal);
    const month_names = ['1', '2', '3',
        '4', '5', '6',
        '7', '8', '9',
        '10', '11', '12'];

    const month_index = dateVal.getMonth();
    const year = dateVal.getFullYear();

    return month_names[month_index] + '/' + year;
}

export function validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}


