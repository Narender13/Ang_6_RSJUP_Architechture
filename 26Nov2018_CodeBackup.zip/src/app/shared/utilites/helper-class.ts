import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { map } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { Injectable, Inject, Renderer2 } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Injectable({
    providedIn: 'root'
})

export class UtilityClass {
    private readonly isModelCurrentInstance = new Subject<any>();


    constructor(@Inject(DOCUMENT) private document: Document, private modalService: BsModalService,
        public bsModalRef: BsModalRef, private renderer: Renderer2) {

    }

    isModalShow() {
        return this.isModelCurrentInstance.asObservable();
    }

    checkIsformDirty(formname) {
        if (formname.dirty || formname.touched) {
            console.log('cmg here');
            this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
            this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
            this.bsModalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
            this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
            this.bsModalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
            this.bsModalRef.content.valueChange.subscribe((data) => {
                console.log(data, 'data');
                if (data = 'PROCEED') {
                    this.isModelCurrentInstance.next(true);
                }
            });

        } else {
            this.isModelCurrentInstance.next(false);
            this.modalService.hide(1);
        }

    }

    removeModalRefOnClose() {
        this.renderer.removeClass(this.document.body, 'modal-open');
    }
}
