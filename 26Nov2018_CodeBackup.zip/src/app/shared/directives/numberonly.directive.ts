import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[numberOnly]'
})
export class NumberOnlyInputDirective {
    // Allow decimal numbers and negative values
    private regex: RegExp = new RegExp(/^-?[0-9]+(\.[0-9] *){0,1}$/g);
    // Allow key codes for special events. Reflect :
    // Backspace, tab, end, home
    private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home'];

    constructor(private el: ElementRef) {
    }

    @HostListener('paste', ['$event']) onEvent($event) {
        const initalValue = $event.clipboardData.getData('text').replace(/[^0-9]*/g, '');
        if (initalValue !== $event.clipboardData.getData('text')) {
            // blocks write to input element
            event.preventDefault();
        }
    }

    @HostListener('keypress', ['$event'])
    onkeypress(event: KeyboardEvent) {
        console.log('umakant', event);
        // Allow Backspace, tab, end, and home keys
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode > 31
            && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }
}
