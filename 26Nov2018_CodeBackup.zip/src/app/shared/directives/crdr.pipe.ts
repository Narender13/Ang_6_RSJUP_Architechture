import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'crdr'
})
export class CrDrAmount implements PipeTransform {
    transform(value) {
        console.log(value);
        const fitstvalue = String(value).charAt(0);

        if (fitstvalue == '-') {
            return fitstvalue.toString().replace('-', value.toString().substring(1, value.length) + ' ' + 'Cr' );
        } else {
            return  value + ' ' + 'Dr' ;
        }

    }
}
