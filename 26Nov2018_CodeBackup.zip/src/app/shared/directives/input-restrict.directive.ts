import { Directive, HostListener, Input } from '@angular/core';
@Directive({
    selector: '[inputrestrict]'
})
export class InputRestrictDirective {


    @Input() isinputrestrict: boolean;

    @HostListener('keypress', ['$event']) onKeyPress(event) {
        return event.preventDefault();
    }
}
