import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'creditsign'
})
export class CreditAmount implements PipeTransform {
    transform(value) {
        console.log(value);

        const fitstvalue = String(value).charAt(0);

        if (fitstvalue === '-') {
            return fitstvalue.toString().replace('-', 'Cr ') + value.toString().substring(1, value.length);
        } else {
            return value;
        }

    }
}