import { Directive, Input, HostListener } from '@angular/core';

@Directive({
    selector: '[credit-card-space]'
})
export class AddSpaceDirective {
    @Input() creditcard: boolean;

    @HostListener('input', ['$event']) onKeyPress(e) {
        e.target.value = e.target.value.replace(/[^\dA-Z]/g,'').replace(/(.{4})/g, '$1 ').trim();
    }
}
