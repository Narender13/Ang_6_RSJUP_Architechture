import { Directive, ElementRef, Output, EventEmitter, HostListener } from '@angular/core';

@Directive({
  selector: '[rsa-click-outside]'
})
export class ClickoutsideDirective {

  @Output() public clickOutside = new EventEmitter();
  constructor(private elementRef: ElementRef) { }

  @HostListener('document:click', ['$event.target']) public onClick(targetElement) {

    let isClickedInside: boolean = this.elementRef.nativeElement.contains(targetElement);
    if (!isClickedInside) {

      this.clickOutside.emit(true);
    }
  }

}
