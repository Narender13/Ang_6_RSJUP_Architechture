import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'removeminus'
})
export class CreditSignAmount implements PipeTransform {
    transform(value) {
        console.log(value);
        const fitstvalue = String(value).charAt(0);

        if (fitstvalue == '-') {
            return fitstvalue.toString().replace('-', '') + value.toString().substring(1, value.length);
        } else {
            return value;
        }

    }
}
