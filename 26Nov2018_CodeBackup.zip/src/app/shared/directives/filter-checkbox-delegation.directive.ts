import { Directive, HostBinding, HostListener, Input, Output, EventEmitter } from '@angular/core';

@Directive({
  selector: '[filtercheckboxdelegation]'
})
export class FilterCheckboxDelegationDirective {
  @Output() filterObjectVal:EventEmitter<any> = new EventEmitter<any>();
  @Input('filtercheckboxdelegation') columnhead:string;

  constructor() { }
  private FilterItems:any=[];
  private objectDynamic:object;
  @HostListener('change',['$event']) getSelectedItem($event){
    $event.stopPropagation();
    this.objectDynamic={}
    if( $event.target.type==='checkbox'){
        let chkFlag=$event.target.checked;
       
        this.objectDynamic[this.columnhead]=$event.target.value;
          if(chkFlag)
          this.FilterItems.push(this.objectDynamic);
          else
         { 
           this.FilterItems.forEach(
              (element,i) => { 
              if(element [this.columnhead] == $event.target.value) return this.FilterItems.splice(i,1);  }
          )
           
         }
   }
   
   this.filterObjectVal.emit(this.FilterItems);
  }

}
