import { Directive, HostBinding, HostListener, Input, ElementRef, Renderer } from '@angular/core';

@Directive({
  selector: '[rsalabelanimate]'
})
export class LabelanimateDirective {

  constructor(private el: ElementRef, private renderer: Renderer) {

  }

  @HostBinding('class.animated') animated = 'animated';

  @HostListener('focusin') focused(event) {
    this.animated = '';
  }

}
