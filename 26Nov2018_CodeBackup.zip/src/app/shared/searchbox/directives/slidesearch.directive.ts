import { Directive, HostBinding, Input, ElementRef, Renderer2, HostListener } from '@angular/core';

@Directive({
  selector: '[rsa-search-slide]'
})
export class SlidesearchDirective {

  @Input('slidesearchbox') innerbox: ElementRef;
  constructor(private renderer: Renderer2) { }

  @HostListener('click', ['$event']) public onClick(event) {
     this.renderer.addClass(this.innerbox,'slide-search');
  }
}
