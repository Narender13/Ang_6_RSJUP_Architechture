import { Component, OnInit, Renderer2, ElementRef, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HomeService } from '../../home/services/home.service';
import { CategoryType } from '../../finance/search/model/category';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
@Component({
  selector: 'rsa-searchbox',
  templateUrl: './searchbox.component.html',
  styleUrls: ['./searchbox.component.scss']
})
export class SearchboxComponent implements OnInit {
  // private searchForm: FormGroup;
  categories: any;
  private searchdata: any;
  private searchval = '';
  category: any;
  categoryItem: string;
  private invalidsearch: boolean;
  entitySerachId;
  entitySerachType;
  entitySerachItem;
  entitysearchlist;
  categoryselectedValue = 'Select Category';
  titleText = 'Please select the LOB before selecting category';
  lobvalue = 'Select LOB';
  lob: number;
  lobItem: string;
  isVewedEnable = true;
  isDisabled = true;
  lobData: any = [];
  categorydata: CategoryType[] = [];
  @Output() searchvalemit = new EventEmitter<string>();
  constructor(private fb: FormBuilder, private renderer: Renderer2,
    private router: Router, private homeservice: HomeService, private alertService: AlertService) { }

  ngOnInit() {
    this.getCategorydataData();
    this.getLobData();
  }

  emitSearchValue() {
    this.searchvalemit.emit(this.searchval);
  }
  getLobData(): void {
    this.homeservice.getLobDataList().subscribe((data) => {
      this.lobData = data;
      console.log(data, 'data');
    });
  }

  setLobDefaults() {
    this.categorydata = [
      { id: 1, item: 'Policy No' },
      { id: 8, item: 'Claim No' },
      { id: 10, item: 'Quotation No' }
    ];
    this.isVewedEnable = false;
  }

  setLobDefaultsAccts() {
    this.categorydata = [
      { id: 2, item: 'Receipt No' },
      { id: 3, item: 'Payment No' },
      { id: 4, item: 'Entity' },
      { id: 5, item: 'Credit Note No' },
      { id: 6, item: 'Tax Invoice No' },
      { id: 7, item: 'Journal No' },
      { id: 11, item: 'Payee Name' },
      { id: 12, item: 'Cheque No' },
      { id: 13, item: 'Approval Code' }
    ];

  }

  setLob(lob: CategoryType) {
    this.lob = lob.id;
    this.lobItem = lob.item;
    this.searchval = '';
    this.titleText = '';
    this.isDisabled = false;
    if (lob.id == 0) {
      this.categoryselectedValue = 'Select Category';
      this.setLobDefaultsAccts();
      this.isVewedEnable = true;
    } else {
      this.categoryselectedValue = 'select category';
      this.setLobDefaults();
    }

  }

  setSelectedCategory(category: CategoryType) {
    this.category = category.id;
    this.categoryItem = category.item;
    this.searchval = '';
  }


  search() {
    this.invalidsearch = (this.category !== undefined && this.category > 0) &&
      (this.lob !== undefined) &&
      (this.searchval !== undefined && this.searchval !== '' && this.searchval.length > 0);
    if (this.invalidsearch) {
      let params;
      if (this.category == 4) {
        params = {
          'id': this.entitySerachId,
          'entityType': this.entitySerachType,
          'entityUnMatched': 0,
          'categoryType': this.category,
          'entitySerachItem': this.entitySerachItem,
        };
      } else {
        params = {
          'inputData': this.searchval,
          'category': this.category,
          'categoryitem': this.categoryItem,
          'classCode': this.lob,
          'lobitem': this.lobItem,
        };
      }
      this.router.navigate(['home/search/result'], {
        queryParams: params
      });
    }
  }

  getCategorydataData(): void {
    this.homeservice.getCategoryData().subscribe((dropDowndata) => {
      this.categories = dropDowndata;
    });
  }

  getEntitySearchListData(params): void {
    console.log('calling function' + params);
    this.homeservice.getEntitySearchListData(this.searchval)
      .subscribe((searchlistdata) => {
        this.entitysearchlist = searchlistdata;
        console.log(this.entitysearchlist, 'enti');
      });
  }

  typeaheadOnSelect(typeheadobj: TypeaheadMatch): void {
    console.log('Selected value: ', typeheadobj);
    this.entitySerachId = typeheadobj.item.id;
    this.entitySerachType = typeheadobj.item.entityEnum;
    this.entitySerachItem = typeheadobj.item.name;
  }

  lookUpChange(e) {
    if (e.srcElement.value.length >= 2) {
      this.getEntitySearchListData(e.srcElement.value);
    } else {
      this.entitysearchlist = [];
    }
  }
}
