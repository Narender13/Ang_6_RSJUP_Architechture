import { Component, Input, ViewChild, EventEmitter, OnInit, Output, ElementRef } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ModalDirective } from 'ngx-bootstrap/modal';
@Component({
    selector: 'app-confirmation-dialog',
    templateUrl: './custom-model.component.html',
    styleUrls: ['./custom-model.component.scss']
})
export class ConfirmationDialogComponent implements OnInit {
    cancelBtn: string;
    actionBtn: string;
    modelTitle: string;
    modelBodyContent: string;
    smallMessage: string;
    list: any[] = [];
    @Output() valueChange = new EventEmitter();

    constructor(private modalService: BsModalService,
        public bsModalRef: BsModalRef) {

    }
    valueChanged(e) {
        this.valueChange.emit(e.srcElement.innerText);
        this.bsModalRef.hide();
    }

    ngOnInit() {
        this.list.push('PROFIT!!!');
    }
}



// open() {
//     const initialStateData = {
//         list: [
//             'Open a modal with component',
//             'Pass your data',
//             'Do something else',
//             '...'
//         ],
//         modelTitle: 'Modal with component',
//         modelBodyContent: 'Modal with component',
//         cancelBtn: 'Cancel',
//         actionBtn: 'Submit',
//         class: 'confirmation-dailog-box modal-lg'
//     };

//     const classObj = {
//         class: 'confirmation-dailog-box modal-lg'
//     };

//     const initialState = Object.assign({}, initialStateData);

//     this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-lg' });
//     this.bsModalRef.content.modelTitle = 'Alert';
//     this.bsModalRef.content.modelBodyContent = 'This policy has a premium outstanding and will require additional approvals';
//     this.bsModalRef.content.cancelBtn = 'cancel';
//     this.bsModalRef.content.actionBtn = 'submit';
//     this.bsModalRef.content.smallMessage = 'Click OK to continue with above transaction';

//     this.bsModalRef.content.valueChange.subscribe((data) => {
//         console.log(data, 'data');
//         if (data = 'Submit') {
//             alert('anki');
//             this.message = data;
//         }

//         if (data === 'actionBtn') {
//             alert('anki');
//         }
//     });

// }