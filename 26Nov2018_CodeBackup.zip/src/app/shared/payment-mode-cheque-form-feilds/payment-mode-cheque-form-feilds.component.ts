import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
@Component({
  selector: 'rsa-payment-mode-cheque-form-feilds',
  templateUrl: './payment-mode-cheque-form-feilds.component.html',
  styleUrls: ['./payment-mode-cheque-form-feilds.component.scss']
})
export class PaymentModeChequeFormFeildsComponent implements OnInit {
  @Input() chequeInfo: FormGroup;
  @Input() errorbankcode;
  @Input() errorchequedate;
  @Input() errorchequeno;
  @Input() payeedataBankName = [];
  constructor() { }

  ngOnInit() {
    console.log(this.errorchequeno, 'chequeInfo');
  }


  get getpayeeBankcode() {
    return this.chequeInfo['controls'].PayeeBankCode;
  }

  get chequeDate() {
    return this.chequeInfo.controls.ChequeDate;
  }


  get chequeno() {
    return this.chequeInfo.controls.ChequeNo;
  }




}
