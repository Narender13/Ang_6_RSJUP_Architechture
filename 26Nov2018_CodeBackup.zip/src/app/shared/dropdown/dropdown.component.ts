import { Component, OnInit, Input, Renderer2, AfterViewInit, ElementRef, ViewChild, Output, EventEmitter } from '@angular/core';
import { Slide } from '../animation/slide';

@Component({
  selector: 'rsa-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
  animations: [Slide]
})
export class DropdownComponent implements OnInit, AfterViewInit {

  @Input() data: any;
  @Input() selectedValue;
  @Input() cssClass: string;
  @ViewChild('dropbtn') dropdownObj: ElementRef;
  @Output() getDountDropdownData = new EventEmitter();
  animationState = 'out';

  constructor(private renderer2: Renderer2) { }

  ngOnInit() {

  }
  openMenu(objdropdown) {
    this.animationState = this.animationState === 'out' ? 'in' : 'out';
    this.renderer2.removeClass(objdropdown, 'viewless');
    this.renderer2.removeClass(objdropdown, 'viewall');
  }

  handleDropdownEvent(objdropdown, ev) {
    if (ev.target.tagName === 'A') {

      this.selectedValue = ev.target.text;
      this.animationState = 'out';

    }
  }
  ngAfterViewInit() {
    this.renderer2.addClass(this.dropdownObj.nativeElement, this.cssClass);
  }

  closePopup() {
    this.animationState = 'out';
  }

  getSelectedItem(item) {
    this.getDountDropdownData.emit({ item: item, selectedValue: this.selectedValue });
  }

}
