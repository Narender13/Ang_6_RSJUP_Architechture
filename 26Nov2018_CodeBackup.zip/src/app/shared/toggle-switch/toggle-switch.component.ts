import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'rsa-toggle-switch',
  templateUrl: './toggle-switch.component.html',
  styleUrls: ['./toggle-switch.component.scss']
})
export class ToggleSwitchComponent implements OnInit {
  @Input() isChecked;
  @Input() isDiabled;
  @Output() changeHandler = new EventEmitter();
  constructor() { }

  ngOnInit() {
    console.log(this.isDiabled, 'isDiabled');
  }

  setCreditEntry(changeEvent) {
    console.log(changeEvent, 'changeEvent');
    this.changeHandler.emit(changeEvent);
  }

}
