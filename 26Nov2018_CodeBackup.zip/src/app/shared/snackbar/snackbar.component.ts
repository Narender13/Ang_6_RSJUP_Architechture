import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
@Component({
  selector: 'rsa-snackbar',
  templateUrl: './snackbar.component.html',
  styleUrls: ['./snackbar.component.scss']
})
export class SnackBarComponent implements OnInit {
  field;
  @Input() totalAmount;
  @Input() totalCount;
  show = true;
  @Input() buttonNames = [];
  @Output() getbuttonhandler = new EventEmitter();
  @Output() hideSnackBar = new EventEmitter();
  constructor() { }

  ngOnInit() {
    console.log(this.totalAmount, 'totalamount');
  }


  buttonHandler(buttonName) {
    this.getbuttonhandler.emit(buttonName);
  }
  close() {
    this.hideSnackBar.emit(this.show);
  }
}

