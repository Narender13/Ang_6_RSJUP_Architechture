import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { SharedService } from 'src/app/finance/services/shared.service';

@Component({
  selector: 'rsa-custom-model-footer',
  templateUrl: './custom-model-footer.component.html',
  styleUrls: ['./custom-model-footer.component.scss']
})
export class CustomModelFooterComponent implements OnInit {
  @Input() level;
  @Input() totalAmount;
  @Input() title;
  @Input() approverusers;
  collapsetoheader: boolean;
  displayApprover = false;
  @Output() reSetFormOp = new EventEmitter();
  @Output() goNextOp = new EventEmitter();
  @Output() goPreviousOp = new EventEmitter();
  @Output() createReceipt = new EventEmitter();
  @Output() userChangeOp = new EventEmitter();
  @Input() users = [];
  constructor(private sharedService: SharedService) { }

  ngOnInit() {
    this.getCollpaseExpand();
  }

  reSetForm(ev, defaultParam) {
    this.reSetFormOp.emit({ event: ev, defaultParam: defaultParam });
  }

  submitForm() {
    this.createReceipt.emit();
  }
  onUserChange(event, item) {
    this.userChangeOp.emit({ event: event, item: item });
  }

  goPrevious() {
    this.goPreviousOp.emit();
  }

  goNext() {
    this.goNextOp.emit();
  }

  getCollpaseExpand() {
    this.sharedService.getMessage().subscribe(val => {
      console.log(val);
      if (val === 'collapse') {
        this.collapsetoheader = true;
      } else {
        this.collapsetoheader = false;
      }
    });
  }
}
