import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';

@Component({
  selector: 'rsa-account-location',
  templateUrl: './account-location.component.html',
  styleUrls: ['./account-location.component.scss']
})
export class AccountLocationComponent implements OnInit {

  @Input() accountInfo: FormGroup;
  @Input() branchdata = [];
  @Input() costcentredata = [];
  @Input() receiverdataBankName = [];
  @Input() totallingacc = [];
  @Output() getTotallingDataO = new EventEmitter();
  @Output() setBankDataO = new EventEmitter();
  constructor(private masterDataService: MasterDataService) { }

  ngOnInit() {
  }

  getTotallingData(event, flag) {
    this.getTotallingDataO.emit({ event: event, flag: flag });
  }
  changeBankData(event, flag) {
    this.setBankDataO.emit({ event: event, flag: flag });
  }
}
