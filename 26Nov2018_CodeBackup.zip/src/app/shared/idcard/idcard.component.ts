import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'rsa-idcard',
  templateUrl: './idcard.component.html',
  styleUrls: ['./idcard.component.scss']
})
export class IdcardComponent implements OnInit {
  @Input() id: number;
  @Input() gl: string;
  @Input() name: string;
  @Input() categoryid:any;
  constructor() { }

  ngOnInit() {
  }

}
