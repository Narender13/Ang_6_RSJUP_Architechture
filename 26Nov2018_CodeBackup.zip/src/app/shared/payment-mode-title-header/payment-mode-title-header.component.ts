import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-payment-mode-title-header',
  templateUrl: './payment-mode-title-header.component.html',
  styleUrls: ['./payment-mode-title-header.component.scss']
})
export class PaymentModeTitleHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
