
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TooltipModule } from 'ngx-bootstrap';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgXDonutChartModule } from 'ngx-donutchart';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap';
import { UiSwitchModule } from 'ngx-toggle-switch';

import { SearchService } from '../finance/search/service/search.service';
import { BsModalService } from 'ngx-bootstrap/modal';

import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { FoldmenuComponent } from './foldmenu/foldmenu.component';
import { MultiselectComponent } from './multiselect/multiselect.component';
import { DropdownComponent } from './dropdown/dropdown.component';
import { DonutchartComponent } from './donutchart/donutchart.component';
import { IdcardComponent } from './idcard/idcard.component';
import { SearchboxComponent } from './searchbox/searchbox.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { ConfirmationDialogComponent } from './custom-model/custom-model.component';
import { AlertComponent } from './alert-rsa/alert.component';
import { SnackBarComponent } from './snackbar/snackbar.component';

import { RowoverdisplayDirective } from './directives/rowoverdisplay.directive';
import { FilterCheckboxDelegationDirective } from './directives/filter-checkbox-delegation.directive';
import { ClickoutsideDirective } from './directives/clickoutside.directive';
import { LabelanimateDirective } from './directives/labelanimate.directive';
import { TypeaheadDirective } from './directives/typeahead.directive';
import { SlidesearchDirective } from './searchbox/directives/slidesearch.directive';
import { ClickmenuDirective } from './foldmenu/directives/clickmenu.directive';
import { NavclickDirective } from './directives/navclick.directive';


import { DateFormatPipe } from './pipes/dateFormat-pipe';
import { SpecialCharacterDirective } from 'src/app/shared/directives/special-char-restrict.directive';
import { AllowCharacterDirective } from 'src/app/shared/directives/allow-char-only.directive'
import { NumberOnlyDirective } from 'src/app/shared/directives/allow-number.directive';
import { InputRestrictDirective } from 'src/app/shared/directives/input-restrict.directive';
import { CreditAmount } from 'src/app/shared/directives/credit-sign-directive';
import { AddSpaceDirective } from 'src/app/shared/directives/credit-number-space.directive';
import { ToggleSwitchComponent } from './toggle-switch/toggle-switch.component';
import { CreditSignAmount } from 'src/app/shared/directives/remove-minus-pipe';
import { CurrencyRendererComponent } from 'src/app/shared/datatable/services/currency-renderer.component';
import { CustomComponentModelComponent } from './custom-component-model/custom-component-model.component';
import { CustomModelHeaderComponent } from './custom-model-header/custom-model-header.component';
import { CustomModelFooterComponent } from './custom-model-footer/custom-model-footer.component';
import { FilterPipe } from 'src/app/shared/pipes/filter.pipe';
import { PaymentHeaderDetailsComponent } from './payment-header-details/payment-header-details.component';
import { RsaDefaultAccountsComponent } from './rsa-default-accounts/rsa-default-accounts.component';
import { PaymentModeTitleHeaderComponent } from './payment-mode-title-header/payment-mode-title-header.component';
import { PaymentModeReviewHeaderComponent } from './payment-mode-review-header/payment-mode-review-header.component';
import { PaymentModeChequeFormFeildsComponent } from './payment-mode-cheque-form-feilds/payment-mode-cheque-form-feilds.component';
import { PaymentModeCreditCardFormFeildsComponent } from './payment-mode-credit-card-form-feilds/payment-mode-credit-card-form-feilds.component';
import { PaymentModeBankTransferFormFeildsComponent } from './payment-mode-bank-transfer-form-feilds/payment-mode-bank-transfer-form-feilds.component';
import { VoucherDetailsFormarrayComponent } from './receipt-details-formarray/receipt-details-formarray.component';
import { FieldErrorComponent } from './field-error/field-error.component';
import { ReceiptBulkMatchUnmatchComponent } from './receipt-bulk-match-unmatch/receipt-bulk-match-unmatch.component';
import { PaymentBulkMatchUnmatchComponent } from './payment-bulk-match-unmatch/payment-bulk-match-unmatch.component';
import { AccountLocationComponent } from './account-location/account-location.component';
import { NumberOnlyInputDirective } from './directives/numberonly.directive';
import { CrDrAmount } from 'src/app/shared/directives/crdr.pipe';

@NgModule({
    declarations: [
        /* components */
        HeaderComponent,
        SidebarComponent,
        FooterComponent,
        FoldmenuComponent,
        MultiselectComponent,
        DropdownComponent,
        DonutchartComponent,
        IdcardComponent,
        SearchboxComponent,
        BreadcrumbComponent,
        ConfirmationDialogComponent,
        CurrencyRendererComponent,
        ToggleSwitchComponent,
        CustomComponentModelComponent,
        CustomModelHeaderComponent,
        CustomModelFooterComponent,
        PaymentHeaderDetailsComponent,
        RsaDefaultAccountsComponent,
        PaymentModeTitleHeaderComponent,
        PaymentModeReviewHeaderComponent,
        PaymentModeChequeFormFeildsComponent,
        PaymentModeCreditCardFormFeildsComponent,
        PaymentModeBankTransferFormFeildsComponent,
        VoucherDetailsFormarrayComponent,


        AlertComponent,
        SnackBarComponent,
        ConfirmationDialogComponent,
        /* directives */
        RowoverdisplayDirective,
        ClickoutsideDirective,
        FilterCheckboxDelegationDirective,
        LabelanimateDirective,
        TypeaheadDirective,
        SlidesearchDirective,
        ClickmenuDirective,
        NavclickDirective,
        SpecialCharacterDirective,
        AllowCharacterDirective,
        NumberOnlyDirective,
        NumberOnlyInputDirective,
        InputRestrictDirective,
        AddSpaceDirective,
        /* Pipes */
        DateFormatPipe,
        CreditAmount,
        CreditSignAmount,
        CrDrAmount,
        FilterPipe,
        FieldErrorComponent,
        ReceiptBulkMatchUnmatchComponent,
        PaymentBulkMatchUnmatchComponent,
        AccountLocationComponent

    ],
    imports: [
        CommonModule,
        RouterModule,
        BsDatepickerModule.forRoot(),
        TabsModule.forRoot(),
        TypeaheadModule.forRoot(),
        TooltipModule.forRoot(),
        ModalModule.forRoot(),
        NgxSpinnerModule,
        NgxPaginationModule,
        NgXDonutChartModule,
        FormsModule,
        ReactiveFormsModule,
        UiSwitchModule

    ],
    providers: [SearchService, BsModalService],
    exports: [
        /* components */
        HeaderComponent,
        SidebarComponent,
        FooterComponent,
        FoldmenuComponent,
        MultiselectComponent,
        DonutchartComponent,
        IdcardComponent,
        DropdownComponent,
        BreadcrumbComponent,
        ConfirmationDialogComponent,
        AlertComponent,
        SnackBarComponent,
        ConfirmationDialogComponent,
        ToggleSwitchComponent,
        CurrencyRendererComponent,
        CustomComponentModelComponent,
        CustomModelHeaderComponent,
        CustomModelFooterComponent,
        PaymentHeaderDetailsComponent,
        RsaDefaultAccountsComponent,
        PaymentModeReviewHeaderComponent,
        PaymentModeTitleHeaderComponent,
        PaymentModeChequeFormFeildsComponent,
        PaymentModeCreditCardFormFeildsComponent,
        PaymentModeBankTransferFormFeildsComponent,
        VoucherDetailsFormarrayComponent,
        FieldErrorComponent,
        ReceiptBulkMatchUnmatchComponent,
        PaymentBulkMatchUnmatchComponent,
        AccountLocationComponent,


        /* directives */
        RowoverdisplayDirective,
        FilterCheckboxDelegationDirective,
        ClickoutsideDirective,
        LabelanimateDirective,
        TypeaheadDirective,
        NavclickDirective,
        SpecialCharacterDirective,
        AllowCharacterDirective,
        NumberOnlyDirective,
        NumberOnlyInputDirective,
        InputRestrictDirective,
        AddSpaceDirective,
        /* Pipes */
        DateFormatPipe,
        CreditAmount,
        CreditSignAmount,
        CrDrAmount,
        FilterPipe,
        /* modules */
        TypeaheadModule,
        NgxSpinnerModule,
        NgxPaginationModule,
        NgXDonutChartModule,
        BsDatepickerModule,
        TabsModule,
        UiSwitchModule,
        TooltipModule,
        /* Validators */

    ],
    entryComponents: [ConfirmationDialogComponent]
})
export class SharedModule { }
