import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';

@Injectable({
    providedIn: 'root'
})

export class GridService {
    constructor(public datepipe: DatePipe) { }
    getEntityColumnHeaderPropertyNames() {
        return [
            {
                headerName: 'GL Code',
                field: 'GlCode',
                headerCheckboxSelection: true,
                headerCheckboxSelectionFilteredOnly: true,
                checkboxSelection: true,
                type: 'numberColumn',
                filter: 'agSetColumnFilter',
                cellRenderer: 'group',
                cellRendererParams: { suppressCount: true },
                filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                headerTooltip: 'Gl Code',


            },
            {
                headerName: 'Voucher No',
                field: 'VoucherNo',
                // type: 'numericColumn',
                filter: 'agNumberColumnFilter',
                headerTooltip: 'Voucher No',
            },
            {
                headerName: 'Voucher Type',
                field: 'VoucherType',
                filter: 'agSetColumnFilter',
                headerTooltip: 'Voucher Type',
                cellRenderer: function (params) {
                    if (params.value === 'CREDIT NOTE') {
                        return '<span class="fa fa-warning" title="This policy has an outstanding and will require addtional approvals to complete the transaction">' + params.value + '</span>';
                    } else {
                        return params.value;
                    }
                }
            },
            {
                headerName: 'Voucher Date (dd/mm/yyyy)',
                field: 'VoucherDate',
                filter: 'agDateColumnFilter',
                headerTooltip: 'Voucher Date',
                valueFormatter: (data) => {
                    console.log(data.value, 'value');
                    return this.datepipe.transform(data.value, 'dd/MM/yyyy');
                }
            },
            {
                headerName: 'Transaction Type',
                field: 'TransactionType',
                filter: 'agSetColumnFilter',
                headerTooltip: 'Transaction Type',
            },
            {
                headerName: 'Class',
                field: 'Class',
                filter: 'agSetColumnFilter',
                headerTooltip: 'Class',

            },
            {
                headerName: 'Transaction No',
                field: 'TransactionNo',
                filter: 'agTextColumnFilter',
                headerTooltip: 'Transaction No',

            },
            {
                headerName: 'Customer Name',
                field: 'CustomerName',
                filter: 'agSetColumnFilter',
                headerTooltip: 'Customer Name',
            },
            {
                headerName: 'Amount',
                field: 'Amt',
                type: 'numericColumn',
                filter: 'agNumberColumnFilter',
                cellRenderer: 'currencyRenderer',
                headerTooltip: 'Amount',
                valueFormatter: function (params) {
                    return Math.floor(params.value).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
                }

            }
        ];
    }

    getMasterData(params) {
        const counterpartyRefNo = params.data.CounterPartyRef;
        const recptDesc = params.data.Description;
        const refId = params.data.RefTransactionID;
        const refType = params.data.RefTranType;
        const refTranNo = params.data.RefTransactionSerialNo;
        const dept = params.data.DepartmentName;
        const prInd = params.data.AnalysisCode;
        const placeholder = params.data.PlaceHolder;
        const preBy = params.data.PreparedBy;
        const predate = params.data.PreparedDate;
        const aprBy = params.data.ApprovedBy;
        const aprDate = params.data.ApprovedDate;
        return (
            '<div class="entity-parent">' +
            '<div class="entitie-detail">' +

            '<div class="flex-inline row">' +
            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Counter Party Ref.' +
            '</div>' +
            '<div class="e-title-re">' + counterpartyRefNo +
            '</div>' +
            '</div>' +

            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Description' +
            '</div>' +
            '<div class="e-title-re">' + recptDesc +
            '</div>' +
            '</div>' +

            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Ref Tran ID' +
            '</div>' +
            '<div class="e-title-re">' + refId +
            '</div>' +
            '</div>' +

            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Ref Tan Type' +
            '</div>' +
            '<div class="e-title-re">' + refType +
            '</div>' +
            '</div>' +
            '</div>' +

            '<div class="flex-inline row">' +
            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Ref Tran Sl No' +
            '</div>' +
            '<div class="e-title-re">' + refTranNo +
            '</div>' +
            '</div>' +

            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Department Name' +
            '</div>' +
            '<div class="e-title-re">' + dept +
            '</div>' +
            '</div>' +

            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Project Indicator' +
            '</div>' +
            '<div class="e-title-re">' + prInd +
            '</div>' +
            '</div>' +

            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Place Holder' +
            '</div>' +
            '<div class="e-title-re">' + placeholder +
            '</div>' +
            '</div>' +
            '</div>' +

            '<div class="flex-inline row">' +

            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Prepared Date' +
            '</div>' +
            '<div class="e-title-re">' + predate +
            '</div>' +
            '</div>' +

            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Approved Date' +
            '</div>' +
            '<div class="e-title-re">' + aprDate +
            '</div>' +
            '</div>' +


            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Prepared By ' +
            '</div>' +
            '<div class="e-title-re">' + preBy +
            '</div>' +
            '</div>' +



            '<div class="block col-lg-3 ">' +
            '<div class="e-title">Approved By ' +
            '</div>' +
            '<div class="e-title-re">' + aprBy +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>'
        );

    }

}

