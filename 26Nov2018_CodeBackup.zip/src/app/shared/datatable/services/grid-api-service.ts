import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class GridApiService {
    private readonly isDeselectSrc = new Subject<boolean>();

    isUnCheck() {
        return this.isDeselectSrc.asObservable();
    }

    unCheck() {
        this.isDeselectSrc.next(true);
    }



}
