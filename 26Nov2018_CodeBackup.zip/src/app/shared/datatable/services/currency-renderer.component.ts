import { Component, OnInit } from '@angular/core';

import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
    selector: 'currency-cell',
    template: `{{params.value}}`
})
export class CurrencyRendererComponent implements OnInit, ICellRendererAngularComp {
    params: any;
    symbol;

    ngOnInit() {
        this.symbol = (localStorage.getItem('symbol'));
        console.log(this.symbol, 'symbol');
    }


    agInit(params: any): void {
        this.params = params;
    }

    refresh(): boolean {
        return false;
    }
}
