import { Component, OnInit, ViewChild, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { GridService } from 'src/app/shared/datatable/services/grid-service';
import { Entitie } from 'src/app/shared/datatable/model/entitie';
import { MatchUnMatchService } from 'src/app/finance/search/service/match-unmatch.service';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { CurrencyRendererComponent } from 'src/app/shared/datatable/services/currency-renderer.component';

@Component({
  selector: 'app-datatable',
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.scss']
})
export class DatatableComponent implements OnInit, AfterViewInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi;
  gridColumnApi;
  paginationOptions: TextValuePair[] = [];
  selectedData;
  masterData = {};
  @Input() detailRowHeight;
  @Input() detailCellRendererParams;
  @Input() gridConfiguration: GridOptions = {};
  @Input('rowData') rowData: Entitie[] = [];
  @Output() selectedRowDetails = new EventEmitter();
  @Output() deSelectCheckbox = new EventEmitter();
  @Output() hideSnackBar = new EventEmitter();
  entityMatch: TextValuePair[] = [];
  columnDefs = [];
  gridDataselectedRows = [];
  uncheck;
  totalRecepitAmount;
  ifMatched;
  frameworkComponents;
  private selectedTransactionType: string;

  constructor(private http: HttpClient, private gridservice: GridService,
    private matchunmatchservice: MatchUnMatchService, private gridApiService: GridApiService,
    private alertService: AlertService) {
    console.log(this.rowData, 'rowData');
    this.paginationOptions = [
      { id: 2, value: '20' },
      { id: 2, value: '100' },
      { id: 3, value: '500' },
      { id: 4, value: '1000' }
    ];

    this.entityMatch = [
      { id: 0, value: 'UnMatched' },
      { id: 1, value: 'Matched' },
    ];

    this.frameworkComponents = {
      currencyRenderer: CurrencyRendererComponent,
    };
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.gridservice.getEntityColumnHeaderPropertyNames(),
      rowData: this.rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      //paginationAutoPageSize: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 20,
      enableRangeSelection: true,
      rowSelection: 'multiple',
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      masterDetail: true,
      suppressContextMenu: true,
      enableSorting: true,
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 100,
        menuTabs: ['filterMenuTab', '', '']
      },
    };
    this.detailRowHeight = 220;
    const _currentInstance = this;
    this.detailCellRendererParams = {
      getDetailRowData: function (params) {
        params.successCallback(params.data);
        this.fitToCoulmn();
      },
      onFirstDataRendered(params) {
        params.api.sizeColumnsToFit();
      },

      template: function (params) {
        return _currentInstance.gridservice.getMasterData(params);
      }
    };
  }


  ngOnInit() {
    this.gridApiService.isUnCheck().subscribe(() => {
      this.gridConfiguration.api.deselectAll();
    });
  }

  ngAfterViewInit() {
    this.fitToCoulmn();
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }

  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }

  rowGroupOpened(params) {
    if (params.node.expanded) {
      params.api.forEachNode(function (node) {
        if (node.expanded && node.id !== params.node.id && node.uiLevel === params.node.uiLevel) {
          node.setExpanded(false);
        }
      });
    }
  }

  onPageSizeChanged(newPageSize: HTMLSelectElement) {
    const value = +(newPageSize.srcElement.value);
    this.gridApi.paginationSetPageSize(value);
    this.gridApi.sizeColumnsToFit();
  }

  changeMatch(e) {
    const value = +(e.srcElement.value);
    this.ifMatched = value === 1 ? true : false;
    this.matchunmatchservice.getMatchUnMatch(value);
    this.hideSnackBar.emit(value);
  }

  onRowSelected(params) {

    /* for matched disable checkboc */
    if (this.ifMatched) {
      if (params.node.isSelected()) {
        this.alertService.warn('you cant generate the recepit for matched data');
        params.node.setSelected(false);
      }
    }

    /* based on transactiontype create option */
    const isSelect = params.node.isSelected();
    const selectedRows = this.gridApi.getSelectedRows();
    const currRowData = params.data;
    const totalVocherAmount = selectedRows.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
    /* select the vochertype */
    // if (!this.selectedTransactionType) {
    //   this.selectedTransactionType = currRowData.VoucherType;
    //   console.log(this.selectedTransactionType, 'seletedtrantype');
    // }
    const currRowTransactionType = this.selectedTransactionType;
    const vocherEmitedDetails = {
      amount: totalVocherAmount,
      count: selectedRows.length,
      transactionType: this.selectedTransactionType,
      selectedrow: selectedRows,
    };

    if (isSelect) {
      this.selectedRowDetails.emit({
        vocherEmitedDetails
      });
      // if (currRowTransactionType == 'DEBIT') {
      //   this.selectedRowDetails.emit({
      //     vocherEmitedDetails
      //   });
      // }

      // if (currRowTransactionType == 'CREDIT') {
      //   this.selectedRowDetails.emit({
      //     vocherEmitedDetails
      //   });
      // }

    } else {
      // if (!selectedRows.length) {
      //   this.selectedTransactionType = undefined;
      // }
      this.selectedRowDetails.emit({
        vocherEmitedDetails
      });
    }
  }

}


interface TextValuePair {
  id: number;
  value: string;
}

/* whole Logic */

// if (isSelect) {
//   if (!this.selectedTransactionType) {
//     this.selectedTransactionType = this.getTransactionType(currRowData.TransactionType);
//   }
//   const currRowTransactionType = this.getTransactionType(currRowData.TransactionType);
//   if (this.selectedTransactionType === currRowTransactionType) {
//     if (currRowTransactionType === 'CREDIT' && (totalVocherAmount + currRowData.Amount) < 0) {
//       this.alertService.warn('you cant generate the payment for negative amount');
//       params.node.setSelected(false);
//     } else {
//       totalVocherAmount = selectedRows.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
//       this.selectedRowDetails.emit({
//         amount: totalVocherAmount,
//         count: selectedRows.length,
//         transactionType: this.selectedTransactionType,
//         selectedrow: selectedRows,
//       });
//     }
//   } else {
//     this.alertService.warn(`you cant include ${this.selectedTransactionType} TransactionType with other TransactionType`);
//     params.node.setSelected(false);
//   }
// } else {
//   if (!selectedRows.length) {
//     this.selectedTransactionType = undefined;
//   }
//   totalVocherAmount = selectedRows.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
//   this.selectedRowDetails.emit({
//     amount: totalVocherAmount,
//     count: selectedRows.length,
//     transactionType: this.selectedTransactionType,
//     selectedrow: selectedRows
//   });
// }