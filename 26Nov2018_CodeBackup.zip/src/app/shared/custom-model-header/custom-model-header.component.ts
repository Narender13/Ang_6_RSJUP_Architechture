import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { SharedService } from 'src/app/finance/services/shared.service';

@Component({
  selector: 'rsa-custom-model-header',
  templateUrl: './custom-model-header.component.html',
  styleUrls: ['./custom-model-header.component.scss']
})
export class CustomModelHeaderComponent implements OnInit {
  @Input() totalAmount;
  @Input() currency;
  @Input() title;
  symbol;
  collapsetoheader: boolean;
  @Output() collapseToheaderOp = new EventEmitter();
  @Output() checkIsformDirtyOp = new EventEmitter();
  constructor(private sharedService: SharedService) { }

  ngOnInit() {
    this.getCollpaseExpand();
    this.symbol = (localStorage.getItem('symbol'));
  }

  collapseToheader(ev?) {
    this.collapseToheaderOp.emit(ev);

  }

  checkIsformDirty(ev) {
    this.checkIsformDirtyOp.emit(ev);
  }

  getCollpaseExpand() {
    this.sharedService.getMessage().subscribe(val => {
      console.log(val);
      if (val === 'collapse') {
        this.collapsetoheader = true;
      } else {
        this.collapsetoheader = false;
      }
    });
  }

}
