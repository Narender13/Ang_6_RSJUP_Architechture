import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filteritem'
})
export class FilterPipe implements PipeTransform {

  transform(items: any, property: string, term: boolean): any {
    console.log(JSON.stringify(items));
    if (items !== undefined) {
      return items.filter(item => item[property] === term);
    }

  }

}
