import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgXDonutChartSlice } from 'ngx-donutchart/ngx-donutchart.type';
import { CreditDebit } from 'src/app/finance/search/model/credit-debit';

@Component({
  selector: 'rsa-donutchart',
  templateUrl: './donutchart.component.html',
  styleUrls: ['./donutchart.component.scss']
})
export class DonutchartComponent implements OnInit {
  @Input() size = 120;
  @Input() innerRadius = 40;
  @Input() slices: NgXDonutChartSlice[] | any[];
  @Input() creditLimitDetails: CreditDebit[] = [];
  @Input() donutdropdata: any;
  @Output() getDountDropdownData = new EventEmitter();
  @Input() selectedValue;
  constructor() { }

  ngOnInit() {

  }
  hoverChart(event) {
    console.log(event);
  }

  getDountDropdown(item) {
    console.log(item);
    this.getDountDropdownData.emit(item);
  }
}
