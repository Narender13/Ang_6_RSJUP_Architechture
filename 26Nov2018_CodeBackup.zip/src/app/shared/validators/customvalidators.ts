export class Customvalidators {
    //Validate Creditcard Number

    static creditcardValidator(creditcard): any {
        if (creditcard.pristine) {
            return null;
        }
        creditcard.markAsTouched();
        if (Math.abs(creditcard.value) !== 0) {
            return null;
        }
        return {
            invalidateCreditCard: true
        };
    }
}
