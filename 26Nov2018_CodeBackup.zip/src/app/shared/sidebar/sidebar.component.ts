import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { SideNavRouteInfo } from '../../home/modal/sidenav';


@Component({
  selector: 'rsa-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
})
export class SidebarComponent implements OnInit {
  isopen: Boolean = false;

  @Input() sideNavData: SideNavRouteInfo;
  @Input() isopennav: boolean;
  @Input() username:string;
  @Output() hideSideNav = new EventEmitter<boolean>();
  private selectedIndex = 0;
  constructor() {

  }
  @Input() menuitem: SideNavRouteInfo[] = [];
  ngOnInit() {
  }

  closeSidenav(hide: boolean): void {
    
    this.hideSideNav.emit(hide);
  }

  opensidebar(): void {
    this.isopen = !this.isopen;
  }

  setSelectedIndex(index): void {
    this.selectedIndex = index;
  }

}

