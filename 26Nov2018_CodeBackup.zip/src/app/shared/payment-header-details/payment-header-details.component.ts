import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'rsa-payment-header-details',
  templateUrl: './payment-header-details.component.html',
  styleUrls: ['./payment-header-details.component.scss']
})
export class PaymentHeaderDetailsComponent implements OnInit {
  @Input() detailInfo: FormGroup;
  @Input() errorpayee;
  @Input() errordetail;
  @Input() errorglCode;
  @Input() animatedClass: boolean;
  @Input() flagGLCode = false;
  @Input() glaccount: any = [];
  @Input() ondemandFlag;
  @Output() setHdrHiddenValueO = new EventEmitter();
  @Output() clearHdrGLCodeO = new EventEmitter();

  constructor() { }

  ngOnInit() {
    console.log(this.animatedClass, 'animatedClass');
  }

  get payeeName() {
    return this.detailInfo.controls.PayeeName;
  }

  get details() {
    return this.detailInfo.controls.EnglishDescription;
  }
  get glAccount() {
    return this.detailInfo.controls.GLCodeDesc;
  }

  get glCode() {
    return this.detailInfo.controls.GLCode;
  }
  setHdrHiddenValue(ev) {
    this.setHdrHiddenValueO.emit(ev);
  }
  clearHdrGLCode(ev) {
    this.clearHdrGLCodeO.emit(ev);
  }
}
