import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-payment-mode-review-header',
  templateUrl: './payment-mode-review-header.component.html',
  styleUrls: ['./payment-mode-review-header.component.scss']
})
export class PaymentModeReviewHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
