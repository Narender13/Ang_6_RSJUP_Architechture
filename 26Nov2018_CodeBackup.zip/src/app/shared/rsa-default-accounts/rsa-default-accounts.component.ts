import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';

@Component({
    selector: 'rsa-rsa-default-accounts',
    templateUrl: './rsa-default-accounts.component.html',
    styleUrls: ['./rsa-default-accounts.component.scss']
})
export class RsaDefaultAccountsComponent implements OnInit {
    @Input() accountInfo: FormGroup;
    @Input() branchdata = [];
    @Input() costcentredata = [];
    @Input() receiverdataBankName = [];
    @Input() totallingacc = [];
    @Input() receiptDetailsLength;
    @Output() getTotallingDataO = new EventEmitter();
    @Output() setBankDataO = new EventEmitter();
    constructor(private masterDataService: MasterDataService) { }

    ngOnInit() {
    }

    getTotallingData(event, flag) {
        this.getTotallingDataO.emit({ event: event, flag: flag })
    }
    setBankData(ev) {
        this.setBankDataO.emit(ev);
    }
}
