import { Component, OnInit, Input } from '@angular/core';
import { BatchUploadService } from 'src/app/finance/search/service/batch-upload.service';
import { ExcelService } from 'src/app/finance/search/service/excel.service';


@Component({
  selector: 'rsa-payment-bulk-match-unmatch',
  templateUrl: './payment-bulk-match-unmatch.component.html',
  styleUrls: ['./payment-bulk-match-unmatch.component.scss']
})
export class PaymentBulkMatchUnmatchComponent implements OnInit {
  @Input() bulkuploadData = [];
  ifUploadSuccess = true;
  isUploadUnmatched;
  isMatchedOrUnmatched = true;
  isMatched;
  unmatchedRecords;
  matchedRecords;
  totalAmount;
  constructor(private batchUploadService: BatchUploadService, private excelService: ExcelService) { }


  ngOnInit() {
  }



  /* upload logic here */

  /* uploadXlsFile(e) {
    if (e.target.files && e.target.files.length) {
      const selectedFiles = e.target.files;
      console.log(selectedFiles.item(0), 'selectedFiles.item(0)');
      // this.bulkuploadData = data;
      this.ifUploadSuccess = false;
      this.batchUploadService.uploadBatchFile(selectedFiles.item(0)).subscribe((data) => {
        console.log(data);
        this.bulkuploadData = data;
        this.ifUploadSuccess = false;
        this.getBatchData();
        this.getBulkTotal();

      });
    } else {
      console.log('Error while file selection');
    }
  } */

  /* export xlsx logic here */
  exportAsXlsx(): void {
    this.isUploadUnmatched = true;
    this.excelService.exportAsExcelFile(this.unmatchedRecords, 'Unmatched');
  }
  /* check match or unmatched */
  checkMatchedOrUnmatched(e) {
    this.isMatchedOrUnmatched = !this.isMatchedOrUnmatched;
    this.isMatched = !this.isMatched;
    this.getBatchData();
    this.getBulkTotal();
  }


  getBatchData() {
    this.unmatchedRecords = this.bulkuploadData.filter(item => item.Matched === false);
    this.matchedRecords = this.bulkuploadData.filter(item => item.Matched === true);
  }
  getBulkTotal() {
    this.totalAmount = 0;
    const data = (this.isMatched) ? this.matchedRecords : this.unmatchedRecords;
    const dataReduced = data.map(item => {
      this.totalAmount = this.totalAmount + item.GrossAmount;
    });
    console.log(' this.totalAmount :', this.totalAmount);
  }

}
