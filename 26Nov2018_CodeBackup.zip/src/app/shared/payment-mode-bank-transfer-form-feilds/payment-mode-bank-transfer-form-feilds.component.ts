import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'rsa-payment-mode-bank-transfer-form-feilds',
  templateUrl: './payment-mode-bank-transfer-form-feilds.component.html',
  styleUrls: ['./payment-mode-bank-transfer-form-feilds.component.scss']
})
export class PaymentModeBankTransferFormFeildsComponent implements OnInit {

  @Input() bankTransfer: FormGroup;
  @Input() errorbankcode;
  @Input() errorchequedate;
  @Input() errorinstrumentrefno;
  @Input() payeedataBankName = [];
  constructor() { }

  ngOnInit() {
    console.log(this.errorinstrumentrefno, 'chequeInfo');
  }


  get payeebankcode() {
    return this.bankTransfer['controls'].PayeeBankCode;
  }

  get chequedate() {
    return this.bankTransfer.controls.ChequeDate;
  }


  get instrumentrefno() {
    return this.bankTransfer.controls.InstrumentRefNo;
  }

}
