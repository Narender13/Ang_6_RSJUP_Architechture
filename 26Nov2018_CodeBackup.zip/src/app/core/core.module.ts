import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { Page404Component } from './page404/page404.component';
import { httpInterceptorProviders } from 'src/app/core/interceptor';
import { TechnicalErrorComponent } from 'src/app/core/technicalError/technicalerror.component';
import { MessageService } from 'src/app/core/message/service/message.service';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    HttpModule,
    HttpClientModule,
  ],
  declarations: [
    Page404Component,
    TechnicalErrorComponent
  ],
  providers: [
    httpInterceptorProviders,
    MessageService
  ],
  exports: [
    Page404Component,
  ]

})
export class CoreModule { }
