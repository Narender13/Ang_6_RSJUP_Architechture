import { InjectionToken } from '@angular/core';

import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoaderInterceptorService } from './loader-interceptor';
import { HttpErrorInterceptor } from './global-error-handler/error-handler-service.service';
import { TimeoutInterceptor } from 'src/app/core/interceptor/time-out-interceptor';
const DEFAULT_TIMEOUT = new InjectionToken<number>('defaultTimeout');
const defaultTimeout = 10000;

/** Http interceptor providers in outside-in order */
export const httpInterceptorProviders = [
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptorService, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true },
    // { provide: HTTP_INTERCEPTORS, useClass: TimeoutInterceptor, multi: true },
];
