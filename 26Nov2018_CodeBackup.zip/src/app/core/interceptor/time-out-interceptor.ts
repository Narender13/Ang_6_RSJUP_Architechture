import { Injectable, InjectionToken, Inject } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { timeout } from 'rxjs/operators';


@Injectable()
export class TimeoutInterceptor implements HttpInterceptor {
    constructor() { }

intercept(req: HttpRequest < any >, next: HttpHandler): Observable < HttpEvent < any >> {
    const timeouts = Number(req.headers.get('timeout')) || 50000;
    return next.handle(req).pipe(
        timeout(timeouts)
    );
}
}

