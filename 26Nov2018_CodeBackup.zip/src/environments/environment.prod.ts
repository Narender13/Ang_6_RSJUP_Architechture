import { AG_GRID_LICENSE_KEY } from 'src/app/app.utilities';
export const environment = {
  production: true,
  agGridLicenseKey: AG_GRID_LICENSE_KEY,
  APP_BASE_HREF : 'http://BLRRJUPITERT01:2120/'

};
